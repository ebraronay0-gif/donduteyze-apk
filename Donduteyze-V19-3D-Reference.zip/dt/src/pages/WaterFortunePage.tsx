import { useState, type PointerEvent } from 'react';
import { ArrowLeft, RotateCw, Sparkles, Waves, CheckCircle2 } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { NavTabId } from '@/lib/navTabs';
import { submitFortune } from '@/lib/fortuneApi';
import { FORTUNE_COST, getCredits } from '@/lib/credits';

interface Props { onNavigate: (tab: NavTabId) => void; }

export default function WaterFortunePage({ onNavigate }: Props) {
  const [energy, setEnergy] = useState(0);
  const [angle, setAngle] = useState(0);
  const [adOpen, setAdOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const stir = (e: PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    setEnergy((v) => Math.min(8, v + 1));
    setAngle((v) => v + 45);
  };

  const requestReading = () => {
    setError('');
    setMessage('');
    if (energy < 8) { setError('Önce suyu 8 kez nazikçe karıştır.'); return; }
    if (getCredits() < FORTUNE_COST) { setError(`Su Falı için ${FORTUNE_COST} kredi gerekiyor.`); return; }
    setAdOpen(true);
  };

  const afterAd = async () => {
    setAdOpen(false);
    setBusy(true); setError(''); setMessage('');
    const result = await submitFortune({ fortuneType: 'water', userInput: JSON.stringify({ ritual: 'Su 8 kez karıştırıldı', energy, rotation: angle }) });
    setBusy(false);
    if (!result.success) { setError(result.error || 'Su falın gönderilemedi.'); return; }
    setMessage('Su falın yapay zekâya gönderildi. Sonucun Fallarım bölümüne kaydedildi. ✨');
  };

  return <div className="relative min-h-screen overflow-hidden bg-[#09021b] pb-32">
    <StarField count={80}/>
    <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_8%,rgba(99,34,180,.34),transparent_34%),radial-gradient(circle_at_0%_60%,rgba(14,116,144,.18),transparent_30%)]"/>
    <main className="relative z-10 mx-auto max-w-2xl px-4 py-5">
      <button onClick={()=>onNavigate('home')} className="mb-5 flex items-center gap-2 rounded-full border border-gold-400/35 bg-[#16062b]/85 px-5 py-3 font-display text-sm text-gold-100 shadow-[0_0_20px_rgba(251,191,36,.08)]"><ArrowLeft className="h-4 w-4"/> Geri</button>
      <section className="reference-page-panel">
        <div className="relative text-center">
          <p className="reference-eyebrow">DÖNDÜ TEYZE'NİN MİSTİK RİTÜELİ</p>
          <h1 className="reference-title">SU FALI</h1>
          <p className="reference-copy">Lütfen suyu karıştırın. Parmağınızla suyu nazikçe hareket ettirin, falınızın enerjisini uyandıralım.</p>
        </div>
        <div onPointerDown={stir} className="water-ritual mt-6" style={{transform:`perspective(900px) rotateX(2deg) rotate(${angle * .15}deg)`}}>
          <img src="/water-ritual.png" alt="Su falı kasesi" draggable={false}/>
          <div className="water-ripple" style={{transform:`rotate(${angle}deg) scale(${1 + energy*.018})`}}/>
          <div className="water-instruction"><RotateCw className="mx-auto h-8 w-8 text-gold-200"/><b>LÜTFEN SUYU KARIŞTIRIN</b><span>Parmağınızla dairesel hareketler yapın</span></div>
        </div>
        <div className="mt-5 rounded-[22px] border border-sky-400/20 bg-[#09143b]/80 p-4">
          <div className="flex items-center justify-between"><span className="font-display text-sm text-gold-100">Su enerjisi</span><b className="text-sky-100">{energy}/8</b></div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-black/40"><div className="h-full rounded-full bg-gradient-to-r from-sky-500 via-violet-500 to-gold-400 transition-all" style={{width:`${energy/8*100}%`}}/></div>
        </div>
        {error && <div className="mt-4 rounded-2xl border border-rose-400/30 bg-rose-950/30 px-4 py-3 text-sm text-rose-200">{error}</div>}
        {message && <div className="mt-4 flex items-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-200"><CheckCircle2 className="h-4 w-4"/>{message}</div>}
        <button disabled={busy || energy < 8} onClick={requestReading} className="reference-cta mt-5"><Sparkles className="h-5 w-5"/>{busy?'YAPAY ZEKÂYA GÖNDERİLİYOR…':`SU FALINA BAK · ${FORTUNE_COST} KREDİ`}</button>
        <p className="mt-3 text-center text-[10px] text-mystic-500">{energy<8?'Suyu karıştırarak enerjiyi tamamla.':'Hazırsın. Reklamı izledikten sonra su falın yapay zekâya gönderilecek.'}</p>
      </section>
    </main>
    <RewardedAdModal open={adOpen} onComplete={afterAd} onClose={()=>setAdOpen(false)} rewardLabel="Su Falına Devam Et"/>
  </div>;
}
