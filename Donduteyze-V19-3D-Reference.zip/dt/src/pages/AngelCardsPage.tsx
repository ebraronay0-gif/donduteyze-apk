import { useState } from 'react';
import { ArrowLeft, Sparkles, CheckCircle2 } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { NavTabId } from '@/lib/navTabs';
import { submitFortune } from '@/lib/fortuneApi';
import { FORTUNE_COST, getCredits } from '@/lib/credits';

interface Props { onNavigate: (tab: NavTabId) => void; }
const cards = ['Işık Meleği','Aşk Meleği','Cesaret Meleği','Bereket Meleği','Şifa Meleği','Yol Meleği'];
export default function AngelCardsPage({onNavigate}:Props){
 const [picks,setPicks]=useState<number[]>([]); const [adOpen,setAdOpen]=useState(false); const [busy,setBusy]=useState(false); const [message,setMessage]=useState(''); const [error,setError]=useState('');
 const pick=(i:number)=>{if(picks.includes(i)||picks.length>=3)return;setPicks([...picks,i]);};
 const go=()=>{setError('');if(picks.length!==3){setError('Üç melek kartı seç.');return;}if(getCredits()<FORTUNE_COST){setError(`Melek Kartları için ${FORTUNE_COST} kredi gerekiyor.`);return;}setAdOpen(true)};
 const afterAd=async()=>{setAdOpen(false);setBusy(true);const r=await submitFortune({fortuneType:'angel',userInput:JSON.stringify({cards:picks.map(i=>cards[i])})});setBusy(false);if(!r.success){setError(r.error||'Melek falın gönderilemedi.');return;}setMessage('Melek kartların yapay zekâya gönderildi ve Fallarım bölümüne kaydedildi. ✨');};
 return <div className="relative min-h-screen overflow-hidden bg-[#09021b] pb-32"><StarField count={85}/><div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_5%,rgba(168,85,247,.34),transparent_34%)]"/><main className="relative z-10 mx-auto max-w-2xl px-4 py-5"><button onClick={()=>onNavigate('home')} className="mb-5 flex items-center gap-2 rounded-full border border-gold-400/35 bg-[#16062b]/85 px-5 py-3 font-display text-sm text-gold-100"><ArrowLeft className="h-4 w-4"/> Geri</button><section className="reference-page-panel"><p className="reference-eyebrow text-center">DÖNDÜ TEYZE'NİN MİSTİK RİTÜELİ</p><h1 className="reference-title text-center">MELEK KARTLARI</h1><p className="reference-copy text-center">Kalbine en yakın üç meleği seç. Kartların mesajını birlikte dinleyelim.</p><div className="angel-grid">{cards.map((name,i)=>{const selected=picks.includes(i);return <button key={name} onClick={()=>pick(i)} className={`angel-card ${selected?'selected':''}`}><div className="angel-wings">✦</div><div className="angel-symbol">☼</div><b>{name}</b><span>{selected?'Seçildi':'Kartı seç'}</span></button>})}</div>{error&&<div className="mt-4 rounded-2xl border border-rose-400/30 bg-rose-950/30 px-4 py-3 text-sm text-rose-200">{error}</div>}{message&&<div className="mt-4 flex items-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-200"><CheckCircle2 className="h-4 w-4"/>{message}</div>}<button disabled={busy||picks.length!==3} onClick={go} className="reference-cta mt-5"><Sparkles className="h-5 w-5"/>{busy?'YAPAY ZEKÂYA GÖNDERİLİYOR…':`MELEK FALINA BAK · ${FORTUNE_COST} KREDİ`}</button></section></main><RewardedAdModal open={adOpen} onComplete={afterAd} onClose={()=>setAdOpen(false)} rewardLabel="Melek Falına Devam Et"/></div>;
}
