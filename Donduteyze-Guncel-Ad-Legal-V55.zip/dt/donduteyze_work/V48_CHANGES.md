# V48 — Falcılar Sayfası + Launcher Icon Fix

- Falcılarımıza Fal Baktır sayfası profesyonel, premium mor-altın 3D görsel dil ile yenilendi.
- Aliye Teyze, Sultan Teyze, Yasemen Bacı ve Döndü Teyze için 3D çerçeveli portre sunumu kullanıldı.
- 72 kredi tek ücret ve görüşme sonlandırılana kadar mesajlaşma bilgisi korunuyor.
- Android launcher ikonu için build script ve GitHub Actions akışı manifest seviyesinde zorunlu Döndü Teyze ikonuna bağlandı.
- Adaptive icon + eski Android sürümleri için raster fallback eklendi.
- Sürüm 1.0.48 / versionCode 48.
