# V52 — Deterministic launcher icon fix

The Android launcher now uses the unique `@mipmap/ic_donduteyze` resource, not Capacitor's `ic_launcher`.
The build script deletes generated launcher resources, writes the approved `resources/launcher-icon-final.png` into all Android densities, creates the Android 8+ adaptive icon, and rewrites the manifest to the unique resource.


V53 build workflow: old force-launcher-icon step removed; manifest remains on @mipmap/ic_donduteyze.
