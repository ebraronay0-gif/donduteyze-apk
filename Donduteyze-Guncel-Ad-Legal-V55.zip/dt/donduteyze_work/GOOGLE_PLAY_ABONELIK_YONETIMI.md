# Google Play abonelik yönetimi

Premium > Aboneliğim ekranında uygulama içinden otomatik yenileme iptal edilmez.
Kullanıcı **Google Play'de Aboneliği Yönet** düğmesine basarak Google Play'in Abonelikler ekranına yönlendirilir.

Google Play'de iptal edilen aboneliklerde kullanıcı, ücretini ödediği mevcut dönem bitene kadar Premium avantajlarını kullanmaya devam eder; sonraki yenileme için ücret alınmaz.

Yönetim bağlantısı:
https://play.google.com/store/account/subscriptions
