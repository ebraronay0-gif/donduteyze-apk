# V24 – Su Falı + Melek Kartları + Celestial Deck Refresh

- Ana sayfaya Su Falı ve Melek Kartları eklendi; mevcut mor-altın görsel dili korunarak yeni özel kart görselleri eklendi.
- Su Falı için parmakla karıştırma etkileşimi, hareket sayacı, reklam kilidi ve yapay zekâya gönderim eklendi.
- Melek Kartları için 12 kartlık özel seçim ekranı, 3 kart seçimi, reklam kilidi ve yapay zekâya gönderim eklendi.
- Su/Melek sonuçları `Fallarım` akışına `submitFortune` üzerinden kaydedilecek şekilde bağlandı; Supabase aktifse `gemini-fortune` Edge Function'a gönderiliyor.
- Su/Melek için yerel fallback yorumları eklendi.
- Katina ve Tarot kart desteleri için daha zengin 3D/celestial kart arka planı, altın çerçeve ve ışık efektleri eklendi.
- Fortune category metadata'sına Su Falı ve Melek Kartları eklendi.
- Sürüm 1.0.24 / Android versionCode 24.
