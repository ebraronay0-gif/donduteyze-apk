# V39 – Legal contact and consent separation

- Legal texts identify the data controller/operator as **Ebrar Onay**.
- Contact email is **ebrar...**.
- Physical address is not included in the in-app KVKK/user/legal text UI.
- KVKK Privacy & Information Notice is informational and is no longer tied to a consent checkbox.
- User Agreement and Terms of Use remain explicit acceptance checkboxes and are required before onboarding/auth/premium purchase can continue.
- Updated onboarding validation/error text accordingly.
- Legal modal no longer displays a placeholder-address warning.
- Legal text version updated to v2.

Note: A production legal review is still recommended before publishing, especially for consumer sales, subscriptions, payment terms, data transfers, and the exact business/contact disclosures required by the applicable sales channel.
