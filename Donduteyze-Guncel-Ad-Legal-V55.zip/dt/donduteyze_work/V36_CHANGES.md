# V36 – Premium tasarımı ve paketleri

- Premium sayfası mor/siyah + altın 3D mistik tasarım diline göre yeniden düzenlendi.
- Haftalık 59,99 TL, aylık 99,99 TL, yıllık 499,99 TL üyelik kartları eklendi.
- Üyeliklerde reklamsız kullanım, günlük 20 kredi ve öncelikli fal ayrıcalıkları gösteriliyor.
- Yıllık pakete 1 defalık 72 kredi düşmeden ücretsiz falcı görüşmesi ayrıcalığı eklendi.
- 500 kredi / 599,99 TL + 30 gün reklamsız, 200 kredi / 299,99 TL + 15 gün reklamsız, 72 kredi / 99,99 TL + 7 gün reklamsız paketleri eklendi.
- Kredi paketleri satın alındığında kredi ve reklamsız süre yerel abonelik önbelleğine işleniyor.
- Abonelik kayıtlarına `auto_renew` işareti eklendi. Gerçek otomatik para çekme/yenileme için Google Play / App Store ödeme altyapısı ve sunucu webhookları ayrıca bağlanmalıdır.
