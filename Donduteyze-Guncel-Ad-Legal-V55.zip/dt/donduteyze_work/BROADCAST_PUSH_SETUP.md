# Toplu Bildirim Kurulumu

Admin panelindeki **Bildirim Gönder** artık yalnızca `notifications` tablosuna kayıt atmaz; `send-broadcast-push` Supabase Edge Function'ını çağırarak kayıtlı kullanıcı cihazlarına FCM bildirimi gönderir.

## Supabase Secret

Edge Function'ın çalışması için Supabase projesinde `FCM_SERVICE_ACCOUNT_JSON` secret'ı tanımlanmalıdır. Değer, Firebase/Google Cloud servis hesabının JSON içeriğidir.

Ayrıca Firebase Cloud Messaging API'nin etkin olduğundan emin olun.

## Deploy

```bash
supabase functions deploy send-broadcast-push --no-verify-jwt
supabase secrets set FCM_SERVICE_ACCOUNT_JSON='...'
```

Fonksiyon kendi içinde admin şifresini `app_config.admin_password` üzerinden doğrular. Admin şifresi istemciye kalıcı olarak kaydedilmez; admin oturumu boyunca bellekte tutulur.

FCM tek çağrıda en fazla 500 hedef desteklediği için fonksiyon cihazları 500'lük gruplara ayırır ve daha fazla kullanıcı için sırayla devam eder. Geçersiz/UNREGISTERED tokenlar otomatik temizlenir.
