# Döndü Teyze — Gerçek Zamanlı Sohbet ve Telefon Bildirimleri

Bu sürümde hem **Canlı Falcı Sohbeti** hem de **Canlı Destek** Supabase Realtime ile çalışır. Mesaj geldiğinde 5 saniyelik polling yerine INSERT olayı anında ekrana düşer.

## Telefon bildirimi

Android/iOS tarafında Capacitor Push Notifications + Local Notifications kullanılır.

- Kullanıcı cihazı `role=user` olarak `push_tokens` tablosuna kaydedilir.
- Admin cihazı, admin şifresi doğrulandıktan sonra `role=admin` olarak kaydedilir.
- Kullanıcı → admin mesajında admin cihazlarına push gönderilir.
- Admin → kullanıcı mesajında ilgili kullanıcının cihazlarına push gönderilir.
- Uygulama açıkken gelen push için ayrıca yerel telefon bildirimi oluşturulur.

## Supabase Edge Function secrets

`send-chat-push` için Supabase Dashboard > Edge Functions > Secrets bölümünde şu secret gereklidir:

`FCM_SERVICE_ACCOUNT_JSON`

Değeri Firebase Console'dan oluşturulan Google/Firebase service account JSON'unun tamamıdır.

Örnek olarak JSON şu alanları içermelidir:

- `project_id`
- `client_email`
- `private_key`

`register-push-token` admin doğrulaması için `app_config.admin_password` değerini kullanır. İsterseniz ayrıca `ADMIN_PASSWORD` secret'ı ile override edilebilir.

## Android Firebase kurulumu

Capacitor Push Notifications'ın gerçek Android push alabilmesi için Firebase projesinin `google-services.json` dosyası Android uygulamasına eklenmelidir. Bu dosya projeye güvenli şekilde eklenmeden APK'da FCM arka plan bildirimi çalışmaz.

Uygulama ID'si:

`com.donduteyze.app`

## Realtime

Migration şu tabloları `supabase_realtime` publication'a ekler:

- `live_chat_sessions`
- `live_chat_messages`
- `support_messages`
