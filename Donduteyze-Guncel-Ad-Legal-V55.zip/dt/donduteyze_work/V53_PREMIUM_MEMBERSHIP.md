# V53 – Premium abonelik yönetimi

- Premium sayfası telefon ekranına uygun 3+3 kompakt paket düzenine geçirildi.
- Üstte Döndü Teyze ikonu, Aboneliğim ve Giriş Yap kontrolleri eklendi.
- Haftalık 59,99 TL, aylık 129,99 TL, yıllık 599,99 TL abonelikleri güncellendi.
- Aboneliklerde günlük 20 kredi, reklamsız kullanım ve öncelikli fal gösteriliyor.
- Tek seferlik 72 / 89,99 TL, 150 / 129,99 TL, 500 / 499,99 TL paketleri ve 15 günlük reklamsız kullanım eklendi.
- Aboneliğim ekranında aktif paket, bitiş tarihi, günlük kredi, reklam durumu ve otomatik yenileme durumu gösteriliyor.
- Otomatik yenilemeyi iptal etme akışı eklendi. İptal, mevcut dönemi bitirmez; expires_at tarihine kadar Premium avantajları devam eder.
- `auto_renew` Supabase alanı için migration eklendi.
- Gerçek karttan otomatik tahsilat/yenileme için Google Play Billing / App Store StoreKit ve sunucu webhooklarının ayrıca bağlanması gerekir.
