# V30 — Ay Işığı Oyunu Günlük Hak
- Ay Işığı Oyunu günlük kullanım hakkı net olarak 1 olarak tanımlandı.
- Kullanım durumu günlük olarak korunur; hak kullanıldığında aynı gün tekrar oynanamaz.
- Oyun ekranına "Günlük hak: 0/1" veya "1/1" göstergesi eklendi.
- Önceki V29 tasarımı ve diğer oyunların işleyişi korunmuştur.
