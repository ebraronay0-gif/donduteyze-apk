# Döndü Teyze Premium — Google Play yayın kontrolü

Bu sürümde Premium ekranı onaylanan tasarıma göre yenilendi. Android tarafında **sahte/yerel satın alma akışı özellikle kapatıldı**. Bunun nedeni Google Play'in dijital ürünler ve aboneliklerde Google Play Billing kullanılmasını zorunlu tutmasıdır.

## Play Console ürünleri

Aşağıdaki ürün kimliklerini Play Console'da oluşturup uygulamadaki Billing katmanına bağlayın:

### Abonelikler
- `donduteyze_premium_weekly` — Haftalık — 59,99 TL — otomatik yenilenir — her gün 20 kredi + reklamsız + öncelikli fal + falcılarla sohbet
- `donduteyze_premium_monthly` — Aylık — 129,99 TL — otomatik yenilenir — her gün 20 kredi + reklamsız + öncelikli fal + falcılarla sohbet
- `donduteyze_premium_yearly` — Yıllık — 499,99 TL — otomatik yenilenir — her gün 20 kredi + reklamsız + öncelikli fal + falcılarla sohbet

Bu üç ürün aynı Premium abonelik grubunda olmalı. Haftalık/aylık/yıllık seçeneklerin her biri kendi temel planı olarak yapılandırılmalıdır.

### Tek seferlik ürün
- `donduteyze_credits_250` — Tüketilebilir ürün — 149,99 TL — 250 kredi

250 kredi ürünü **abonelik değildir** ve reklam kaldırmaz.

## Önemli yayın kuralları

- Uygulama içindeki fiyatlar Google Play Billing'ın kullanıcıya gösterdiği fiyatla aynı olmalıdır.
- Abonelik ekranında ücret, dönem ve otomatik yenileme açıkça gösterilmelidir.
- İptal, Google Play Abonelikler ekranından yapılabilir; uygulama mevcut dönemin sonuna kadar Premium haklarını korumalıdır.
- Aboneliklerin gerçek durumu (yenileme, iptal, sona erme, grace period vb.) sunucu tarafında Google Play Developer API ile doğrulanmalıdır.
- Satın alma gerçekleşmeden Supabase'e abonelik/credit hakkı yazılmamalıdır.
- Yayın öncesinde Internal Testing/Closed Testing üzerinde gerçek Google Play test hesabıyla satın alma, iptal, yenileme ve geri yükleme test edilmelidir.

## Mevcut kodda bilinçli güvenlik önlemi

`src/lib/subscriptions.ts` Android'de Google Play Billing bağlanmadan önce satın alma işlemini reddeder. Böylece önceki gibi yalnızca Supabase'e kayıt atıp gerçek ödeme alınmış gibi Premium açılması engellenmiştir.
