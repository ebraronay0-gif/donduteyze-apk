# V23 changes
- Rewarded AdMob flow rewritten around Loaded / FailedToLoad / FailedToShow / Rewarded / Dismissed events with retry support.
- Daily reward, game, zodiac, fortune continuation and fortune submission flows all reuse the corrected rewarded-ad component.
- Yıldız Falı local fallback readings are saved completed with a non-empty result; old empty completed records are recovered with a fallback result.
- Added cosmic/planetary backdrop treatment behind the main fortune-card grid.
- Falcı list renamed to Aliye Teyze, Döndü Teyze, Yasemin Nine, Sultan Teyze with dedicated 3D-style assets.
- Android launcher icon now uses a unique v23 resource name and a dedicated character/crystal crop to prevent the old launcher icon from surviving Capacitor generation.
- Android workflow versionCode/versionName bumped to 23 / 1.0.23.
