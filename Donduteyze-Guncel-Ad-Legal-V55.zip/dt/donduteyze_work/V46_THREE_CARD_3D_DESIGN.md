# V46 – 3D 12 Kartlı Tarot / Melek / Katina Tasarımı

- Tarot, Melek Kartları ve Katina sayfaları ortak, mor-altın mistik 3D görsel sistemine geçirildi.
- Her sayfada tam 12 görsel kart bulunuyor.
- Kullanıcı en fazla 3 kart seçebiliyor; seçim sırası gösteriliyor.
- `FALIMA BAK` butonu yalnızca 3 kart seçildiğinde aktif oluyor.
- Seçim ve gönderim sonrası mevcut `submitFortune` akışı kullanılıyor.
- Mevcut sistemdeki 4 dakikalık `ready_at` gecikmesi korunuyor; sonuç hazır olmadan Fallarım'da yorum metni gösterilmiyor.
- Tarot, Melek ve Katina kartlarının 36 adet 3D görseli `public/generated-cards/` altında yer alıyor.
- Reklam/kredi akışı korunuyor; fal gönderimi mevcut `RewardedAdModal` sonrasında gerçekleşiyor.
