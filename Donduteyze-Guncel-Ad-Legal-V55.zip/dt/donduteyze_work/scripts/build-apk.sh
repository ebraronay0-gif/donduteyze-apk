#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

ICON="resources/launcher-icon-final.png"
RES="android/app/src/main/res"
MANIFEST="android/app/src/main/AndroidManifest.xml"

[ -s "$ICON" ] || { echo "HATA: $ICON bulunamadı"; exit 1; }
command -v convert >/dev/null 2>&1 || { sudo apt-get update && sudo apt-get install -y imagemagick; }

echo "1/6 Web uygulaması derleniyor..."
npm run build

echo "2/6 Android projesi oluşturuluyor..."
if [ ! -d android ]; then
  npx cap add android
fi

# Firebase Cloud Messaging configuration is supplied by CI as a secret file.
# It must live at android/app/google-services.json for the Android Gradle plugin.
if [ -s firebase-google-services.json ]; then
  cp -f firebase-google-services.json android/app/google-services.json
  python3 - <<'PY2'
from pathlib import Path
root = Path('android/build.gradle')
s = root.read_text()
if 'com.google.gms:google-services' not in s:
    marker = 'dependencies {'
    if marker in s:
        s = s.replace(marker, marker + "\n        classpath 'com.google.gms:google-services:4.4.2'", 1)
        root.write_text(s)
app = Path('android/app/build.gradle')
s = app.read_text()
if 'com.google.gms.google-services' not in s:
    s = "apply plugin: 'com.google.gms.google-services'\n" + s
    app.write_text(s)
PY2
else
  echo 'UYARI: firebase-google-services.json bulunamadı; FCM Android yapılandırması eksik.'
fi

# Capacitor's generated default launcher resources are deliberately removed.
rm -rf "$RES/mipmap-anydpi-v26" "$RES/mipmap-anydpi"
find "$RES" -type f \( \
  -name 'ic_launcher*' -o \
  -name 'ic_donduteyze*' \
\) -delete || true

mkdir -p "$RES"/mipmap-mdpi "$RES"/mipmap-hdpi "$RES"/mipmap-xhdpi \
  "$RES"/mipmap-xxhdpi "$RES"/mipmap-xxxhdpi \
  "$RES"/mipmap-anydpi-v26 "$RES"/drawable-nodpi "$RES"/values

echo "3/6 Döndü Teyze launcher ikonu uygulanıyor..."

# Unique resource name: this prevents any Capacitor ic_launcher resource from winning.
cp -f "$ICON" "$RES/drawable-nodpi/ic_donduteyze_foreground.png"

cat > "$RES/values/donduteyze_icon_colors.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="donduteyze_icon_background">#16052F</color>
</resources>
XML

cat > "$RES/mipmap-anydpi-v26/ic_donduteyze.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/donduteyze_icon_background" />
    <foreground android:drawable="@drawable/ic_donduteyze_foreground" />
</adaptive-icon>
XML

cp "$RES/mipmap-anydpi-v26/ic_donduteyze.xml" \
   "$RES/mipmap-anydpi-v26/ic_donduteyze_round.xml"

declare -A SIZES=([mdpi]=48 [hdpi]=72 [xhdpi]=96 [xxhdpi]=144 [xxxhdpi]=192)
for density in "${!SIZES[@]}"; do
  size="${SIZES[$density]}"
  convert "$ICON" -background '#16052F' -gravity center \
    -resize "${size}x${size}" -extent "${size}x${size}" \
    "$RES/mipmap-${density}/ic_donduteyze.png"
  cp "$RES/mipmap-${density}/ic_donduteyze.png" \
     "$RES/mipmap-${density}/ic_donduteyze_round.png"
done

python3 - <<'PY'
from pathlib import Path
import re
p = Path('android/app/src/main/AndroidManifest.xml')
s = p.read_text()
a = s.index('<application')
b = s.index('>', a)
app = s[a:b]
app = re.sub(r'\s+android:icon="[^"]*"', '', app)
app = re.sub(r'\s+android:roundIcon="[^"]*"', '', app)
app += ' android:icon="@mipmap/ic_donduteyze" android:roundIcon="@mipmap/ic_donduteyze"'
p.write_text(s[:a] + app + s[b:])
PY

echo "4/6 Capacitor senkronizasyonu..."
npx cap sync android

echo "5/6 Manifest ve kaynak doğrulaması..."
grep -q 'android:icon="@mipmap/ic_donduteyze"' "$MANIFEST"
grep -q 'android:roundIcon="@mipmap/ic_donduteyze"' "$MANIFEST"
test -s "$RES/drawable-nodpi/ic_donduteyze_foreground.png"
test -s "$RES/mipmap-anydpi-v26/ic_donduteyze.xml"
test -s "$RES/mipmap-xxxhdpi/ic_donduteyze.png"

# The old Capacitor launcher name must not be referenced by the application manifest.
if grep -q 'android:icon="@mipmap/ic_launcher"' "$MANIFEST"; then
  echo 'HATA: Manifest hâlâ ic_launcher kullanıyor.'
  exit 1
fi

echo "6/6 İKON TAMAM: @mipmap/ic_donduteyze"
