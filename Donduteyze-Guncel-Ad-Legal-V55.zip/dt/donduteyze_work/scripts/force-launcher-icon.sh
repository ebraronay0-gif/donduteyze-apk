#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

ICON="resources/launcher-icon-final.png"
RES="android/app/src/main/res"

[ -s "$ICON" ] || { echo "HATA: $ICON bulunamadı"; exit 1; }
command -v convert >/dev/null 2>&1 || { sudo apt-get update && sudo apt-get install -y imagemagick; }

mkdir -p "$RES"/mipmap-mdpi "$RES"/mipmap-hdpi "$RES"/mipmap-xhdpi "$RES"/mipmap-xxhdpi "$RES"/mipmap-xxxhdpi "$RES"/mipmap-anydpi-v26 "$RES"/drawable-nodpi "$RES"/values

# Remove any Capacitor/default launcher resources that could win over the requested icon.
rm -f "$RES"/mipmap-*/ic_launcher.png "$RES"/mipmap-*/ic_launcher_round.png
rm -f "$RES"/mipmap-*/ic_launcher.webp "$RES"/mipmap-*/ic_launcher_round.webp
rm -f "$RES"/mipmap-anydpi-v26/ic_launcher.xml "$RES"/mipmap-anydpi-v26/ic_launcher_round.xml

for pair in mdpi:48 hdpi:72 xhdpi:96 xxhdpi:144 xxxhdpi:192; do
  density="${pair%%:*}"
  size="${pair##*:}"
  convert "$ICON" -background none -gravity center -resize "${size}x${size}" -extent "${size}x${size}" "$RES/mipmap-$density/ic_launcher.png"
  cp "$RES/mipmap-$density/ic_launcher.png" "$RES/mipmap-$density/ic_launcher_round.png"
done

convert "$ICON" -background none -gravity center -resize 360x360 -extent 432x432 "$RES/drawable-nodpi/ic_launcher_foreground.png"
cat > "$RES/values/launcher_icon.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="launcher_icon_background">#16052F</color>
</resources>
XML

cat > "$RES/mipmap-anydpi-v26/ic_launcher.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/launcher_icon_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
XML
cp "$RES/mipmap-anydpi-v26/ic_launcher.xml" "$RES/mipmap-anydpi-v26/ic_launcher_round.xml"

python3 - <<'PY'
from pathlib import Path
import re
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
a=s.index('<application')
b=s.index('>', a)
app=s[a:b]
app=re.sub(r'\s+android:icon="[^"]*"', '', app)
app=re.sub(r'\s+android:roundIcon="[^"]*"', '', app)
app += ' android:icon="@mipmap/ic_launcher" android:roundIcon="@mipmap/ic_launcher_round"'
p.write_text(s[:a]+app+s[b:])
PY

grep -q 'android:icon="@mipmap/ic_launcher"' android/app/src/main/AndroidManifest.xml
[ -s "$RES/mipmap-mdpi/ic_launcher.png" ]
[ -s "$RES/mipmap-anydpi-v26/ic_launcher.xml" ]

echo "LAUNCHER ICON OK"
