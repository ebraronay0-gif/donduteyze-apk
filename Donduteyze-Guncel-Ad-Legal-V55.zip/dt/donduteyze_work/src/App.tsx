import React, { useState, useEffect } from 'react';
import { App as CapacitorApp } from '@capacitor/app';
import { Sparkles, Stars, Crown } from 'lucide-react';
import OnboardingPage from '@/pages/OnboardingPage';
import HomePage from '@/pages/HomePage';
import CoffeeFortunePage from '@/pages/CoffeeFortunePage';
import PalmFortunePage from '@/pages/PalmFortunePage';
import TarotFortunePage from '@/pages/TarotFortunePage';
import KatinaFortunePage from '@/pages/KatinaFortunePage';
import FaceFortunePage from '@/pages/FaceFortunePage';
import DreamFortunePage from '@/pages/DreamFortunePage';
import WheelFortunePage from '@/pages/WheelFortunePage';
import DiceFortunePage from '@/pages/DiceFortunePage';
import LotteryPage from '@/pages/LotteryPage';
import PremiumPage from '@/pages/PremiumPage';
import ZodiacPage from '@/pages/ZodiacPage';
import StarFortunePage from '@/pages/StarFortunePage';
import WaterFortunePage from '@/pages/WaterFortunePage';
import AngelCardsFortunePage from '@/pages/AngelCardsFortunePage';
import AuthPage from '@/pages/AuthPage';
import HistoryPage from '@/pages/HistoryPage';
import DiaryPage from '@/pages/DiaryPage';
import EarnPage from '@/pages/EarnPage';
import LiveChatPage from '@/pages/LiveChatPage';
import NightGamePage from '@/pages/NightGamePage';
import MyWorldPage from '@/pages/MyWorldPage';
import FortuneTellerPage from '@/pages/FortuneTellerPage';
import AdminPanel from '@/pages/admin/AdminPanel';
import BottomNavBar from '@/components/BottomNavBar';
import CreditHeader from '@/components/CreditHeader';
import SupportModal from '@/components/SupportModal';
import FloatingFortuneButton from '@/components/FloatingFortuneButton';
import BannerAd from '@/components/BannerAd';
import InterstitialAd from '@/components/InterstitialAd';
import { shouldShowInterstitial } from '@/lib/ads';
import { isAdFree } from '@/lib/subscriptions';
import type { UserProfile } from '@/lib/profile';
import { loadProfile } from '@/lib/profile';
import type { NavTabId } from '@/lib/navTabs';
import { getStoredAuth, clearStoredAuth, handleOAuthCallback } from '@/lib/auth';
import type { AuthUser } from '@/lib/auth';
import { supabase, hasSupabaseConfig } from '@/lib/supabase';
import { syncCreditsFromSubscription } from '@/lib/subscriptions';
import { startAnalytics } from '@/lib/analytics';
import { registerAdminPush, registerUserPush } from '@/lib/pushNotifications';

type AuthView = 'login' | 'signup' | 'premium-warning' | null;

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; message: string }
> {
  state = { hasError: false, message: '' };

  static getDerivedStateFromError(error: unknown) {
    return {
      hasError: true,
      message: error instanceof Error ? error.message : 'Bilinmeyen bir hata oluştu.',
    };
  }

  componentDidCatch(error: unknown) {
    console.error('Döndü Teyze ekran hatası:', error);
  }

  handleRetry = () => {
    this.setState({ hasError: false, message: '' });
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <div className="min-h-screen bg-[#09031a] px-6 py-16 text-center text-mystic-100">
        <div className="mx-auto max-w-sm rounded-3xl border border-gold-400/30 bg-night-800/90 p-6">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/20 text-3xl">🔮</div>
          <h2 className="font-display text-xl font-semibold text-gold-100">Döndü Teyze hazırlanıyor</h2>
          <p className="mt-3 text-sm text-mystic-300">Ekran yüklenirken küçük bir sorun oluştu. Tekrar deneyelim.</p>
          <button onClick={this.handleRetry} className="mt-5 w-full rounded-xl border border-gold-400/40 bg-gold-700/30 px-4 py-3 font-semibold text-gold-100">Tekrar Dene</button>
          <button onClick={() => { localStorage.removeItem('fal_profile'); window.location.reload(); }} className="mt-2 w-full rounded-xl border border-mystic-700/50 px-4 py-3 text-sm text-mystic-300">Bilgilerimi yeniden gir</button>
          {this.state.message && <p className="mt-4 break-words text-[10px] text-mystic-600">{this.state.message}</p>}
        </div>
      </div>
    );
  }
}

function App() {
  // IMPORTANT: initialize every state value before any effect references it.
  // Referencing isAdminRoute from a hook dependency before its const declaration
  // triggers the JavaScript temporal-dead-zone error:
  // "Cannot access 'isAdminRoute' before initialization".
  const [profile, setProfile] = useState<UserProfile | null>(() => loadProfile());
  const [activeTab, setActiveTab] = useState<NavTabId>('home');
  const [isAdminRoute, setIsAdminRoute] = useState(() => window.location.pathname === '/admin');
  const [authUser, setAuthUser] = useState<AuthUser | null>(() => getStoredAuth());
  const [authView, setAuthView] = useState<AuthView>(null);
  const [supportOpen, setSupportOpen] = useState(false);
  const [coffeeFortuneOpen, setCoffeeFortuneOpen] = useState(false);
  const [palmFortuneOpen, setPalmFortuneOpen] = useState(false);
  const [tarotFortuneOpen, setTarotFortuneOpen] = useState(false);
  const [katinaFortuneOpen, setKatinaFortuneOpen] = useState(false);
  const [faceFortuneOpen, setFaceFortuneOpen] = useState(false);
  const [dreamFortuneOpen, setDreamFortuneOpen] = useState(false);
  const [wheelOpen, setWheelOpen] = useState(false);
  const [diceOpen, setDiceOpen] = useState(false);
  const [lotteryOpen, setLotteryOpen] = useState(false);
  const [starFortuneOpen, setStarFortuneOpen] = useState(false);
  const [waterFortuneOpen, setWaterFortuneOpen] = useState(false);
  const [angelCardsFortuneOpen, setAngelCardsFortuneOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatCounselor, setChatCounselor] = useState<string | undefined>(undefined);
  const [diaryOpen, setDiaryOpen] = useState(false);
  const [nightGameOpen, setNightGameOpen] = useState(false);
  const [myWorldOpen, setMyWorldOpen] = useState(false);
  const [fortuneTellerOpen, setFortuneTellerOpen] = useState(false);
  const [interstitialOpen, setInterstitialOpen] = useState(false);
  const [pendingNav, setPendingNav] = useState<(() => void) | null>(null);
  const fortuneOpen = coffeeFortuneOpen || palmFortuneOpen || tarotFortuneOpen || katinaFortuneOpen || faceFortuneOpen || dreamFortuneOpen || wheelOpen || diceOpen || lotteryOpen || starFortuneOpen || waterFortuneOpen || angelCardsFortuneOpen || chatOpen || diaryOpen || nightGameOpen || myWorldOpen || fortuneTellerOpen;

  useEffect(() => { startAnalytics(); }, []);
  useEffect(() => {
    if (!isAdminRoute && authUser) {
      void registerUserPush(authUser.id);
    }
  }, [isAdminRoute, authUser?.id]);

  useEffect(() => {
    let listener: { remove: () => Promise<void> } | null = null;
    const processUrl = async (url?: string) => {
      if (!url || !url.startsWith('com.donduteyze.app://auth/callback')) return;
      const result = await handleOAuthCallback(url);
      if (result.user) {
        setAuthUser(result.user);
        setAuthView(null);
      } else if (result.error) {
        console.error(result.error);
      }
    };
    CapacitorApp.getLaunchUrl().then(({ url }) => processUrl(url));
    CapacitorApp.addListener('appUrlOpen', ({ url }) => processUrl(url)).then((handle) => { listener = handle; });
    return () => { listener?.remove(); };
  }, []);

  useEffect(() => {
    if (!hasSupabaseConfig) return;

    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      (async () => {
        if (event === 'SIGNED_IN' && session?.user) {
          const user: AuthUser = { id: session.user.id, email: session.user.email || '' };
          localStorage.setItem('donduteyze_auth_user', JSON.stringify(user));
          setAuthUser(user);
          setAuthView(null);
          syncCreditsFromSubscription(user);
        } else if (event === 'SIGNED_OUT') {
          clearStoredAuth();
          setAuthUser(null);
        }
      })();
    });
    return () => data.subscription.unsubscribe();
  }, []);

  const handleSignOut = () => {
    clearStoredAuth();
    if (hasSupabaseConfig) {
      supabase.auth.signOut();
    }
    setAuthUser(null);
  };

  const openFortuneWithAd = (openFn: () => void) => {
    if (!isAdFree() && shouldShowInterstitial()) {
      setPendingNav(() => openFn);
      setInterstitialOpen(true);
    } else {
      openFn();
    }
  };

  const handleInterstitialClose = () => {
    setInterstitialOpen(false);
    if (pendingNav) {
      pendingNav();
      setPendingNav(null);
    }
  };

  const authScreenActive = authView !== null;

  if (authScreenActive && !isAdminRoute) {
    return (
      <>
        {authView === 'premium-warning' && (
          <AuthPage
            mode="signup"
            reasonText="Aldığınız krediyi saklayabilmek ve cihaz değiştirdiğinizde kaybetmemek için bir hesap oluşturmanız gerekiyor. Hesabınızla kredileriniz güvende kalır."
            showLegal
            onSuccess={() => { setAuthView(null); setActiveTab('premium'); }}
            onSwitchMode={(m) => setAuthView(m)}
            onBack={() => setAuthView(null)}
          />
        )}
        {authView === 'login' && (
          <AuthPage
            mode="login"
            compact
            topAligned
            showLegal
            onSuccess={() => setAuthView(null)}
            onSwitchMode={(m) => setAuthView(m)}
            onBack={() => setAuthView(null)}
          />
        )}
        {authView === 'signup' && (
          <AuthPage
            mode="signup"
            compact
            topAligned
            showLegal
            onSuccess={() => setAuthView(null)}
            onSwitchMode={(m) => setAuthView(m)}
            onBack={() => setAuthView(null)}
          />
        )}
      </>
    );
  }

  if (isAdminRoute) {
    return <AdminPanel />;
  }

  if (!profile) {
    return <OnboardingPage onComplete={setProfile} />;
  }

  let page;
  if (coffeeFortuneOpen) {
    page = <CoffeeFortunePage onNavigate={(tab) => { setCoffeeFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (palmFortuneOpen) {
    page = <PalmFortunePage onNavigate={(tab) => { setPalmFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (tarotFortuneOpen) {
    page = <TarotFortunePage onNavigate={(tab) => { setTarotFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (katinaFortuneOpen) {
    page = <KatinaFortunePage onNavigate={(tab) => { setKatinaFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (faceFortuneOpen) {
    page = <FaceFortunePage onNavigate={(tab) => { setFaceFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (dreamFortuneOpen) {
    page = <DreamFortunePage onNavigate={(tab) => { setDreamFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (wheelOpen) {
    page = <WheelFortunePage onNavigate={(tab) => { setWheelOpen(false); setActiveTab(tab); }} />;
  } else if (diceOpen) {
    page = <DiceFortunePage onNavigate={(tab) => { setDiceOpen(false); setActiveTab(tab); }} />;
  } else if (lotteryOpen) {
    page = <LotteryPage onNavigate={(tab) => { setLotteryOpen(false); setActiveTab(tab); }} />;
  } else if (starFortuneOpen) {
    page = <StarFortunePage onNavigate={(tab) => { setStarFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (waterFortuneOpen) {
    page = <WaterFortunePage onNavigate={(tab) => { setWaterFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (angelCardsFortuneOpen) {
    page = <AngelCardsFortunePage onNavigate={(tab) => { setAngelCardsFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (diaryOpen) {
    page = <DiaryPage onNavigate={(tab) => { setDiaryOpen(false); setActiveTab(tab); }} />;
  } else if (myWorldOpen) {
    page = <MyWorldPage onNavigate={(tab) => { setMyWorldOpen(false); setActiveTab(tab); }} />;
  } else if (fortuneTellerOpen) {
    page = <FortuneTellerPage onNavigate={(tab) => { setFortuneTellerOpen(false); setActiveTab(tab); }} onOpenChat={(user, counselor) => { setFortuneTellerOpen(false); setAuthUser(user); setChatCounselor(counselor); setChatOpen(true); }} />;
  } else if (nightGameOpen) {
    page = <NightGamePage onNavigate={(tab) => { setNightGameOpen(false); setActiveTab(tab); }} />;
  } else if (chatOpen) {
    page = (
      <LiveChatPage onNavigate={(tab) => { setChatOpen(false); setChatCounselor(undefined); setActiveTab(tab); }} authUser={authUser!} counselorName={chatCounselor} />
    );
  } else {
  switch (activeTab) {
    case 'home':
      page = <HomePage profile={profile} onNavigate={setActiveTab} onOpenCoffeeFortune={() => openFortuneWithAd(() => setCoffeeFortuneOpen(true))} onOpenPalmFortune={() => openFortuneWithAd(() => setPalmFortuneOpen(true))} onOpenTarotFortune={() => openFortuneWithAd(() => setTarotFortuneOpen(true))} onOpenKatinaFortune={() => openFortuneWithAd(() => setKatinaFortuneOpen(true))} onOpenFaceFortune={() => openFortuneWithAd(() => setFaceFortuneOpen(true))} onOpenDreamFortune={() => openFortuneWithAd(() => setDreamFortuneOpen(true))} onOpenWheel={() => openFortuneWithAd(() => setWheelOpen(true))} onOpenDice={() => openFortuneWithAd(() => setDiceOpen(true))} onOpenLottery={() => openFortuneWithAd(() => setLotteryOpen(true))} onOpenStarFortune={() => openFortuneWithAd(() => setStarFortuneOpen(true))} onOpenWaterFortune={() => openFortuneWithAd(() => setWaterFortuneOpen(true))} onOpenAngelCards={() => openFortuneWithAd(() => setAngelCardsFortuneOpen(true))} onOpenLiveChat={() => setFortuneTellerOpen(true)} onOpenDiary={() => setDiaryOpen(true)} onOpenNightGame={() => setNightGameOpen(true)} onOpenMyWorld={() => setMyWorldOpen(true)} />;
      break;
    case 'earn':
      page = <EarnPage onNavigate={setActiveTab} />;
      break;
    case 'history':
      page = <HistoryPage onNavigate={setActiveTab} />;
      break;
    case 'zodiac':
      page = <ZodiacPage userZodiac={profile.zodiac} />;
      break;
    case 'support':
      page = <HomePage profile={profile} onNavigate={setActiveTab} onOpenCoffeeFortune={() => openFortuneWithAd(() => setCoffeeFortuneOpen(true))} onOpenPalmFortune={() => openFortuneWithAd(() => setPalmFortuneOpen(true))} onOpenTarotFortune={() => openFortuneWithAd(() => setTarotFortuneOpen(true))} onOpenKatinaFortune={() => openFortuneWithAd(() => setKatinaFortuneOpen(true))} onOpenFaceFortune={() => openFortuneWithAd(() => setFaceFortuneOpen(true))} onOpenDreamFortune={() => openFortuneWithAd(() => setDreamFortuneOpen(true))} onOpenWheel={() => openFortuneWithAd(() => setWheelOpen(true))} onOpenDice={() => openFortuneWithAd(() => setDiceOpen(true))} onOpenLottery={() => openFortuneWithAd(() => setLotteryOpen(true))} onOpenStarFortune={() => openFortuneWithAd(() => setStarFortuneOpen(true))} onOpenWaterFortune={() => openFortuneWithAd(() => setWaterFortuneOpen(true))} onOpenAngelCards={() => openFortuneWithAd(() => setAngelCardsFortuneOpen(true))} onOpenLiveChat={() => setFortuneTellerOpen(true)} onOpenDiary={() => setDiaryOpen(true)} onOpenNightGame={() => setNightGameOpen(true)} onOpenMyWorld={() => setMyWorldOpen(true)} />;
      break;
    case 'premium':
      page = <PremiumPage onNavigate={setActiveTab} onRequireAuth={() => setAuthView('premium-warning')} onOpenLogin={() => setAuthView('login')} isLoggedIn={!!authUser} authUser={authUser} />;
      break;
    default:
      page = <HomePage profile={profile} onNavigate={setActiveTab} onOpenCoffeeFortune={() => openFortuneWithAd(() => setCoffeeFortuneOpen(true))} onOpenPalmFortune={() => openFortuneWithAd(() => setPalmFortuneOpen(true))} onOpenTarotFortune={() => openFortuneWithAd(() => setTarotFortuneOpen(true))} onOpenKatinaFortune={() => openFortuneWithAd(() => setKatinaFortuneOpen(true))} onOpenFaceFortune={() => openFortuneWithAd(() => setFaceFortuneOpen(true))} onOpenDreamFortune={() => openFortuneWithAd(() => setDreamFortuneOpen(true))} onOpenWheel={() => openFortuneWithAd(() => setWheelOpen(true))} onOpenDice={() => openFortuneWithAd(() => setDiceOpen(true))} onOpenLottery={() => openFortuneWithAd(() => setLotteryOpen(true))} onOpenStarFortune={() => openFortuneWithAd(() => setStarFortuneOpen(true))} onOpenWaterFortune={() => openFortuneWithAd(() => setWaterFortuneOpen(true))} onOpenAngelCards={() => openFortuneWithAd(() => setAngelCardsFortuneOpen(true))} onOpenLiveChat={() => setFortuneTellerOpen(true)} onOpenDiary={() => setDiaryOpen(true)} onOpenNightGame={() => setNightGameOpen(true)} onOpenMyWorld={() => setMyWorldOpen(true)} />;
  }
  }

  return (
    <AppErrorBoundary>
      <>
      <CreditHeader
        onNavigate={setActiveTab}
        onAdminAccess={() => setIsAdminRoute(true)}
        authUser={authUser}
        onAuthClick={() => setAuthView(authUser ? null : 'login')}
        onSignOut={handleSignOut}
      />
      <div className="reference-theme">
        {page}
      </div>
      {!fortuneOpen && <FloatingFortuneButton onClick={() => setFortuneTellerOpen(true)} />}
      <BottomNavBar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onSupportClick={() => { setSupportOpen(true); }}
      />
      <SupportModal open={supportOpen} onClose={() => setSupportOpen(false)} />
      <InterstitialAd open={interstitialOpen} onClose={handleInterstitialClose} />
      </>
    </AppErrorBoundary>
  );
}

export default App;
