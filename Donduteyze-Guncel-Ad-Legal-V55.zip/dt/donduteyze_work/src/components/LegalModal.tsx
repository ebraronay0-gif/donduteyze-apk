import { X, FileText, Shield } from 'lucide-react';

export type LegalType = 'privacy' | 'user-agreement';
interface LegalModalProps { type: LegalType | null; onClose: () => void; }

const CONTENT: Record<LegalType, { title: string; icon: typeof FileText; intro: string; sections: Array<{ heading: string; paragraphs: string[] }> }> = {
  privacy: {
    title: 'Gizlilik Politikası / Sözleşmesi',
    icon: Shield,
    intro: 'Son Güncelleme Tarihi: 28 Ağustos 2026',
    sections: [
      { heading: '', paragraphs: [
        'Döndü Teyze ("Uygulama") olarak gizliliğinize saygı duyuyor ve kişisel verilerinizin güvenliğini önemsiyoruz. Bu Gizlilik Politikası, uygulamamızı kullandığınızda verilerinizin nasıl toplandığını, kullanıldığını ve korunduğunu açıklar.'
      ]},
      { heading: '1. Toplanan Veriler ve Kullanım Amacı', paragraphs: [
        'Hesap Bilgileri: Uygulama içi işlemler veya profil oluşturma için sağladığınız kullanıcı adı ve e-posta adresiniz.',
        'Fal Verileri: Fal yorumu alabilmek amacıyla girdiğiniz metinler, sorular veya tercihler. Bu veriler yalnızca sizlere fal içeriği üretmek amacıyla işlenir.',
        'Çerezler ve Analitik Veriler: Uygulama performansını artırmak, hataları gidermek ve kullanıcı deneyimini iyileştirmek amacıyla Google Play Services ve analitik araçları vasıtasıyla anonim kullanım verileri toplanabilir.'
      ]},
      { heading: '2. Verilerin Saklanması ve Güvenliği', paragraphs: ['Toplanan verileriniz şifreli sunucularda güvenle saklanır. Yasal zorunluluklar haricinde kişisel verileriniz asla üçüncü şahıslarla paylaşılmaz veya satılmaz.'] },
      { heading: '3. Uluslararası Kullanıcılar ve GDPR Uyumluluğu (Yurt Dışı)', paragraphs: ['Avrupa Birliği (AB) sınırları içerisinden uygulamamızı kullanan kullanıcılar için Genel Veri Koruma Yönetmeliği (GDPR) ilkelerine uyulmaktadır. Kullanıcılar diledikleri zaman verilerine erişme, verilerinin silinmesini veya güncellenmesini talep etme hakkına sahiptir.'] },
      { heading: '4. KVKK Aydınlatma Metni (Türkiye)', paragraphs: ['6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca, kişisel verileriniz veri sorumlusu sıfatıyla uygulama yönetimi tarafından işlenmektedir. Detaylı haklarınız için bizimle iletişime geçebilirsiniz.'] },
    ],
  },
  'user-agreement': {
    title: 'Kullanıcı Sözleşmesi ve Kullanım Şartları',
    icon: FileText,
    intro: 'Son Güncelleme Tarihi: 28 Ağustos 2026',
    sections: [
      { heading: '', paragraphs: ['Döndü Teyze uygulamasını indirerek ve kullanarak aşağıdaki şartları ve koşulları eksiksiz kabul etmiş sayılırsınız. Bu şartları kabul etmiyorsanız lütfen uygulamayı kullanmayın.'] },
      { heading: '1. Eğlence Amacı ve Sorumluluk Reddi (Çok Önemli - Google Play Şartı)', paragraphs: [
        'Uygulama içerisindeki tüm fallar (kahve falı, tarot, astroloji vb.) ve yorumlar yalnızca ve tamamen eğlence ve keyif amaçlıdır.',
        'Sunulan içeriklerin hiçbir bilimsel, resmi veya hukuki geçerliliği yoktur. Geleceğe yönelik öngörüler, tavsiyeler veya tahminler kesinlik içermez.',
        'Kullanıcılar; bu uygulamadaki içeriklere dayanarak finansal, hukuki, tıbbi veya hayati kararlar alamazlar. Alınan kararlardan doğabilecek her türlü sorumluluk tamamen kullanıcının kendisine aittir. Geliştirici hiçbir hukuki ve cezai sorumluluk kabul etmez.'
      ]},
      { heading: '2. Yaş Sınırı', paragraphs: ['Uygulamamız 18 yaş ve üzeri kullanıcılar için tasarlanmıştır. 18 yaşından küçüklerin uygulamayı kullanması yasaktır.'] },
      { heading: '3. Abonelik, Kredi ve Ödemeler', paragraphs: [
        'Uygulama içi satın alımlar (kredi paketleri ve otomatik yenilenen abonelikler) Google Play Faturalandırma Sistemi üzerinden gerçekleştirilir.',
        'Haftalık, aylık veya yıllık abonelikler, iptal edilmediği sürece dönemin sonunda otomatik olarak yenilenir. Aboneliğinizi dilediğiniz zaman Google Play Hesap Ayarları üzerinden yönetebilir veya iptal edebilirsiniz.',
        'Satın alınan dijital içeriklerin ve kredilerin iadesi Google Play İade Politikaları çerçevesinde değerlendirilir.'
      ]},
      { heading: '4. Fikri Mülkiyet Hakları', paragraphs: ['Döndü Teyze uygulamasının tasarımı, arayüzü, logoları, metinleri, görselleri ve yazılım altyapısı üzerindeki tüm haklar saklıdır. İzinsiz kopyalanamaz, çoğaltılamaz veya ticari amaçla kullanılamaz.'] },
      { heading: 'İletişim', paragraphs: ['Hukuki talepleriniz, soru ve önerileriniz için uygulama içi destek bölümünden veya donduteyze00@outlook.com üzerinden bizimle iletişime geçebilirsiniz.'] },
    ],
  },
};

export default function LegalModal({ type, onClose }: LegalModalProps) {
  if (!type) return null;
  const item = CONTENT[type];
  const Icon = item.icon;
  return <div className="fixed inset-0 z-[120] flex items-center justify-center bg-night-950/90 p-4 backdrop-blur-sm" onClick={onClose}>
    <div className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-gold-400/30 bg-night-800 p-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
      <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><Icon className="h-5 w-5 text-gold-300" /><h2 className="font-display text-xl font-semibold text-gold-100">{item.title}</h2></div><button onClick={onClose} aria-label="Kapat" className="rounded-lg p-2 text-mystic-400 hover:text-mystic-100"><X className="h-5 w-5" /></button></div>
      <div className="mb-4 rounded-xl border border-gold-400/20 bg-gold-950/15 p-3 text-xs font-semibold leading-5 text-gold-100/85">{item.intro}</div>
      <div className="space-y-5 text-sm leading-7 text-mystic-200">
        {item.sections.map((section, i) => <section key={i} className={section.heading ? 'border-t border-mystic-700/40 pt-4' : ''}>
          {section.heading && <h3 className="mb-2 font-display text-base font-semibold text-gold-200">{section.heading}</h3>}
          <div className="space-y-2">{section.paragraphs.map((p, j) => <p key={j}>{p}</p>)}</div>
        </section>)}
      </div>
      <button onClick={onClose} className="mt-6 w-full rounded-xl border border-gold-400/40 bg-gold-900/20 px-4 py-3 text-sm font-semibold text-gold-200">Kapat</button>
    </div>
  </div>;
}
