import { useEffect, useState } from 'react';
import { Check, Shield, UserCheck } from 'lucide-react';
import LegalModal, { type LegalType } from '@/components/LegalModal';

interface LegalAcceptanceProps {
  onValidityChange?: (valid: boolean) => void;
  compact?: boolean;
}

export default function LegalAcceptance({ onValidityChange, compact = false }: LegalAcceptanceProps) {
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const [userAgreementAccepted, setUserAgreementAccepted] = useState(false);
  const [legalType, setLegalType] = useState<LegalType | null>(null);
  const valid = privacyAccepted && userAgreementAccepted;

  useEffect(() => { onValidityChange?.(valid); }, [valid, onValidityChange]);

  return <>
    <div className={`space-y-2 rounded-xl border border-mystic-700/40 bg-night-900/35 ${compact ? 'p-3' : 'p-4'}`}>
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-[.14em] text-gold-300/80">Sözleşmeler ve gizlilik</p>

      <div className="flex items-start gap-2">
        <button type="button" aria-pressed={privacyAccepted} onClick={() => setPrivacyAccepted(v => !v)} className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${privacyAccepted ? 'border-gold-400 bg-gold-400/20 text-gold-300' : 'border-mystic-600 bg-night-700/60'}`}>
          {privacyAccepted && <Check className="h-3.5 w-3.5" />}
        </button>
        <div className="text-xs leading-5 text-mystic-300">
          <button type="button" onClick={() => setLegalType('privacy')} className="inline-flex items-center gap-1 text-gold-200 underline-offset-2 hover:underline"><Shield className="h-3 w-3" />Gizlilik Politikası / Sözleşmesi</button> <span>metnini okudum.</span>
        </div>
      </div>

      <div className="flex items-start gap-2">
        <button type="button" aria-pressed={userAgreementAccepted} onClick={() => setUserAgreementAccepted(v => !v)} className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${userAgreementAccepted ? 'border-gold-400 bg-gold-400/20 text-gold-300' : 'border-mystic-600 bg-night-700/60'}`}>
          {userAgreementAccepted && <Check className="h-3.5 w-3.5" />}
        </button>
        <div className="text-xs leading-5 text-mystic-300">
          <button type="button" onClick={() => setLegalType('user-agreement')} className="inline-flex items-center gap-1 text-gold-200 underline-offset-2 hover:underline"><UserCheck className="h-3 w-3" />Kullanıcı Sözleşmesi ve Kullanım Şartları</button> <span>metnini okudum ve kabul ediyorum.</span>
        </div>
      </div>

      {!valid && <p className="pt-1 text-[10px] text-amber-200/60">Devam etmek için iki metni de açıp ilgili kutucukları işaretleyin.</p>}
    </div>
    <LegalModal type={legalType} onClose={() => setLegalType(null)} />
  </>;
}
