import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

class RootErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; message: string }
> {
  state = { hasError: false, message: '' };

  static getDerivedStateFromError(error: unknown) {
    return {
      hasError: true,
      message: error instanceof Error ? error.message : 'Uygulama yüklenirken bilinmeyen bir hata oluştu.',
    };
  }

  componentDidCatch(error: unknown) {
    console.error('Döndü Teyze başlangıç hatası:', error);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <main className="dz-boot-error">
        <div className="dz-boot-card">
          <div className="dz-boot-orb">🔮</div>
          <h1>Döndü Teyze</h1>
          <p>Uygulama açılırken küçük bir sorun oluştu.</p>
          <button onClick={() => window.location.reload()}>Tekrar Dene</button>
          <small>{this.state.message}</small>
        </div>
      </main>
    );
  }
}

// Render the React tree first. Native services such as AdMob/analytics are
// deliberately initialized after the first frame so a native plugin failure
// can never leave the WebView on a black screen.
const root = document.getElementById('root');
if (!root) throw new Error('Uygulama kökü bulunamadı.');

createRoot(root).render(
  <RootErrorBoundary>
    <App />
  </RootErrorBoundary>,
);

requestAnimationFrame(() => {
  document.documentElement.classList.add('app-mounted');
  document.getElementById('dz-boot')?.remove();

  void import('./lib/ads')
    .then(({ ensureAdMobInitialized }) => ensureAdMobInitialized())
    .catch((error) => console.warn('AdMob başlangıç uyarısı:', error));
});
