import { useMemo, useState } from 'react';
import { ArrowLeft, Star, Heart, ShieldCheck, Lock, Sparkles, Crown, Gem, MessageCircle, Check, ChevronRight, Clock3, Award, Send } from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import { getCredits, spendCredits } from '@/lib/credits';
import { FORTUNE_TELLER_PRICE, purchaseChatSession } from '@/lib/liveChat';
import { hasSupabaseConfig, supabase } from '@/lib/supabase';
import type { AuthUser } from '@/lib/auth';

interface Props { onNavigate: (tab: NavTabId) => void; onOpenChat: (user: AuthUser, counselor: string) => void; }

type Teller = {
  name: string; quote: string; rating: string; reviews: string; specialty: string[]; avatar: string; expert?: boolean; experience: string; success: string;
};

const TELLERS: Teller[] = [
  { name: 'Aliye Teyze', quote: 'Gönlünden geçenleri bilirim.', rating: '4.9', reviews: '12.458', specialty: ['Kahve Falı', 'Tarot', 'Katina'], avatar: '/teller-aliye-3d.png', experience: '30+ Yıl', success: '%97' },
  { name: 'Sultan Teyze', quote: 'Kaderini birlikte aydınlatalım.', rating: '4.8', reviews: '9.876', specialty: ['Tarot', 'Katina', 'Rüya Yorumu'], avatar: '/teller-sultan-3d.png', experience: '30+ Yıl', success: '%98' },
  { name: 'Yasemen Bacı', quote: 'İçindeki sesi duymana yardım ederim.', rating: '4.7', reviews: '11.203', specialty: ['Kahve Falı', 'El Falı', 'Yüz Falı'], avatar: '/teller-yasemen-3d.png', experience: '25+ Yıl', success: '%96' },
  { name: 'Döndü Teyze', quote: 'Hayatın sırlarını birlikte çözelim.', rating: '5.0', reviews: '15.692', specialty: ['Kahve Falı', 'Tarot', 'Katina'], avatar: '/teller-dondu-3d.png', expert: true, experience: '35+ Yıl', success: '%99' },
];

async function getOrCreateGuest(): Promise<AuthUser | null> {
  const { data } = await supabase.auth.getSession();
  if (data.session?.user) return { id: data.session.user.id, email: data.session.user.email || '' };
  const { data: anon, error } = await supabase.auth.signInAnonymously();
  if (error || !anon.user) return null;
  return { id: anon.user.id, email: anon.user.email || '' };
}

function FortuneTellerPage({ onNavigate, onOpenChat }: Props) {
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [done, setDone] = useState('');
  const [selected, setSelected] = useState<string>('Sultan Teyze');
  const [filter, setFilter] = useState('Tümü');

  const selectedTeller = useMemo(() => TELLERS.find(t => t.name === selected) || TELLERS[1], [selected]);
  const visibleTellers = useMemo(() => {
    if (filter === 'Tümü') return TELLERS;
    if (filter === 'Popüler') return [...TELLERS].sort((a, b) => Number(b.rating) - Number(a.rating));
    if (filter === 'En Çok Beğenilen') return [...TELLERS].sort((a, b) => Number(b.reviews.replace('.', '')) - Number(a.reviews.replace('.', '')));
    return TELLERS.slice().reverse();
  }, [filter]);

  const choose = async (name: string) => {
    if (busy) return;
    setSelected(name);
    setError('');
    if (getCredits() < FORTUNE_TELLER_PRICE) { setError(`Bu falcıyla görüşmek için ${FORTUNE_TELLER_PRICE} kredi gerekiyor.`); return; }
    if (!hasSupabaseConfig) { setError('Falcı mesajlaşma sunucusu şu anda yapılandırılmamış.'); return; }
    setBusy(name);
    const buyer = await getOrCreateGuest();
    if (!buyer) { setBusy(null); setError('Mesajlaşma bağlantısı kurulamadı. Lütfen tekrar deneyin.'); return; }
    const result = spendCredits(FORTUNE_TELLER_PRICE);
    if (!result.success) { setBusy(null); setError('Yeterli krediniz yok.'); return; }
    const session = await purchaseChatSession(buyer, name);
    if (!session) {
      const { addCredits } = await import('@/lib/credits');
      addCredits(FORTUNE_TELLER_PRICE);
      setBusy(null);
      setError('Falcı sohbeti oluşturulamadı; krediniz iade edildi.');
      return;
    }
    setDone(name);
    setBusy(null);
    window.dispatchEvent(new Event('credits-updated'));
    setTimeout(() => onOpenChat(buyer, name), 450);
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#05020b] pb-28 text-white">
      <StarField count={85} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_15%_8%,rgba(126,34,206,.26),transparent_25%),radial-gradient(circle_at_88%_20%,rgba(245,158,11,.12),transparent_22%),linear-gradient(180deg,#05020b,#10031d_42%,#07020d)]" />

      <div className="relative z-10 mx-auto max-w-3xl px-3 pb-10 pt-3">
        <header className="mb-3 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-gold-300/70 bg-black/45 text-gold-200 shadow-[0_0_25px_rgba(168,85,247,.2)]"><ArrowLeft className="h-5 w-5" /></button>
          <div className="flex-1 text-center">
            <p className="font-display text-[13px] tracking-[.18em] text-gold-200">FALCILARIMIZA</p>
            <h1 className="font-display text-[30px] leading-none text-gold-300 drop-shadow-[0_0_16px_rgba(245,158,11,.35)]">FAL BAKTIR</h1>
          </div>
          <div className="rounded-full border border-gold-300/60 bg-[#190622]/90 px-3 py-2 text-sm text-gold-100 shadow-[0_0_20px_rgba(168,85,247,.16)]">✦ {getCredits()} <span className="text-gold-300/70">Kredi</span></div>
        </header>

        <section className="relative mb-4 overflow-hidden rounded-[30px] border border-gold-300/35 bg-[linear-gradient(135deg,rgba(46,10,74,.95),rgba(10,2,18,.98))] p-4 shadow-[0_24px_70px_rgba(0,0,0,.6)]">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_12%_70%,rgba(168,85,247,.25),transparent_30%),radial-gradient(circle_at_80%_20%,rgba(251,191,36,.12),transparent_22%)]" />
          <div className="relative grid grid-cols-[92px_1fr] items-center gap-4 sm:grid-cols-[125px_1fr]">
            <div className="relative h-28 w-24 overflow-hidden rounded-[24px] border border-gold-300/60 bg-black/40 shadow-[0_15px_35px_rgba(0,0,0,.55)] sm:h-32 sm:w-28">
              <img src="/teller-dondu-3d.png" alt="Döndü Teyze" className="h-full w-full object-cover object-top" />
            </div>
            <div>
              <p className="text-center text-[12px] leading-5 text-mystic-200 sm:text-left">Döndü Teyze'nin seçkin falcılarıyla özel olarak falına baktır, merak ettiğin soruların cevaplarını öğren.</p>
              <div className="mt-3 rounded-2xl border border-gold-300/20 bg-black/25 px-3 py-2 text-center text-[11px] text-gold-100"><span className="text-gold-300">✦</span> Falcılarımız gerçek yorumcularımızdır. <span className="text-gold-300">Falı senin adına onlar bakar.</span></div>
            </div>
          </div>
        </section>

        <div className="mb-4 grid grid-cols-4 gap-1 rounded-full border border-gold-300/20 bg-[#13051e]/90 p-1">
          {['Tümü', 'Popüler', 'En Çok Beğenilen', 'Yeni'].map(x => <button key={x} onClick={() => setFilter(x)} className={`rounded-full px-2 py-2 text-[10px] transition ${filter === x ? 'bg-gradient-to-r from-amber-400 to-yellow-500 font-bold text-[#261000] shadow-[0_0_20px_rgba(245,158,11,.25)]' : 'text-mystic-200 hover:bg-white/5'}`}>{x}</button>)}
        </div>

        {error && <div className="mb-3 rounded-2xl border border-rose-400/30 bg-rose-950/40 p-3 text-center text-xs text-rose-200">{error}</div>}

        <div className="mb-2 flex items-end justify-between px-1">
          <div><p className="text-[9px] uppercase tracking-[.3em] text-gold-300/65">Canlı yorumcular</p><h2 className="font-display text-xl text-gold-100">Sana uygun falcıyı seç</h2></div>
          <span className="rounded-full border border-gold-300/20 bg-purple-950/60 px-3 py-1 text-[9px] text-gold-200">{TELLERS.length} yorumcu</span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {visibleTellers.map(t => (
            <button key={t.name} onClick={() => setSelected(t.name)} className={`group relative overflow-hidden rounded-[24px] border text-left transition duration-300 ${selected === t.name ? 'border-gold-300 shadow-[0_0_28px_rgba(245,158,11,.22)]' : 'border-gold-300/25'} bg-gradient-to-b from-[#2b0b46] to-[#0d0318] p-2`}>
              <div className="relative aspect-[.92] overflow-hidden rounded-[19px] border border-gold-300/30 bg-black/30">
                <img src={t.avatar} alt={t.name} className="h-full w-full object-cover object-top transition duration-300 group-hover:scale-[1.025]" />
                <span className="absolute left-2 top-2 rounded-full border border-emerald-300/20 bg-black/70 px-2 py-1 text-[8px] text-emerald-300"><span className="mr-1 inline-block h-1.5 w-1.5 rounded-full bg-emerald-400" />Çevrimiçi</span>
                <span className="absolute right-2 top-2 grid h-7 w-7 place-items-center rounded-full border border-gold-300/30 bg-black/55 text-pink-300"><Heart className="h-3.5 w-3.5" /></span>
              </div>
              <div className="px-1.5 pb-1.5 pt-2">
                <div className="flex items-center justify-between gap-1"><h3 className="font-display text-[15px] text-gold-100">{t.name}</h3><span className="flex items-center gap-0.5 text-[9px] text-gold-200"><Star className="h-3 w-3 fill-gold-300 text-gold-300" />{t.rating}</span></div>
                <p className="mt-0.5 text-[8px] text-mystic-400">{t.reviews} yorum</p>
                <div className="mt-2 flex flex-wrap gap-1">{t.specialty.slice(0,3).map(s => <span key={s} className="rounded-full border border-violet-300/20 bg-violet-500/10 px-1.5 py-1 text-[7px] text-violet-100">{s}</span>)}</div>
                <div className="mt-2 rounded-xl border border-violet-300/30 bg-gradient-to-r from-violet-900/80 to-purple-700/70 py-2 text-center font-display text-[11px] text-gold-100">✦ {FORTUNE_TELLER_PRICE} KREDİ</div>
              </div>
            </button>
          ))}
        </div>

        <section className="mt-4 overflow-hidden rounded-[28px] border border-gold-300/35 bg-gradient-to-b from-[#26083e] to-[#0c0217] shadow-[0_25px_70px_rgba(0,0,0,.55)]">
          <div className="grid md:grid-cols-[.9fr_1.1fr]">
            <div className="relative min-h-[330px] overflow-hidden border-b border-gold-300/15 md:border-b-0 md:border-r">
              <img src={selectedTeller.avatar} alt={selectedTeller.name} className="h-full w-full object-cover object-top" />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#09010f] via-[#09010f]/80 to-transparent px-5 pb-5 pt-20">
                <h2 className="font-display text-3xl text-gold-100">{selectedTeller.name}</h2>
                <div className="mt-1 flex items-center gap-2 text-sm text-gold-200"><Star className="h-4 w-4 fill-gold-300 text-gold-300" /> {selectedTeller.rating} <span className="text-white/45">({selectedTeller.reviews})</span><span className="rounded-full bg-emerald-500/15 px-2 py-1 text-[9px] text-emerald-300">● Çevrimiçi</span></div>
              </div>
            </div>
            <div className="p-5">
              <p className="text-center text-sm leading-6 text-mystic-200">{selectedTeller.experience} deneyimiyle, seçtiğin fal türünde sana özel yorum yapmaya hazır.</p>
              <div className="mt-4 border-t border-gold-300/15 pt-4"><p className="mb-3 text-center font-display text-sm tracking-[.18em] text-gold-200">UZMANLIK ALANLARI</p><div className="flex flex-wrap justify-center gap-2">{selectedTeller.specialty.map(s => <span key={s} className="rounded-full border border-gold-300/25 bg-purple-900/45 px-3 py-1.5 text-[9px] text-gold-100">{s}</span>)}</div></div>
              <div className="mt-4 grid grid-cols-3 gap-2">
                <div className="rounded-xl border border-gold-300/15 bg-black/20 p-2 text-center"><Award className="mx-auto h-4 w-4 text-gold-300" /><p className="mt-1 text-[8px] text-mystic-400">Deneyim</p><p className="text-[10px] text-gold-100">{selectedTeller.experience}</p></div>
                <div className="rounded-xl border border-gold-300/15 bg-black/20 p-2 text-center"><MessageCircle className="mx-auto h-4 w-4 text-violet-300" /><p className="mt-1 text-[8px] text-mystic-400">Yorum</p><p className="text-[10px] text-gold-100">{selectedTeller.reviews}</p></div>
                <div className="rounded-xl border border-gold-300/15 bg-black/20 p-2 text-center"><ShieldCheck className="mx-auto h-4 w-4 text-emerald-300" /><p className="mt-1 text-[8px] text-mystic-400">Başarı</p><p className="text-[10px] text-gold-100">{selectedTeller.success}</p></div>
              </div>
              <div className="mt-4 rounded-2xl border border-violet-300/25 bg-black/20 p-4 text-center">
                <p className="text-[9px] uppercase tracking-[.25em] text-gold-300/70">FAL BAKTIRMA BEDELİ</p>
                <p className="mt-1 font-display text-2xl text-gold-100">✦ {FORTUNE_TELLER_PRICE} KREDİ</p>
                <button onClick={() => choose(selectedTeller.name)} disabled={!!busy} className="mt-3 flex w-full items-center justify-center gap-2 rounded-full border border-gold-200/70 bg-gradient-to-r from-amber-400 to-yellow-500 py-3 font-display text-base text-[#281000] shadow-[0_0_28px_rgba(245,158,11,.3)] disabled:opacity-60">{busy === selectedTeller.name ? 'Sohbet açılıyor...' : <><Send className="h-4 w-4" /> FALINA BAKTIR</>}</button>
                <p className="mt-2 flex items-center justify-center gap-1 text-[8px] text-mystic-400"><Lock className="h-3 w-3" /> Falcı görüşmeyi sonlandırana kadar mesajlaşabilirsiniz.</p>
              </div>
            </div>
          </div>
        </section>

        {done && <div className="mt-3 flex items-center justify-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-950/30 p-3 text-xs text-emerald-200"><Check className="h-4 w-4" /> {done} seçildi · {FORTUNE_TELLER_PRICE} kredi harcandı · mesaj kutusu açılıyor</div>}

        <section className="mt-4 rounded-[24px] border border-gold-300/25 bg-[#16051f]/90 p-4">
          <div className="mb-3 flex items-center justify-center gap-2"><Sparkles className="h-4 w-4 text-gold-300" /><h3 className="font-display text-base tracking-[.16em] text-gold-100">NEDEN FALCILARIMIZ?</h3><Sparkles className="h-4 w-4 text-gold-300" /></div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[['Güvenli Hizmet', ShieldCheck, 'Seçkin yorumcular'], ['Gerçek Yorumlar', Sparkles, 'Sana özel yorum'], ['Gizlilik Garantisi', Lock, 'Sohbetler gizli'], ['Memnuniyet Odaklı', Heart, 'Özenli iletişim']].map(([title, Icon, text]) => <div key={title as string} className="rounded-2xl border border-gold-300/10 bg-black/20 p-3 text-center"><Icon className="mx-auto h-5 w-5 text-gold-300" /><p className="mt-1 text-[9px] font-semibold text-gold-100">{title as string}</p><p className="mt-1 text-[8px] leading-3 text-mystic-400">{text as string}</p></div>)}
          </div>
        </section>
        <p className="mt-3 flex items-center justify-center gap-1 text-[8px] text-mystic-500"><ChevronRight className="h-3 w-3" /> Yorumcuların görüşleri tamamen eğlence amaçlıdır.</p>
      </div>
    </div>
  );
}

export default FortuneTellerPage;
