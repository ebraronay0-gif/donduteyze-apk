import { useEffect, useMemo, useState } from 'react';
import { Check, Crown, CreditCard, Loader2, User, X } from 'lucide-react';
import type { NavTabId } from '@/lib/navTabs';
import type { AuthUser } from '@/lib/auth';
import LegalModal, { type LegalType } from '@/components/LegalModal';
import {
  purchasePlan,
  refreshSubscription,
  type PlanId,
  type SubscriptionInfo,
} from '@/lib/subscriptions';

interface PremiumPageProps {
  onNavigate: (tab: NavTabId) => void;
  onRequireAuth?: () => void;
  onOpenLogin?: () => void;
  isLoggedIn?: boolean;
  authUser?: AuthUser | null;
}

interface Offer {
  id: PlanId;
  title: string;
  price: string;
  recurring?: boolean;
}

const CREDIT_PACK: Offer = { id: 'credits250', title: '250 Kredi (Tek Seferlik)', price: '₺149,99' };
const SUBSCRIPTIONS: Offer[] = [
  { id: 'weekly', title: 'Haftalık', price: '₺59,99 / hafta', recurring: true },
  { id: 'monthly', title: 'Aylık', price: '₺129,99 / ay', recurring: true },
  { id: 'yearly', title: 'Yıllık', price: '₺499,99 / yıl', recurring: true },
];
const PLAN_NAMES: Record<string, string> = { weekly: 'Haftalık Üyelik', monthly: 'Aylık Üyelik', yearly: 'Yıllık Üyelik' };

function formatDate(value: string | null) {
  if (!value) return '—';
  return new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(value));
}

/**
 * Premium artwork is intentionally used as the visual base so the production screen
 * stays pixel-faithful to the approved design. Transparent hit areas sit above the
 * artwork and keep the purchase/legal controls accessible.
 */
function PremiumPage({ onNavigate, onOpenLogin, onRequireAuth, authUser }: PremiumPageProps) {
  const [subscription, setSubscription] = useState<SubscriptionInfo | null>(null);
  const [subscriptionOpen, setSubscriptionOpen] = useState(false);
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);
  const [purchasing, setPurchasing] = useState(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);
  const [legalType, setLegalType] = useState<LegalType | null>(null);

  const loadSubscription = async () => setSubscription(await refreshSubscription(authUser ?? null));
  useEffect(() => { loadSubscription(); }, [authUser?.id]);

  const activePlanName = useMemo(
    () => subscription ? (PLAN_NAMES[subscription.plan] || subscription.plan) : 'Aktif abonelik yok',
    [subscription],
  );

  const handleBuy = async (offer: Offer) => {
    setPurchasing(true);
    setPurchaseError(null);
    try {
      const result = await purchasePlan(offer.id, authUser ?? undefined);
      if (!result.success) {
        setPurchaseError(result.error || 'Satın alma başarısız oldu.');
        return;
      }
      setSelectedOffer(offer);
      await loadSubscription();
    } finally {
      setPurchasing(false);
    }
  };

  const daysRemaining = useMemo(() => {
    if (!subscription?.expiresAt) return 0;
    const diff = new Date(subscription.expiresAt).getTime() - Date.now();
    return Math.max(0, Math.ceil(diff / 86400000));
  }, [subscription?.expiresAt]);

  const openGooglePlaySubscriptions = async () => {
    const url = 'https://play.google.com/store/account/subscriptions';
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center overflow-hidden bg-[#07030f] px-1 py-1">
      <div className="relative h-full max-h-[100vh] w-auto max-w-full aspect-[709/1430]">
        <img src="/premium-reference-corrected.jpg" alt="Döndü Teyze Premium" className="absolute inset-0 h-full w-full select-none object-contain" draggable={false} />

        {/* Top controls */}
        <button aria-label="Aboneliğim" onClick={() => setSubscriptionOpen(true)} className="absolute left-[6.8%] top-[5.8%] h-[5.1%] w-[25.5%] rounded-full bg-transparent" />
        <button aria-label="Premium sayfasını kapat" onClick={() => onNavigate('home')} className="absolute right-[6.5%] top-[5.7%] h-[5.3%] w-[9.2%] rounded-full bg-transparent" />

        {/* One-time 250 credit purchase */}
        <button aria-label="250 kredi satın al" onClick={() => handleBuy(CREDIT_PACK)} disabled={purchasing} className="absolute left-[10.2%] top-[49.8%] h-[4.5%] w-[80%] rounded-full bg-transparent disabled:cursor-wait">
          {purchasing && <Loader2 className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 animate-spin text-white" />}
        </button>

        {/* Subscription purchase hit areas */}
        <button aria-label="Haftalık abonelik satın al" onClick={() => handleBuy(SUBSCRIPTIONS[0])} disabled={purchasing} className="absolute left-[8.5%] top-[80.8%] h-[4.4%] w-[25%] rounded-full bg-transparent disabled:cursor-wait" />
        <button aria-label="Aylık abonelik satın al" onClick={() => handleBuy(SUBSCRIPTIONS[1])} disabled={purchasing} className="absolute left-[37.4%] top-[80.8%] h-[4.4%] w-[25%] rounded-full bg-transparent disabled:cursor-wait" />
        <button aria-label="Yıllık abonelik satın al" onClick={() => handleBuy(SUBSCRIPTIONS[2])} disabled={purchasing} className="absolute left-[66.2%] top-[80.8%] h-[4.4%] w-[25%] rounded-full bg-transparent disabled:cursor-wait" />

        {/* Legal links: two approved documents. The footer artwork contains two stacked labels. */}
        <button aria-label="Gizlilik Politikası / Sözleşmesi" onClick={() => setLegalType('privacy')} className="absolute left-[13%] top-[94.7%] h-[2.1%] w-[74%] bg-transparent" />
        <button aria-label="Kullanıcı Sözleşmesi ve Kullanım Şartları" onClick={() => setLegalType('user-agreement')} className="absolute left-[8%] top-[97%] h-[2.1%] w-[84%] bg-transparent" />

        {purchaseError && (
          <div className="absolute left-[8%] right-[8%] top-[86.5%] rounded-xl border border-red-400/50 bg-black/85 px-3 py-2 text-center text-[10px] font-semibold text-red-200 shadow-xl">
            {purchaseError}
          </div>
        )}
      </div>

      {/* My subscription modal */}
      {subscriptionOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 px-4 backdrop-blur-md" onClick={() => setSubscriptionOpen(false)}>
          <div className="w-full max-w-md rounded-3xl border border-amber-400/45 bg-gradient-to-b from-[#21082f] to-[#09030f] p-5 shadow-[0_0_55px_rgba(245,158,11,.18)]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <div><p className="text-[10px] tracking-[.2em] text-amber-300">DÖNDÜ TEYZE</p><h2 className="font-display text-2xl font-bold text-amber-100">Aboneliğim</h2></div>
              <button onClick={() => setSubscriptionOpen(false)} className="rounded-full border border-purple-400/30 p-2 text-purple-200"><X className="h-4 w-4" /></button>
            </div>

            {subscription ? (
              <div className="mt-4 space-y-3">
                <div className="rounded-2xl border border-amber-400/35 bg-amber-500/10 p-4">
                  <div className="flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-full bg-amber-500/15"><Crown className="h-6 w-6 text-amber-300" /></div><div><p className="text-xs text-purple-200/60">Aktif paket</p><p className="font-display text-lg font-bold text-amber-100">{activePlanName}</p></div></div>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-xs"><InfoRow label="Günlük kredi" value={`${subscription.dailyCredits}`} /><InfoRow label="Reklam" value={subscription.adFree ? 'Kapalı' : 'Açık'} /><InfoRow label="Kalan süre" value={`${daysRemaining} gün`} /><InfoRow label="Bitiş tarihi" value={formatDate(subscription.expiresAt)} /></div>
                </div>
                <div className="rounded-2xl border border-purple-400/20 bg-black/20 p-3 text-xs leading-relaxed text-purple-100/75">Aktif abonelik boyunca her gün 20 kredi hesabınıza eklenir ve reklamlar gösterilmez.</div>
                <div className={`rounded-2xl border p-3 text-xs leading-relaxed ${subscription.autoRenew ? 'border-amber-400/25 bg-amber-500/10 text-amber-100' : 'border-emerald-400/25 bg-emerald-500/10 text-emerald-100'}`}>
                  {subscription.autoRenew
                    ? `Otomatik yenileme açık. Aboneliğinizi ${formatDate(subscription.expiresAt)} tarihine kadar kullanabilirsiniz. İptal etmek için Google Play'deki Abonelikler bölümünü kullanın.`
                    : `Otomatik yenileme Google Play üzerinden kapatılmış. Aboneliğiniz ${formatDate(subscription.expiresAt)} tarihinde sona erecek; o tarihe kadar Premium avantajlarınız devam eder.`}
                </div>
                <button onClick={openGooglePlaySubscriptions} className="w-full rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-4 py-3 text-sm font-bold text-[#1a071e] shadow-[0_0_22px_rgba(245,158,11,.22)]">Google Play'de Aboneliği Yönet</button>
                <p className="text-center text-[9px] text-purple-300/50">İptal işlemi uygulama içinde yapılmaz. Google Play'den iptal ederseniz, ödediğiniz mevcut dönem bitene kadar Premium avantajlarınız devam eder.</p>
              </div>
            ) : (
              <div className="mt-6 rounded-2xl border border-purple-400/20 bg-black/20 p-5 text-center">
                <CreditCard className="mx-auto h-9 w-9 text-amber-300" />
                <p className="mt-2 font-semibold text-amber-100">Aktif aboneliğiniz yok</p>
                <p className="mt-1 text-xs text-purple-200/60">Bir abonelik seçerek Premium avantajlarından yararlanabilirsiniz.</p>
                {!authUser && <button onClick={() => { setSubscriptionOpen(false); (onOpenLogin ?? onRequireAuth)?.(); }} className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-5 py-2.5 text-sm font-bold text-[#1a071e]"><User className="h-4 w-4" /> Giriş Yap</button>}
              </div>
            )}
          </div>
        </div>
      )}

      {selectedOffer && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 px-5 backdrop-blur-md" onClick={() => setSelectedOffer(null)}>
          <div className="w-full max-w-sm rounded-3xl border border-amber-400/50 bg-gradient-to-b from-[#21082f] to-[#09030f] p-6 text-center shadow-[0_0_55px_rgba(245,158,11,.2)]" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-amber-400/50 bg-amber-500/10"><Check className="h-8 w-8 text-amber-300" /></div>
            <h2 className="mt-4 font-display text-xl font-bold text-amber-100">Satın Alma Başarılı</h2>
            <p className="mt-2 text-sm text-purple-100/80"><strong className="text-amber-200">{selectedOffer.title}</strong> paketiniz aktifleştirildi.</p>
            {selectedOffer.recurring && <p className="mt-2 text-xs text-purple-200/65">Her gün 20 kredi hesabınıza eklenir ve Premium süresince reklamlar gösterilmez.</p>}
            <button onClick={() => { setSelectedOffer(null); onNavigate('home'); }} className="mt-5 w-full rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-4 py-3 font-display font-bold text-[#1a071e]">Tamam</button>
          </div>
        </div>
      )}

      <LegalModal type={legalType} onClose={() => setLegalType(null)} />
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-purple-400/15 bg-black/20 p-2"><p className="text-[9px] text-purple-200/50">{label}</p><p className="mt-0.5 font-semibold text-amber-100">{value}</p></div>;
}

export default PremiumPage;
