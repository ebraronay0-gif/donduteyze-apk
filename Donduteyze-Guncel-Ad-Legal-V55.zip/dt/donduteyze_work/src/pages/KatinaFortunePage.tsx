import type { NavTabId } from '@/lib/navTabs';
import ThreeCardFortunePage from './ThreeCardFortunePage';
export default function KatinaFortunePage({ onNavigate }: { onNavigate: (tab: NavTabId) => void }) {
  return <ThreeCardFortunePage kind="katina" onNavigate={onNavigate} />;
}
