import { useState, useMemo, useEffect } from 'react';
import { ArrowLeft, Trophy, Ticket, CheckCircle2, Coins, Calendar, Sparkles, Crown } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import { addCredits } from '@/lib/credits';
import { getCredits, spendCredits } from '@/lib/credits';
import type { NavTabId } from '@/lib/navTabs';
import { unlockBadge } from '@/lib/badges';
import { hasPlayedGameToday, markGamePlayedToday } from '@/lib/ads';

interface LotteryPageProps {
  onNavigate: (tab: NavTabId) => void;
}

const TICKET_COST = 2;
const PRIZE = 50;

function getNextWednesday(): Date {
  const now = new Date();
  const day = now.getDay(); // 0=Sun ... 3=Wed
  const daysUntilWed = (3 - day + 7) % 7;
  const next = new Date(now);
  next.setDate(now.getDate() + (daysUntilWed === 0 ? 7 : daysUntilWed));
  next.setHours(20, 0, 0, 0);
  return next;
}

function formatCountdown(target: Date): { days: string; hours: string; minutes: string; seconds: string } {
  const diff = Math.max(0, target.getTime() - Date.now());
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return {
    days: String(days).padStart(2, '0'),
    hours: String(hours).padStart(2, '0'),
    minutes: String(minutes).padStart(2, '0'),
    seconds: String(seconds).padStart(2, '0'),
  };
}

function LotteryPage({ onNavigate }: LotteryPageProps) {
  const nextDraw = useMemo(() => getNextWednesday(), []);
  const [tickets, setTickets] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('fal_lottery_tickets') || '0');
    } catch {
      return 0;
    }
  });
  const [credits, setCredits] = useState(() => getCredits());
  const [countdown, setCountdown] = useState(() => formatCountdown(nextDraw));
  const [purchasing, setPurchasing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [watchAdOpen, setWatchAdOpen] = useState(false);
  const [playedToday, setPlayedToday] = useState(() => hasPlayedGameToday('lottery'));

  useEffect(() => {
    const handler = () => setCredits(getCredits());
    window.addEventListener('credits-updated', handler);
    return () => window.removeEventListener('credits-updated', handler);
  }, []);

  useEffect(() => {
    const id = setInterval(() => setCountdown(formatCountdown(nextDraw)), 1000);
    return () => clearInterval(id);
  }, [nextDraw]);

  const handleBuy = () => {
    if (purchasing || playedToday) { setError('Bugünkü çekiliş hakkınızı kullandınız. Yarın tekrar deneyebilirsiniz.'); return; }
    setError(null);
    const result = spendCredits(TICKET_COST);
    if (!result.success) {
      setError('Yeterli krediniz yok. Kredi kazanmak için çarkıfelek veya zar oyununu oynayabilirsiniz.');
      return;
    }
    setPurchasing(true);
    const newTickets = tickets + 1;
    try {
      localStorage.setItem('fal_lottery_tickets', String(newTickets));
    } catch {
      // ignore
    }
    setTickets(newTickets);
    markGamePlayedToday('lottery');
    setPlayedToday(true);
    window.dispatchEvent(new Event('credits-updated'));
    setTimeout(() => {
      setPurchasing(false);
      setSuccess(true);
    }, 900);
  };

  const handleRewardedAd = () => {
    addCredits(2); unlockBadge('lucky');
    setWatchAdOpen(false);
    setError(null);
    window.dispatchEvent(new Event('credits-updated'));
  };

  const drawDateStr = nextDraw.toLocaleDateString('tr-TR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={50} />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-amber-600/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/2 -right-32 h-64 w-64 rounded-full bg-gold-700/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-amber-400/30 bg-amber-900/20 text-amber-200 transition hover:border-amber-400/60 hover:text-amber-100"
          >
            <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <div className="flex items-center gap-2">
            <Trophy className="h-6 w-6 text-amber-300" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">Çekiliş</h1>
          </div>
        </div>

        {/* Prize card */}
        <div className="relative mb-6 overflow-hidden rounded-2xl border border-gold-400/40 bg-gradient-to-br from-gold-900/30 via-night-700/70 to-night-800/80 p-6 text-center backdrop-blur-sm glow-border-gold" style={{ boxShadow: '0 0 16px rgba(251, 191, 36, 0.25), 0 0 32px rgba(251, 191, 36, 0.15)' }}>
          <div className="pointer-events-none absolute -top-12 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full bg-gold-500/25 blur-3xl" />
          <div className="relative">
            <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 28px rgba(251, 191, 36, 0.5)' }}>
              <Crown className="h-8 w-8 text-gold-300" />
            </div>
            <p className="font-display text-sm uppercase tracking-widest text-gold-300/70">Büyük Ödül</p>
            <p className="mt-1 font-display text-4xl font-bold text-shimmer">{PRIZE} Kredi</p>
            <p className="mt-2 font-serif text-sm italic text-gold-100/70">Çekilişi kazanana özel</p>
          </div>
        </div>

        {/* Draw info */}
        <div className="mb-6 overflow-hidden rounded-2xl border border-amber-500/30 bg-gradient-to-br from-amber-900/20 via-night-700/70 to-night-800/80 p-5 backdrop-blur-sm">
          <div className="mb-4 flex items-center gap-2">
            <Calendar className="h-5 w-5 text-amber-300" />
            <h2 className="font-display text-lg font-semibold text-amber-100">Çekiliş Bilgileri</h2>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border border-mystic-700/30 bg-night-700/40 px-4 py-3">
              <span className="text-sm text-mystic-300">Çekiliş Günü</span>
              <span className="font-display text-sm font-semibold text-amber-100">Her Çarşamba 20:00</span>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-mystic-700/30 bg-night-700/40 px-4 py-3">
              <span className="text-sm text-mystic-300">Bilet Bedeli</span>
              <span className="flex items-center gap-1 font-display text-sm font-semibold text-amber-100">
                <Coins className="h-4 w-4 text-gold-300" /> {TICKET_COST} kredi
              </span>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-mystic-700/30 bg-night-700/40 px-4 py-3">
              <span className="text-sm text-mystic-300">Sahip Olduğunuz Bilet</span>
              <span className="rounded-full bg-amber-400/20 px-3 py-1 text-sm font-semibold text-amber-200">{tickets} bilet</span>
            </div>
          </div>
        </div>

        {/* Countdown */}
        <div className="mb-6 overflow-hidden rounded-2xl border border-amber-500/30 bg-gradient-to-br from-night-700/70 to-night-800/80 p-5 text-center backdrop-blur-sm">
          <p className="mb-3 font-display text-sm uppercase tracking-widest text-amber-300/70">Sonraki Çekiliş</p>
          <p className="mb-4 text-sm text-mystic-300">{drawDateStr}</p>
          <div className="flex justify-center gap-2">
            {[
              { label: 'Gün', value: countdown.days },
              { label: 'Saat', value: countdown.hours },
              { label: 'Dakika', value: countdown.minutes },
              { label: 'Saniye', value: countdown.seconds },
            ].map((unit) => (
              <div key={unit.label} className="flex flex-col items-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-xl border border-gold-400/30 bg-night-900/60 font-display text-xl font-bold text-gold-200" style={{ boxShadow: 'inset 0 1px 2px rgba(255,255,255,0.05)' }}>
                  {unit.value}
                </div>
                <span className="mt-1 text-[10px] uppercase tracking-wider text-mystic-400">{unit.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-4 rounded-xl border border-rose-500/30 bg-rose-900/20 px-4 py-3 text-center text-sm text-rose-200">
            {error}
          </div>
        )}

        <button onClick={() => setWatchAdOpen(true)} className="group relative mb-3 flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl border border-emerald-400/40 bg-gradient-to-r from-emerald-700/30 via-purple-800/30 to-night-800 px-6 py-3.5 text-sm font-semibold text-emerald-200 shadow-[0_0_18px_rgba(16,185,129,.12)] transition hover:scale-[1.01]">
          <span className="text-lg">▶</span> Reklam İzle · +2 Kredi
        </button>

        {/* Buy button */}
        <button
          onClick={handleBuy}
          disabled={purchasing || success || playedToday}
          className="group relative mb-6 flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl border border-amber-400/50 bg-gradient-to-r from-amber-700 via-amber-800 to-night-800 px-6 py-4 transition-all duration-300 enabled:hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50"
          style={{ boxShadow: '0 0 12px rgba(217, 119, 6, 0.3), 0 0 24px rgba(217, 119, 6, 0.2)' }}
        >
          <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-amber-300/25 to-transparent transition-transform duration-1000 enabled:group-hover:translate-x-full" />
          {purchasing ? (
            <>
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-amber-200/30 border-t-amber-200" />
              <span className="font-display text-lg font-semibold text-amber-100">Bilet alınıyor...</span>
            </>
          ) : success ? (
            <>
              <CheckCircle2 className="h-5 w-5 text-emerald-300" />
              <span className="font-display text-lg font-semibold text-emerald-200">Bilet Alındı</span>
            </>
          ) : (
            <>
              <Ticket className="h-5 w-5 text-amber-300" />
              <span className="font-display text-lg font-semibold text-amber-100">{playedToday ? 'Bugünkü hak kullanıldı' : `Bilet Al (${TICKET_COST} Kredi)`}</span>
            </>
          )}
        </button>

        {/* Tickets owned badge */}
        {tickets > 0 && !success && (
          <div className="mb-6 flex items-center justify-center gap-2 rounded-xl border border-amber-400/20 bg-amber-900/10 px-4 py-3 text-sm text-amber-200">
            <Sparkles className="h-4 w-4 text-amber-300" />
            Çekilişe <span className="font-semibold">{tickets} bilet</span> ile katıldınız. Bol şans!
          </div>
        )}

        {/* Legal disclaimer */}
        <RewardedAdModal open={watchAdOpen} onComplete={handleRewardedAd} onClose={() => setWatchAdOpen(false)} rewardLabel="2 Kredi" />

        <p className="mx-auto max-w-md text-center text-[9px] leading-relaxed text-mystic-500/40">
          Döndü Teyze bir eğlence uygulamasıdır. Çekiliş kredileri yalnızca uygulama içi kullanım içindir.
          Çekiliş sonuçları eğlence amaçlıdır.
        </p>
      </div>

      {/* Success overlay */}
      {success && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in">
          <div className="relative max-w-sm rounded-2xl border border-gold-400/40 bg-gradient-to-br from-gold-900/40 via-night-700/90 to-night-800/95 p-8 text-center animate-fade-in-up" style={{ boxShadow: '0 0 12px rgba(251, 191, 36, 0.3), 0 0 24px rgba(251, 191, 36, 0.2)' }}>
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-gold-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 36px rgba(251, 191, 36, 0.5)' }}>
                <CheckCircle2 className="h-10 w-10 text-gold-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-gold-100">Biletiniz Alındı!</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              Çekilişe katıldınız. Toplam <span className="font-semibold text-gold-200">{tickets} bilet</span> ile yarışıyorsunuz. Bol şans!
            </p>
            <button
              onClick={() => { setSuccess(false); onNavigate('home'); }}
              className="mt-6 w-full rounded-xl border border-gold-400/40 bg-gold-900/30 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:bg-gold-800/40"
            >
              Ana Sayfaya Dön
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default LotteryPage;
