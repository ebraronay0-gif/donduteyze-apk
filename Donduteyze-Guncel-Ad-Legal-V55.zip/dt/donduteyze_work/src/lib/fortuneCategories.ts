import type { LucideIcon } from 'lucide-react';
import { Coffee, Sparkles, Hand, Layers, Smile, Moon, Droplets, Heart } from 'lucide-react';

export interface FortuneCategory {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  gradient: string;
  glow: string;
  iconColor: string;
}

export const FORTUNE_CATEGORIES: FortuneCategory[] = [
  {
    id: 'kahve',
    name: 'Kahve Falı',
    description: '2 fotoğraf yükle',
    icon: Coffee,
    gradient: 'from-amber-700/30 to-amber-950/40',
    glow: 'rgba(217, 119, 6, 0.35)',
    iconColor: 'text-amber-400',
  },
  {
    id: 'tarot',
    name: 'Tarot Falı',
    description: '3 kart seç',
    icon: Sparkles,
    gradient: 'from-mystic-600/30 to-mystic-900/40',
    glow: 'rgba(139, 92, 246, 0.35)',
    iconColor: 'text-mystic-300',
  },
  {
    id: 'el',
    name: 'El Falı',
    description: 'Fotoğraf yükle',
    icon: Hand,
    gradient: 'from-rose-600/20 to-rose-950/40',
    glow: 'rgba(244, 63, 94, 0.3)',
    iconColor: 'text-rose-300',
  },
  {
    id: 'katina',
    name: 'Katina Falı',
    description: '3 kart seç',
    icon: Layers,
    gradient: 'from-emerald-600/20 to-emerald-950/40',
    glow: 'rgba(16, 185, 129, 0.3)',
    iconColor: 'text-emerald-300',
  },
  {
    id: 'yuz',
    name: 'Yüz Falı',
    description: 'Fotoğraf yükle',
    icon: Smile,
    gradient: 'from-sky-600/20 to-sky-950/40',
    glow: 'rgba(14, 165, 233, 0.3)',
    iconColor: 'text-sky-300',
  },
  {
    id: 'ruya',
    name: 'Rüya Falı',
    description: 'Rüyanı yaz',
    icon: Moon,
    gradient: 'from-indigo-600/20 to-indigo-950/40',
    glow: 'rgba(99, 102, 241, 0.3)',
    iconColor: 'text-indigo-300',
  },
  {
    id: 'water',
    name: 'Su Falı',
    description: 'Suyu karıştır',
    icon: Droplets,
    gradient: 'from-cyan-600/20 to-blue-950/40',
    glow: 'rgba(34, 211, 238, 0.3)',
    iconColor: 'text-cyan-200',
  },
  {
    id: 'angel',
    name: 'Melek Kartları',
    description: '3 melek kartı seç',
    icon: Heart,
    gradient: 'from-pink-600/20 to-violet-950/40',
    glow: 'rgba(236, 72, 153, 0.3)',
    iconColor: 'text-pink-200',
  },
];
