export type PetMeal = 'ask' | 'sevgi' | 'mutluluk';
export type PetOutfit = 'mor' | 'altin' | 'yildiz' | 'gece';

import { addCredits } from '@/lib/credits';
import { unlockBadge } from '@/lib/badges';

export interface PetState {
  name: string;
  level: number;
  xp: number;
  meals: Record<PetMeal, string>;
  outfit: PetOutfit;
  happiness: number;
  love: number;
  mood: number;
  lastDay: string;
  lastDailyReward: string;
  totalMeals: number;
}

const KEY = 'donduteyze_pet_v1';
const defaultState = (): PetState => ({
  name: 'Döndü Dostum', level: 1, xp: 0,
  meals: { ask: '', sevgi: '', mutluluk: '' },
  outfit: 'mor', happiness: 70, love: 70, mood: 70,
  lastDay: '', lastDailyReward: '', totalMeals: 0,
});

function today() { const d = new Date(); return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`; }

export function getPet(): PetState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultState();
    const p = { ...defaultState(), ...JSON.parse(raw) } as PetState;
    p.meals = { ...defaultState().meals, ...(p.meals || {}) };
    return p;
  } catch { return defaultState(); }
}
export function savePet(pet: PetState) { localStorage.setItem(KEY, JSON.stringify(pet)); window.dispatchEvent(new Event('pet-updated')); }
export function feedPet(meal: PetMeal): PetState {
  const pet = getPet(); const d = today();
  if (pet.lastDay !== d) { pet.meals = { ask:'', sevgi:'', mutluluk:'' }; pet.lastDay = d; }
  if (pet.meals[meal]) return pet;
  pet.meals[meal] = new Date().toISOString(); pet.totalMeals += 1; pet.xp += 10; unlockBadge('pet');
  if (meal === 'ask') pet.love = Math.min(100, pet.love + 8);
  if (meal === 'sevgi') pet.mood = Math.min(100, pet.mood + 8);
  if (meal === 'mutluluk') pet.happiness = Math.min(100, pet.happiness + 8);
  if (pet.xp >= 30) { pet.xp -= 30; pet.level += 1; pet.happiness = Math.min(100, pet.happiness + 5); }
  savePet(pet); return pet;
}
export function claimPetDailyReward(): { pet: PetState; claimed: boolean } {
  const pet = getPet(); const d = today();
  if (pet.lastDailyReward === d) return { pet, claimed: false };
  pet.lastDailyReward = d; pet.xp += 5; savePet(pet); addCredits(1); return { pet, claimed: true };
}

export function setPetOutfit(outfit: PetOutfit) { const pet = getPet(); pet.outfit = outfit; savePet(pet); return pet; }
export function petDayKey() { return today(); }
