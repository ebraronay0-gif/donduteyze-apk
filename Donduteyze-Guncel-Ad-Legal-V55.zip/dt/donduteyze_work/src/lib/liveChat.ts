import { supabase } from './supabase';
import type { AuthUser } from './auth';
import { sendChatPush } from './pushNotifications';

export const LIVE_CHAT_PRICE = 99.99;
export const FORTUNE_TELLER_PRICE = 72;

export type ChatSessionStatus = 'pending' | 'active' | 'ended';

export interface ChatSession {
  id: string;
  user_id: string;
  user_email: string | null;
  status: ChatSessionStatus;
  price: number;
  purchased_at: string;
  connected_at: string | null;
  ended_at: string | null;
}

export interface ChatMessage {
  id: string;
  session_id: string;
  sender: 'user' | 'admin';
  message: string;
  read: boolean;
  created_at: string;
}

export async function getActiveSession(user: AuthUser): Promise<ChatSession | null> {
  const { data, error } = await supabase
    .from('live_chat_sessions')
    .select('*')
    .eq('user_id', user.id)
    .in('status', ['pending', 'active'])
    .order('created_at', { ascending: false })
    .maybeSingle();
  if (error) return null;
  return data as ChatSession | null;
}

export async function purchaseChatSession(user: AuthUser, counselorName?: string): Promise<ChatSession | null> {
  const { data, error } = await supabase
    .from('live_chat_sessions')
    .insert({
      user_id: user.id,
      user_email: user.email || 'Misafir',
      status: 'pending',
      price: counselorName ? FORTUNE_TELLER_PRICE : LIVE_CHAT_PRICE,
    })
    .select()
    .maybeSingle();
  if (error || !data) return null;
  const session = data as ChatSession;
  if (counselorName) {
    await supabase.from('live_chat_messages').insert({
      session_id: session.id,
      sender: 'user',
      message: `FALCI SEÇİMİ: ${counselorName}`,
      read: true,
    });
  }
  return session;
}

export async function fetchMessages(sessionId: string): Promise<ChatMessage[]> {
  const { data, error } = await supabase
    .from('live_chat_messages')
    .select('*')
    .eq('session_id', sessionId)
    .order('created_at', { ascending: true });
  if (error || !data) return [];
  return data as ChatMessage[];
}

export async function sendMessage(sessionId: string, sender: 'user' | 'admin', message: string): Promise<ChatMessage | null> {
  const { data, error } = await supabase
    .from('live_chat_messages')
    .insert({
      session_id: sessionId,
      sender,
      message,
      read: sender === 'user',
    })
    .select()
    .maybeSingle();
  if (error) return null;
  const chatMessage = data as ChatMessage | null;
  if (chatMessage) void sendChatPush(chatMessage.id, 'live_chat');
  return chatMessage;
}

export async function markMessagesRead(sessionId: string): Promise<void> {
  await supabase
    .from('live_chat_messages')
    .update({ read: true })
    .eq('session_id', sessionId)
    .eq('sender', 'admin')
    .eq('read', false);
}

export function subscribeToMessages(sessionId: string, callback: (messages: ChatMessage[]) => void): () => void {
  const channel = supabase
    .channel(`live_chat_messages:${sessionId}`)
    .on('postgres_changes', {
      event: 'INSERT',
      schema: 'public',
      table: 'live_chat_messages',
      filter: `session_id=eq.${sessionId}`,
    }, async () => {
      const msgs = await fetchMessages(sessionId);
      callback(msgs);
    })
    .subscribe();
  return () => {
    supabase.removeChannel(channel);
  };
}

export function subscribeToSession(sessionId: string, callback: (session: ChatSession) => void): () => void {
  const channel = supabase
    .channel(`live_chat_session:${sessionId}`)
    .on('postgres_changes', {
      event: 'UPDATE',
      schema: 'public',
      table: 'live_chat_sessions',
      filter: `id=eq.${sessionId}`,
    }, (payload) => {
      callback(payload.new as ChatSession);
    })
    .subscribe();
  return () => {
    supabase.removeChannel(channel);
  };
}
