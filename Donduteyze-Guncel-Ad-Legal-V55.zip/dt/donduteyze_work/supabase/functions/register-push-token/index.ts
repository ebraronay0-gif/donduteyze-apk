import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const ADMIN_OWNER_ID = "00000000-0000-0000-0000-000000000001";

type Body = {
  token?: string;
  role?: "user" | "admin";
  ownerId?: string;
  adminPassword?: string;
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const body = await req.json() as Body;
    const token = body.token?.trim();
    const role = body.role;
    if (!token || !role) return json({ error: "Eksik push bilgisi." }, 400);

    const adminClient = createClient(
      Deno.env.get("SUPABASE_URL") || "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "",
    );

    let ownerId = "";
    if (role === "admin") {
      const { data } = await adminClient
        .from("app_config")
        .select("value")
        .eq("key", "admin_password")
        .maybeSingle();
      const expected = data?.value || Deno.env.get("ADMIN_PASSWORD") || "";
      if (!expected || body.adminPassword !== expected) return json({ error: "Yetkisiz." }, 401);
      ownerId = ADMIN_OWNER_ID;
    } else {
      const authHeader = req.headers.get("Authorization") || "";
      const jwt = authHeader.replace(/^Bearer\s+/i, "");
      if (!jwt) return json({ error: "Oturum gerekli." }, 401);
      const { data: userData, error: userError } = await adminClient.auth.getUser(jwt);
      if (userError || !userData.user) return json({ error: "Oturum geçersiz." }, 401);
      if (body.ownerId !== userData.user.id) return json({ error: "Yetkisiz kullanıcı." }, 403);
      ownerId = userData.user.id;
    }

    const { error } = await adminClient.from("push_tokens").upsert({
      owner_id: ownerId,
      role,
      token,
      platform: "native",
      updated_at: new Date().toISOString(),
    }, { onConflict: "token" });

    if (error) return json({ error: error.message }, 500);
    return json({ success: true });
  } catch (error) {
    return json({ error: String(error) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
