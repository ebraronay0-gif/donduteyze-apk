import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const ADMIN_OWNER_ID = "00000000-0000-0000-0000-000000000001";
const FCM_SCOPE = "https://www.googleapis.com/auth/firebase.messaging";
const FCM_TOKEN_URL = "https://oauth2.googleapis.com/token";

type Body = { messageId?: string; channel?: "live_chat" | "support" };
type ServiceAccount = { client_email: string; private_key: string; project_id: string };

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const { messageId, channel } = await req.json() as Body;
    if (!messageId || !channel) return json({ error: "Eksik mesaj bilgisi." }, 400);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") || "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "",
    );

    const authHeader = req.headers.get("Authorization") || "";
    const jwt = authHeader.replace(/^Bearer\s+/i, "");
    const { data: caller } = jwt ? await supabase.auth.getUser(jwt) : { data: { user: null } };

    let targetRole: "admin" | "user";
    let targetOwnerId: string | null = null;
    let messageText = "";
    let title = "Döndü Teyze";
    let data: Record<string, string> = { messageId, channel };

    if (channel === "live_chat") {
      const { data: message, error } = await supabase
        .from("live_chat_messages")
        .select("id,session_id,sender,message")
        .eq("id", messageId)
        .maybeSingle();
      if (error || !message) return json({ error: "Mesaj bulunamadı." }, 404);

      const { data: session } = await supabase
        .from("live_chat_sessions")
        .select("user_id,user_email")
        .eq("id", message.session_id)
        .maybeSingle();
      if (!session) return json({ error: "Sohbet bulunamadı." }, 404);

      if (message.sender === "user") {
        if (!caller.user || caller.user.id !== session.user_id) return json({ error: "Yetkisiz." }, 403);
        targetRole = "admin";
        title = "Döndü Teyze — Yeni falcı mesajı";
        messageText = message.message;
      } else {
        // Admin login is intentionally separate from Supabase Auth in this app.
        // The admin message is still safely constrained to a real admin-created row.
        if (caller.user) return json({ error: "Yetkisiz." }, 403);
        targetRole = "user";
        targetOwnerId = session.user_id;
        title = "Döndü Teyze — Yeni mesaj";
        messageText = message.message;
      }
      data = { ...data, sessionId: message.session_id };
    } else {
      const { data: message, error } = await supabase
        .from("support_messages")
        .select("id,user_id,user_email,sender,message")
        .eq("id", messageId)
        .maybeSingle();
      if (error || !message) return json({ error: "Mesaj bulunamadı." }, 404);

      if (message.sender === "user") {
        if (!caller.user || (message.user_id && caller.user.id !== message.user_id && caller.user.email !== message.user_email)) return json({ error: "Yetkisiz." }, 403);
        targetRole = "admin";
        title = "Döndü Teyze — Yeni destek mesajı";
        messageText = message.message;
      } else {
        if (caller.user) return json({ error: "Yetkisiz." }, 403);
        targetRole = "user";
        // support_messages historically stores the app_users id, while native
        // push tokens belong to the Supabase auth user. Resolve by email so
        // older support conversations continue to receive notifications.
        if (message.user_email) {
          const { data: users } = await supabase.auth.admin.listUsers({ page: 1, perPage: 1000 });
          const target = users.users.find((u) => u.email?.toLowerCase() === message.user_email?.toLowerCase());
          targetOwnerId = target?.id || null;
        }
        if (!targetOwnerId && message.user_id) targetOwnerId = message.user_id;
        if (!targetOwnerId) return json({ error: "Kullanıcı bulunamadı." }, 404);
        title = "Döndü Teyze — Destek yanıtı";
        messageText = message.message;
      }
    }

    const query = supabase.from("push_tokens").select("id,token").eq("role", targetRole);
    const { data: tokens, error: tokenError } = targetOwnerId
      ? await query.eq("owner_id", targetOwnerId)
      : await query.eq("owner_id", ADMIN_OWNER_ID);
    if (tokenError) return json({ error: tokenError.message }, 500);
    if (!tokens?.length) return json({ success: true, sent: 0 });

    const serviceAccount = readServiceAccount();
    if (!serviceAccount) return json({ success: false, sent: 0, warning: "FCM_SERVICE_ACCOUNT_JSON ayarlanmamış." });

    const accessToken = await getGoogleAccessToken(serviceAccount);
    let sent = 0;
    const invalidTokenIds: string[] = [];

    await Promise.all((tokens || []).map(async (row) => {
      const result = await sendFcm(serviceAccount.project_id, accessToken, row.token, title, messageText, data);
      if (result.ok) sent++;
      if (result.invalidToken) invalidTokenIds.push(row.id);
    }));

    if (invalidTokenIds.length) {
      await supabase.from("push_tokens").delete().in("id", invalidTokenIds);
    }

    return json({ success: true, sent });
  } catch (error) {
    console.error(error);
    return json({ error: String(error) }, 500);
  }
});

function readServiceAccount(): ServiceAccount | null {
  const raw = Deno.env.get("FCM_SERVICE_ACCOUNT_JSON") || "";
  if (!raw) return null;
  try {
    return JSON.parse(raw) as ServiceAccount;
  } catch {
    return null;
  }
}

function base64Url(input: Uint8Array): string {
  let binary = "";
  for (const byte of input) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64UrlText(input: string): string {
  return base64Url(new TextEncoder().encode(input));
}

function pemToDer(pem: string): ArrayBuffer {
  const base64 = pem.replace(/-----BEGIN PRIVATE KEY-----/g, "").replace(/-----END PRIVATE KEY-----/g, "").replace(/\s/g, "");
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function createJwt(sa: ServiceAccount): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlText(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const payload = base64UrlText(JSON.stringify({
    iss: sa.client_email,
    scope: FCM_SCOPE,
    aud: FCM_TOKEN_URL,
    iat: now,
    exp: now + 3600,
  }));
  const unsigned = `${header}.${payload}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToDer(sa.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned));
  return `${unsigned}.${base64Url(new Uint8Array(signature))}`;
}

async function getGoogleAccessToken(sa: ServiceAccount): Promise<string> {
  const assertion = await createJwt(sa);
  const response = await fetch(FCM_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion,
    }),
  });
  if (!response.ok) throw new Error(`Google OAuth hatası: ${await response.text()}`);
  const result = await response.json();
  return result.access_token as string;
}

async function sendFcm(projectId: string, accessToken: string, token: string, title: string, body: string, data: Record<string, string>) {
  const response = await fetch(`https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      message: {
        token,
        notification: { title, body: body.slice(0, 300) },
        data,
        android: { priority: "high", notification: { channel_id: "donduteyze_chat", sound: "default" } },
      },
    }),
  });
  if (response.ok) return { ok: true, invalidToken: false };
  const text = await response.text();
  return { ok: false, invalidToken: /UNREGISTERED|registration-token-not-registered/i.test(text) };
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
