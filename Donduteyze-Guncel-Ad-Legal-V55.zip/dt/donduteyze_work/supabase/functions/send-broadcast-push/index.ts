import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const ADMIN_OWNER_ID = "00000000-0000-0000-0000-000000000001";
const FCM_SCOPE = "https://www.googleapis.com/auth/firebase.messaging";
const FCM_TOKEN_URL = "https://oauth2.googleapis.com/token";

type Body = {
  title?: string;
  body?: string;
  target?: "all" | "user";
  targetUserId?: string;
  adminPassword?: string;
};
type ServiceAccount = { client_email: string; private_key: string; project_id: string };

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const { title, body, target, targetUserId, adminPassword } = await req.json() as Body;
    if (!title?.trim()) return json({ error: "Bildirim başlığı gerekli." }, 400);
    if (target !== "all" && target !== "user") return json({ error: "Geçersiz hedef." }, 400);
    if (target === "user" && !targetUserId) return json({ error: "Kullanıcı seçilmedi." }, 400);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") || "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "",
    );

    const { data: config } = await supabase.from("app_config").select("value").eq("key", "admin_password").maybeSingle();
    const expectedPassword = config?.value || Deno.env.get("ADMIN_PASSWORD") || "";
    if (!expectedPassword || adminPassword !== expectedPassword) return json({ error: "Yetkisiz." }, 401);

    const serviceAccount = readServiceAccount();
    if (!serviceAccount) return json({ success: false, error: "FCM_SERVICE_ACCOUNT_JSON ayarlanmamış." }, 500);

    let query = supabase.from("push_tokens").select("id,token,owner_id").eq("role", "user");
    if (target === "user") query = query.eq("owner_id", targetUserId!);
    const { data: rows, error } = await query;
    if (error) return json({ error: error.message }, 500);
    if (!rows?.length) return json({ success: true, sent: 0, failed: 0, recipients: 0 });

    const accessToken = await getGoogleAccessToken(serviceAccount);
    let sent = 0;
    let failed = 0;
    const invalidIds: string[] = [];
    const messageBody = (body || "").trim().slice(0, 1000);

    // FCM supports at most 500 targets per multicast call. We chunk so the
    // admin panel can broadcast to any number of registered devices.
    for (let i = 0; i < rows.length; i += 500) {
      const batch = rows.slice(i, i + 500);
      const result = await sendMulticast(serviceAccount.project_id, accessToken, batch.map((r) => r.token), title.trim(), messageBody);
      sent += result.sent;
      failed += result.failed;
      result.invalidIndexes.forEach((index) => invalidIds.push(batch[index].id));
    }

    if (invalidIds.length) await supabase.from("push_tokens").delete().in("id", invalidIds);

    return json({ success: true, sent, failed, recipients: rows.length, invalidTokensRemoved: invalidIds.length });
  } catch (error) {
    console.error(error);
    return json({ error: String(error) }, 500);
  }
});

function readServiceAccount(): ServiceAccount | null {
  const raw = Deno.env.get("FCM_SERVICE_ACCOUNT_JSON") || "";
  if (!raw) return null;
  try { return JSON.parse(raw) as ServiceAccount; } catch { return null; }
}

function base64Url(input: Uint8Array): string {
  let binary = "";
  for (const byte of input) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function base64UrlText(input: string): string { return base64Url(new TextEncoder().encode(input)); }
function pemToDer(pem: string): ArrayBuffer {
  const base64 = pem.replace(/-----BEGIN PRIVATE KEY-----/g, "").replace(/-----END PRIVATE KEY-----/g, "").replace(/\s/g, "");
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}
async function createJwt(sa: ServiceAccount): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlText(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const payload = base64UrlText(JSON.stringify({ iss: sa.client_email, scope: FCM_SCOPE, aud: FCM_TOKEN_URL, iat: now, exp: now + 3600 }));
  const unsigned = `${header}.${payload}`;
  const key = await crypto.subtle.importKey("pkcs8", pemToDer(sa.private_key), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned));
  return `${unsigned}.${base64Url(new Uint8Array(signature))}`;
}
async function getGoogleAccessToken(sa: ServiceAccount): Promise<string> {
  const response = await fetch(FCM_TOKEN_URL, {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: await createJwt(sa) }),
  });
  if (!response.ok) throw new Error(`Google OAuth hatası: ${await response.text()}`);
  return (await response.json()).access_token as string;
}

async function sendMulticast(projectId: string, accessToken: string, tokens: string[], title: string, body: string) {
  const results = await Promise.all(tokens.map(async (token) => {
    const response = await fetch(`https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`, {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({ message: {
        token,
        notification: { title, body },
        data: { type: "admin_broadcast" },
        android: { priority: "high", notification: { channel_id: "donduteyze_chat", sound: "default" } },
      }}),
    });
    if (response.ok) return { ok: true, invalid: false };
    const text = await response.text();
    return { ok: false, invalid: /UNREGISTERED|registration-token-not-registered/i.test(text) };
  }));
  return {
    sent: results.filter((r) => r.ok).length,
    failed: results.filter((r) => !r.ok).length,
    invalidIndexes: results.map((r, i) => r.invalid ? i : -1).filter((i) => i >= 0),
  };
}
function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
