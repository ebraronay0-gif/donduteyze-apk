create table if not exists public.push_tokens (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null,
  role text not null default 'admin',
  token text not null unique,
  platform text not null default 'native',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.push_tokens enable row level security;

create policy "authenticated users can manage own push token"
on public.push_tokens for all
to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

create index if not exists push_tokens_role_idx on public.push_tokens(role);

-- The native push provider (FCM/APNs) should consume admin push_tokens when a
-- new user message is inserted into live_chat_messages. Provider credentials
-- must be configured in Supabase secrets before production deployment.
