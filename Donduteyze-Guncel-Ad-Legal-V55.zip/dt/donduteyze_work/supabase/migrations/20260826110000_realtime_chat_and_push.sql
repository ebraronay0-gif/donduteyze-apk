/*
  Real-time chat + native push infrastructure.

  Realtime:
  - live_chat_sessions
  - live_chat_messages
  - support_messages

  Push tokens:
  - users are registered through the register-push-token Edge Function
  - admins are registered after admin password verification through the same function
*/

CREATE TABLE IF NOT EXISTS public.push_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  role text NOT NULL CHECK (role IN ('user', 'admin')),
  token text NOT NULL UNIQUE,
  platform text NOT NULL DEFAULT 'native',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.push_tokens ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "authenticated users can manage own push token" ON public.push_tokens;
CREATE POLICY "authenticated users can manage own push token"
ON public.push_tokens FOR ALL TO authenticated
USING (owner_id = auth.uid())
WITH CHECK (owner_id = auth.uid() AND role = 'user');

CREATE INDEX IF NOT EXISTS push_tokens_role_owner_idx ON public.push_tokens(role, owner_id);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'live_chat_sessions'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_chat_sessions;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'live_chat_messages'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_chat_messages;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'support_messages'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.support_messages;
  END IF;
END $$;
