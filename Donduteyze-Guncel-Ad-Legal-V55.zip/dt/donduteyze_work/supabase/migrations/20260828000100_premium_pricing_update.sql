-- Döndü Teyze Premium pricing update
-- Prices shown in the Premium screen:
-- Weekly 59.99 TL, Monthly 129.99 TL, Yearly 499.99 TL, 250 credits 149.99 TL.
UPDATE app_config SET value = '59,99', updated_at = now() WHERE key = 'price_weekly';
UPDATE app_config SET value = '129,99', updated_at = now() WHERE key = 'price_monthly';
UPDATE app_config SET value = '499,99', updated_at = now() WHERE key = 'price_yearly';
INSERT INTO app_config (key, value) VALUES ('price_credits250', '149,99') ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now();
