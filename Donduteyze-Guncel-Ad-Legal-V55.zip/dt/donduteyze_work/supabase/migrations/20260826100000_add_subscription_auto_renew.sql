/*
  Subscription management:
  - auto_renew=true means the next billing period may renew.
  - Cancelling auto-renew keeps the subscription active until expires_at.
*/
ALTER TABLE subscriptions
  ADD COLUMN IF NOT EXISTS auto_renew boolean NOT NULL DEFAULT true;

CREATE INDEX IF NOT EXISTS idx_subscriptions_auto_renew
  ON subscriptions(auto_renew) WHERE auto_renew = true;
