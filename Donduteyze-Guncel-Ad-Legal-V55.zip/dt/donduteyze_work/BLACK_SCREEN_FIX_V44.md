# V44 — Black screen / WebView startup hardening

- React is rendered before AdMob/native initialization.
- AdMob initialization is deferred until the first animation frame and cannot block startup.
- Added a native-safe HTML boot screen so a blank/black frame is not shown while React loads.
- Added a root-level React error boundary with a visible retry screen.
- Updated Capacitor native background to match the boot screen.
- Bumped app version to 1.0.32.
