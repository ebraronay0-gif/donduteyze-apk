# Döndü Teyze Android APK

Bu proje Capacitor 6 + Android + Vite kullanır.

## Telefonda test APK'sı

GitHub'a push ettikten sonra **Actions → Build Döndü Teyze Android APK → Run workflow** ile derlemeyi başlatabilirsiniz.

Build tamamlandığında **donduteyze-debug-apk** artifact'inden `app-debug.apk` indirilebilir.

Bu APK fiziksel Android telefonda test içindir. Google Play yayını için daha sonra imzalı **AAB** üretmeliyiz.

## İlk kurulum

Android telefonda bilinmeyen kaynaklardan uygulama yükleme izni gerekebilir. Google Play'den olmayan APK olduğu için Android bunu sorabilir.

## Önemli

- APK debug sürümüdür; mağaza yayını için kullanılmamalıdır.
- Gerçek AdMob reklamlarını test etmek yerine yayın öncesinde test reklamları kullanılmalıdır.
- Google/Apple OAuth için Supabase ve sağlayıcı tarafındaki redirect ayarları ayrıca yapılmalıdır.


## Analytics

Apply the new Supabase migration `20260822000100_analytics_events.sql` before using Admin analytics. Country is a browser locale/timezone hint, not IP-geolocation. Revenue is estimated from subscription records and prices configured in Admin → İçerik & Fiyat.

## Premium / Google Play Billing

Premium dijital ürün ve abonelikleri Google Play'de yayınlanırken Play Billing ile satılmalıdır. `GOOGLE_PLAY_PREMIUM_CHECKLIST.md` içindeki ürün kimlikleri ve test adımları tamamlanmadan Android'de ücretli Premium satın alımı açılmamalıdır.
