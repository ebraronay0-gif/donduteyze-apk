# V29 — Döndü Teyze Hero Fix
- Ana sayfa üst bannerı yenilendi.
- Döndü Teyze'nin yüzü ve baş kısmı artık kadrajın içinde tamamen görünür.
- 3D/mistik mor-altın görsel dili korunmuştur.
- Mevcut kartlar, navigasyon ve işlevler değiştirilmemiştir.
