# V27 – Unified 3D Mistik Tasarım

- Ana sayfa ve uygulama içindeki sayfalar aynı mor/indigo + altın 3D görsel dilinde birleştirildi.
- Fal kartları için ortak derinlik, cam, parlama, yıldız ve altın çerçeve sistemi eklendi.
- Su Falı ekranı referans görsellerdeki ritüel/3D düzenine göre güçlendirildi; parmakla karıştırma ve reklam → yapay zekâ → Fallarım akışı korunur.
- Yüz Falı, El Falı, Katina ve Melek Kartları dahil fal ekranlarının ortak premium görünüm sistemiyle uyumu artırıldı.
- Alt menü ve diğer paneller aynı görsel kimliğe bağlandı.
- Android launcher icon üretimindeki kritik hata düzeltildi: build artık resources/launcher-icon-final.png kaynağını kullanıyor; public/icon.png artık launcher kaynağı olarak üzerine yazılmıyor.
- Sürüm 1.0.27 / Android versionCode 27 hedefi.
