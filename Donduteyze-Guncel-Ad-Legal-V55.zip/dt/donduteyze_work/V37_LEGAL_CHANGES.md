# V37 Legal / KVKK / Purchase Texts

- İlk giriş/onboarding ekranındaki tek sözleşme alanı üç ayrı, tıklanabilir metne ayrıldı:
  - Kullanıcı Sözleşmesi
  - Gizlilik ve KVKK Aydınlatma Metni
  - Kullanım Şartları
- Her metin için ayrı kutucuk eklendi.
- Onboarding, gerekli kutucuklar işaretlenmeden tamamlanamıyor.
- E-posta/şifre, Google ve Apple giriş/üyelik akışında aynı üçlü yasal kabul alanı kullanılıyor.
- Premium/satın alma ekranına aynı yasal metinler ve satın alma öncesi üçlü kabul eklendi.
- Fal sayfalarında eğlence amaçlı kullanım ve profesyonel danışmanlık olmadığına ilişkin görünür uyarılar tamamlandı.
- KVKK metni; veri sorumlusu, amaç, veri kategorileri, aktarım grupları, hukuki sebepler, saklama, ilgili kişi hakları ve açık rıza/aydınlatma ayrımını kapsayacak şekilde genişletildi.
- Kullanıcı Sözleşmesi ve Kullanım Şartları; yapay zekâ yorumları, fotoğraf yüklemeleri, krediler, reklam ödülleri, abonelikler, dijital hizmetler, kötüye kullanım ve tüketici haklarını kapsayacak şekilde genişletildi.

## Yayın öncesi zorunlu hukuk/işletme bilgileri

LegalModal içindeki köşeli parantezli alanlar gerçek veri sorumlusu/işletmeci unvanı, adres ve iletişim bilgileriyle doldurulmalıdır. Gerçek ödeme sağlayıcısı/uygulama mağazası, reklam sağlayıcıları, yapay zekâ sağlayıcıları, yurt dışı veri aktarımı ve saklama süreleri teknik sözleşmelerle doğrulanmalıdır. Bu değişiklikler hukuki danışmanlık veya mevzuata uygunluk garantisi değildir; yayın öncesi Türkiye'de KVKK ve tüketici hukuku alanında çalışan bir avukat tarafından son kontrol önerilir.
