# V55 – Ad alanı ve yasal metin güncellemesi

- İlk profil/onboarding ekranındaki “İsim - Soyisim” alanı “Adınız” olarak güncellendi.
- Alanın yer tutucusu “Adınız” ve doğrulama mesajı “Lütfen adınızı girin.” oldu.
- Giriş/üyelik ekranındaki yasal metinler iki belgeye ayrıldı:
  1. Gizlilik Politikası / Sözleşmesi
  2. Kullanıcı Sözleşmesi ve Kullanım Şartları
- Premium ekranındaki üçlü eski yasal bağlantı kaldırılıp aynı iki belgeye bağlandı.
- Premium görselinin altındaki yasal bağlantı alanı iki satırlı ve ayraçlı hale getirildi.
- Uygulama kaynak sürümü 1.0.55 olarak güncellendi.
