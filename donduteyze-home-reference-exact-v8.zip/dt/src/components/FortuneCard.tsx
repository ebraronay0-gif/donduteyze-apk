import type { FortuneCategory } from '@/lib/fortuneCategories';

interface FortuneCardProps {
  category: FortuneCategory;
  onClick?: () => void;
}

function FortuneCard({ category, onClick }: FortuneCardProps) {
  const Icon = category.icon;

  return (
    <button
      onClick={onClick}
      className="group relative aspect-[0.92] overflow-hidden rounded-[1.35rem] border border-gold-400/15 bg-gradient-to-br from-night-700/90 via-night-800/90 to-night-950/95 p-2.5 text-left transition-all duration-300 hover:-translate-y-1 hover:border-gold-400/50"
      style={{ boxShadow: `0 4px 20px ${category.glow}` }}
    >
      {/* Glow blob */}
      <div
        className="pointer-events-none absolute -top-8 -right-8 h-24 w-24 rounded-full opacity-30 blur-2xl transition-opacity duration-300 group-hover:opacity-60"
        style={{ backgroundColor: category.glow }}
      />

      {/* 3D Icon */}
      <div className="relative flex h-full flex-col items-center justify-center gap-2">
        <div
          className="relative transition-transform duration-500 group-hover:scale-110"
          style={{ perspective: '600px' }}
        >
          <div
            className="transition-transform duration-500 group-hover:[transform:rotateY(15deg)_rotateX(-10deg)]"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div
              className="flex h-14 w-14 items-center justify-center rounded-[1.1rem] border border-white/10 bg-gradient-to-br from-white/15 via-mystic-700/20 to-transparent backdrop-blur-sm sm:h-16 sm:w-16"
              style={{
                boxShadow: `0 8px 24px ${category.glow}, inset 0 1px 1px rgba(255,255,255,0.15)`,
              }}
            >
              <Icon className={`h-7 w-7 drop-shadow-[0_4px_8px_rgba(0,0,0,0.35)] sm:h-8 sm:w-8 ${category.iconColor}`} strokeWidth={1.5} />
            </div>
          </div>
        </div>

        <div className="text-center">
          <h3 className="font-display text-[11px] font-semibold leading-tight text-mystic-100 sm:text-sm">
            {category.name}
          </h3>
          <p className="mt-1 text-[9px] leading-tight text-mystic-400 sm:text-[10px]">{category.description}</p>
        </div>
      </div>

      {/* Shimmer sweep */}
      <div className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/5 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
    </button>
  );
}

export default FortuneCard;
