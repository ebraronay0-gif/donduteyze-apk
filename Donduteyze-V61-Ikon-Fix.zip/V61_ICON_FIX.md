# V61 — Launcher Icon Fix

- Capacitor `ic_launcher` is no longer used by the app manifest.
- A unique launcher resource name (`donduteyze_launcher`) is used.
- The icon is applied **after** `npx cap sync android`, preventing Capacitor sync from overwriting it.
- GitHub Actions fails if `ic_launcher` is referenced or if the Döndü Teyze launcher resources are missing.
- Gemini / Supabase Edge Function fortune logic is untouched.
