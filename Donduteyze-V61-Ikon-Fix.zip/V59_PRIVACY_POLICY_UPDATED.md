# V59 — Gizlilik Politikası Güncellendi

- Gerçek veri akışına göre ayrıntılı gizlilik politikası hazırlandı.
- Supabase, Firebase Cloud Messaging, Google Play/Google Play Billing ve Google AdMob açıkça belirtildi.
- Hesap, fal, fotoğraf, sohbet, push token, abonelik/kredi ve teknik/analitik veriler açıklandı.
- Fal fotoğrafları ve AI/fal yorumlama altyapısının veri işleme amacı açıklandı.
- Veri saklama, hesap silme, güvenlik, KVKK ve yaş sınırı bölümleri netleştirildi.
- GitHub Pages için bağımsız `privacy-policy.html` eklendi; böylece uygulamanın ana `index.html` dosyasını ezmeden gizlilik URL'si yayınlanabilir.
