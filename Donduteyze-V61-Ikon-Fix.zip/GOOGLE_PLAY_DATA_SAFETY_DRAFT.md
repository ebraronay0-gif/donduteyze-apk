# Google Play Data Safety — Taslak

Bu belge Play Console'daki formun yerini tutmaz; uygulamanın mevcut kaynak koduna göre başlangıç taslağıdır.

## Muhtemel toplanan/verilen veri türleri
- Personal info: Email address; kullanıcı tarafından profil için verilen ad ve burç.
- App activity: app interactions / analytics events; fortune history.
- User content: photos/images, free-form text and chat messages.
- App info and performance: crash/diagnostic/technical events if enabled by the deployed SDKs.
- Device or other identifiers: push notification token used for notifications.
- Purchase/subscription information: plan, entitlement and expiry state. Payment card data is handled by Google Play and is not stored by Döndü Teyze.

## Amaçlar
- App functionality
- Account management
- Personalization / user-requested fortune history
- Messaging / support
- Notifications
- App analytics and performance
- Fraud/security where applicable

## Deletion
- In-app: Profil → Ayarlar → Hesabımı Sil
- External: the deployed public account deletion web resource.
- Account deletion removes account-linked records that are not legally required to be retained.

## Important
Before publishing, verify every SDK actually bundled in the release APK/AAB and reconcile this document with Play Console's current Data Safety questions. Google requires the Play Console disclosure to be accurate and consistent with the privacy policy. 
