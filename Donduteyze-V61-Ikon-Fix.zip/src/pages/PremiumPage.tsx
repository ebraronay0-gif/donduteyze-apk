import { useEffect, useMemo, useState } from 'react';
import { Check, ChevronRight, Crown, CreditCard, Loader2, ShieldCheck, User, X, Zap } from 'lucide-react';
import type { NavTabId } from '@/lib/navTabs';
import type { AuthUser } from '@/lib/auth';
import LegalModal, { type LegalType } from '@/components/LegalModal';
import { purchasePlan, refreshSubscription, type PlanId, type SubscriptionInfo } from '@/lib/subscriptions';
import { deleteAccount } from '@/lib/auth';

interface PremiumPageProps {
  onNavigate: (tab: NavTabId) => void;
  onRequireAuth?: () => void;
  onOpenLogin?: () => void;
  isLoggedIn?: boolean;
  authUser?: AuthUser | null;
}

interface Offer {
  id: PlanId;
  title: string;
  price: string;
  period: string;
  recurring?: boolean;
  badge?: string;
  featured?: boolean;
}

const CREDIT_PACK: Offer = { id: 'credits250', title: '250 Kredi', price: '₺149,99', period: 'tek seferlik' };
const SUBSCRIPTIONS: Offer[] = [
  { id: 'weekly', title: 'Haftalık', price: '₺59,99', period: '/ hafta', recurring: true },
  { id: 'monthly', title: 'Aylık', price: '₺129,99', period: '/ ay', recurring: true, badge: 'EN ÇOK TERCİH EDİLEN', featured: true },
  { id: 'yearly', title: 'Yıllık', price: '₺499,99', period: '/ yıl', recurring: true, badge: 'EN AVANTAJLI' },
];
const PLAN_NAMES: Record<string, string> = { weekly: 'Haftalık Üyelik', monthly: 'Aylık Üyelik', yearly: 'Yıllık Üyelik' };

function formatDate(value: string | null) {
  if (!value) return '—';
  return new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(value));
}

function PremiumPage({ onNavigate, onOpenLogin, onRequireAuth, authUser }: PremiumPageProps) {
  const [subscription, setSubscription] = useState<SubscriptionInfo | null>(null);
  const [subscriptionOpen, setSubscriptionOpen] = useState(false);
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);
  const [purchasing, setPurchasing] = useState(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);
  const [legalType, setLegalType] = useState<LegalType | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);
  const [deletingAccount, setDeletingAccount] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const loadSubscription = async () => setSubscription(await refreshSubscription(authUser ?? null));
  useEffect(() => { loadSubscription(); }, [authUser?.id]);

  const activePlanName = useMemo(() => subscription ? (PLAN_NAMES[subscription.plan] || subscription.plan) : 'Aktif abonelik yok', [subscription]);
  const daysRemaining = useMemo(() => {
    if (!subscription?.expiresAt) return 0;
    return Math.max(0, Math.ceil((new Date(subscription.expiresAt).getTime() - Date.now()) / 86400000));
  }, [subscription?.expiresAt]);

  const handleBuy = async (offer: Offer) => {
    setPurchasing(true); setPurchaseError(null);
    try {
      const result = await purchasePlan(offer.id, authUser ?? undefined);
      if (!result.success) { setPurchaseError(result.error || 'Satın alma başarısız oldu.'); return; }
      setSelectedOffer(offer); await loadSubscription();
    } finally { setPurchasing(false); }
  };

  const openGooglePlaySubscriptions = () => window.open('https://play.google.com/store/account/subscriptions', '_blank', 'noopener,noreferrer');

  const handleDeleteAccount = async () => {
    if (!authUser || deletingAccount) return;
    if (!window.confirm('Hesabınızı ve ilişkili verilerinizi kalıcı olarak silmek istediğinize emin misiniz?')) return;
    setDeletingAccount(true); setDeleteError(null);
    const result = await deleteAccount();
    if (!result.success) { setDeleteError(result.error || 'Hesap silinemedi.'); setDeletingAccount(false); return; }
    window.location.reload();
  };

  return (
    <div className="fixed inset-0 z-40 overflow-hidden bg-[#07020f] text-white">
      {/* Animated, app-owned background: no reference artwork is used as the UI. */}
      <div className="premium-aurora absolute inset-0" aria-hidden="true">
        <div className="premium-orb premium-orb-one" />
        <div className="premium-orb premium-orb-two" />
        <div className="premium-orb premium-orb-three" />
        <div className="premium-stars" />
      </div>

      <div className="relative mx-auto flex h-full w-full max-w-[520px] flex-col">
        <header className="shrink-0 px-5 pb-2 pt-[max(18px,env(safe-area-inset-top))]">
          <div className="flex items-center justify-between gap-2">
            <button onClick={() => setProfileOpen(true)} className="premium-glass flex items-center gap-2 rounded-full px-3.5 py-2 text-xs font-semibold text-purple-100 active:scale-95"><User className="h-4 w-4 text-amber-300" /> Profil</button>
            <button onClick={() => setSubscriptionOpen(true)} className="premium-glass flex items-center gap-2 rounded-full px-3.5 py-2 text-xs font-semibold text-amber-100 active:scale-95">
              <Crown className="h-4 w-4 text-amber-300" /> Aboneliğim
            </button>
            <button onClick={() => onNavigate('home')} aria-label="Kapat" className="premium-glass rounded-full p-2 text-white/80 active:scale-95"><X className="h-5 w-5" /></button>
          </div>
        </header>

        <main className="scrollbar-hide min-h-0 flex-1 overflow-y-auto px-4 pb-8">
          <section className="relative overflow-hidden px-2 pb-5 pt-4 text-center">
            <div className="mx-auto mb-2 flex h-20 w-20 items-center justify-center rounded-full border border-amber-300/35 bg-white/10 shadow-[0_0_45px_rgba(251,191,36,.18)] backdrop-blur-xl">
              <img src="/dondu-3d.png" alt="Döndü Teyze" className="h-[74px] w-[74px] object-contain" />
            </div>
            <p className="text-[10px] font-bold tracking-[.34em] text-amber-300/80">DÖNDÜ TEYZE</p>
            <h1 className="mt-1 font-display text-[30px] font-black leading-tight text-white">Premium Dünyasına Hoş Geldin</h1>
            <p className="mx-auto mt-2 max-w-[370px] text-sm leading-5 text-purple-100/70">Daha fazla fal, daha fazla kredi ve reklamsız bir Döndü Teyze deneyimi.</p>
          </section>

          <section className="mb-4 rounded-[28px] border border-white/10 bg-white/[.07] p-4 shadow-2xl backdrop-blur-xl">
            <div className="mb-3 flex items-center justify-between">
              <div><p className="text-[10px] font-bold tracking-[.22em] text-amber-300">TEK SEFERLİK</p><h2 className="mt-1 text-lg font-bold">Kredini artır</h2></div>
              <Zap className="h-6 w-6 text-amber-300" />
            </div>
            <button onClick={() => handleBuy(CREDIT_PACK)} disabled={purchasing} className="premium-buy-card flex w-full items-center justify-between rounded-2xl border border-amber-300/25 bg-gradient-to-r from-amber-500/20 to-purple-500/10 p-4 text-left active:scale-[.985] disabled:opacity-60">
              <div><p className="text-base font-extrabold text-amber-100">250 Kredi</p><p className="mt-1 text-xs text-white/55">Tek seferlik satın alım • Premium abonelik değildir</p></div>
              <div className="flex items-center gap-1.5 text-right"><span className="font-extrabold text-white">₺149,99</span>{purchasing ? <Loader2 className="h-4 w-4 animate-spin" /> : <ChevronRight className="h-4 w-4 text-amber-300" />}</div>
            </button>
          </section>

          <section>
            <div className="mb-3 px-1"><p className="text-[10px] font-bold tracking-[.22em] text-amber-300">PREMİUM ÜYELİK</p><h2 className="mt-1 text-xl font-black">Sana en uygun paketi seç</h2></div>
            <div className="scrollbar-hide -mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2">
              {SUBSCRIPTIONS.map((offer) => (
                <button key={offer.id} onClick={() => handleBuy(offer)} disabled={purchasing} className={`relative min-w-[245px] snap-center overflow-hidden rounded-[25px] border p-4 text-left shadow-xl transition active:scale-[.985] disabled:opacity-60 ${offer.featured ? 'border-amber-300/60 bg-gradient-to-br from-amber-500/20 via-purple-900/45 to-black/30' : 'border-white/10 bg-white/[.07]'}`}>
                  {offer.badge && <span className="absolute right-3 top-3 rounded-full bg-amber-300 px-2.5 py-1 text-[8px] font-black tracking-wide text-[#2b0b28]">{offer.badge}</span>}
                  <div className="mt-4"><p className="text-sm font-semibold text-white/65">{offer.title}</p><div className="mt-1 flex items-end gap-1"><span className="font-display text-[27px] font-black text-amber-100">{offer.price}</span><span className="mb-1 text-xs text-white/50">{offer.period}</span></div></div>
                  <div className="my-4 h-px bg-white/10" />
                  <ul className="space-y-2.5 text-xs text-white/80"><li className="flex gap-2"><Check className="h-4 w-4 shrink-0 text-emerald-300" /> Her gün <b>20 kredi</b></li><li className="flex gap-2"><Check className="h-4 w-4 shrink-0 text-emerald-300" /> Reklamsız kullanım</li><li className="flex gap-2"><Check className="h-4 w-4 shrink-0 text-emerald-300" /> Öncelikli fal</li></ul>
                  <div className="mt-4 rounded-xl bg-amber-300 py-2.5 text-center text-xs font-black text-[#25081f]">{purchasing ? 'İşleniyor…' : 'Premium’a Geç'}</div>
                </button>
              ))}
            </div>
          </section>

          <section className="mt-5 grid grid-cols-3 gap-2">
            {[['20', 'Günlük kredi'], ['∞', 'Reklamsız'], ['★', 'Öncelikli fal']].map(([value, label]) => <div key={label} className="premium-glass rounded-2xl px-2 py-3 text-center"><p className="font-display text-lg font-black text-amber-200">{value}</p><p className="mt-0.5 text-[9px] text-white/55">{label}</p></div>)}
          </section>

          {purchaseError && <div className="mt-4 rounded-2xl border border-red-400/30 bg-red-500/10 p-3 text-center text-xs font-semibold text-red-100">{purchaseError}</div>}

          <section className="mt-5 rounded-2xl border border-white/10 bg-black/20 p-4 text-center backdrop-blur-md">
            <div className="flex items-center justify-center gap-2 text-xs font-semibold text-white/70"><ShieldCheck className="h-4 w-4 text-emerald-300" /> Güvenli ödeme Google Play üzerinden yapılır.</div>
            <div className="mt-3 flex justify-center gap-4 text-[10px] text-white/45"><button onClick={() => setLegalType('privacy')} className="underline underline-offset-2">Gizlilik Politikası</button><span>•</span><button onClick={() => setLegalType('user-agreement')} className="underline underline-offset-2">Kullanıcı Sözleşmesi</button></div>
          </section>
        </main>
      </div>

      {subscriptionOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 px-4 backdrop-blur-md" onClick={() => setSubscriptionOpen(false)}>
          <div className="w-full max-w-md rounded-3xl border border-amber-400/35 bg-gradient-to-b from-[#21082f] to-[#09030f] p-5 shadow-[0_0_55px_rgba(245,158,11,.18)]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between"><div><p className="text-[10px] tracking-[.2em] text-amber-300">DÖNDÜ TEYZE</p><h2 className="font-display text-2xl font-bold text-amber-100">Aboneliğim</h2></div><button onClick={() => setSubscriptionOpen(false)} className="rounded-full border border-purple-400/30 p-2 text-purple-200"><X className="h-4 w-4" /></button></div>
            {subscription ? <div className="mt-4 space-y-3"><div className="rounded-2xl border border-amber-400/35 bg-amber-500/10 p-4"><div className="flex items-center gap-3"><Crown className="h-7 w-7 text-amber-300" /><div><p className="text-xs text-purple-200/60">Aktif paket</p><p className="font-display text-lg font-bold text-amber-100">{activePlanName}</p></div></div><div className="mt-3 grid grid-cols-2 gap-2 text-xs"><InfoRow label="Günlük kredi" value={`${subscription.dailyCredits}`} /><InfoRow label="Reklam" value={subscription.adFree ? 'Kapalı' : 'Açık'} /><InfoRow label="Kalan süre" value={`${daysRemaining} gün`} /><InfoRow label="Bitiş" value={formatDate(subscription.expiresAt)} /></div></div><div className={`rounded-2xl border p-3 text-xs leading-relaxed ${subscription.autoRenew ? 'border-amber-400/25 bg-amber-500/10 text-amber-100' : 'border-emerald-400/25 bg-emerald-500/10 text-emerald-100'}`}>{subscription.autoRenew ? `Otomatik yenileme açık. ${formatDate(subscription.expiresAt)} tarihine kadar Premium avantajlarından yararlanabilirsiniz.` : `Aboneliğiniz ${formatDate(subscription.expiresAt)} tarihinde sona erecek. Bu tarihe kadar Premium avantajlarından yararlanmaya devam edebilirsiniz.`}</div><button onClick={openGooglePlaySubscriptions} className="w-full rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-4 py-3 text-sm font-bold text-[#1a071e]">Google Play'de Aboneliği Yönet</button><p className="text-center text-[9px] text-purple-300/50">İptal ederseniz mevcut satın alınmış dönem bitene kadar Premium devam eder.</p></div> : <div className="mt-6 rounded-2xl border border-purple-400/20 bg-black/20 p-5 text-center"><CreditCard className="mx-auto h-9 w-9 text-amber-300" /><p className="mt-2 font-semibold text-amber-100">Aktif aboneliğiniz yok</p><p className="mt-1 text-xs text-purple-200/60">Bir Premium paketi seçerek avantajlardan yararlanabilirsiniz.</p>{!authUser && <button onClick={() => { setSubscriptionOpen(false); (onOpenLogin ?? onRequireAuth)?.(); }} className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-5 py-2.5 text-sm font-bold text-[#1a071e]"><User className="h-4 w-4" /> Giriş Yap</button>}</div>}
          </div>
        </div>
      )}

      {profileOpen && (
        <div className="fixed inset-0 z-[75] flex items-center justify-center bg-black/80 px-4 backdrop-blur-md" onClick={() => setProfileOpen(false)}>
          <div className="w-full max-w-md rounded-3xl border border-amber-400/30 bg-gradient-to-b from-[#21082f] to-[#09030f] p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between"><div><p className="text-[10px] tracking-[.2em] text-amber-300">DÖNDÜ TEYZE</p><h2 className="font-display text-2xl font-bold text-amber-100">Profil</h2></div><button onClick={() => setProfileOpen(false)} className="rounded-full border border-purple-400/30 p-2 text-purple-200"><X className="h-4 w-4" /></button></div>
            {authUser ? <div className="mt-4 space-y-3"><div className="rounded-2xl border border-white/10 bg-white/5 p-4"><p className="text-xs text-purple-200/50">Giriş yapılan hesap</p><p className="mt-1 font-semibold text-white">{authUser.email}</p></div><div className="rounded-2xl border border-red-400/20 bg-red-500/5 p-4"><h3 className="font-semibold text-red-100">Ayarlar</h3><button onClick={handleDeleteAccount} disabled={deletingAccount} className="mt-3 w-full rounded-xl border border-red-400/40 bg-red-500/10 px-4 py-3 text-sm font-bold text-red-100 disabled:opacity-50">{deletingAccount ? 'Hesap siliniyor…' : 'Hesabımı Sil'}</button><p className="mt-2 text-[10px] leading-4 text-red-100/55">Bu işlem hesabınızı ve ilişkili kullanıcı verilerini kalıcı olarak siler.</p>{deleteError && <p className="mt-2 text-xs text-red-200">{deleteError}</p>}</div></div> : <div className="mt-6 text-center"><User className="mx-auto h-10 w-10 text-amber-300" /><p className="mt-3 font-semibold text-amber-100">Henüz giriş yapmadınız</p><p className="mt-1 text-xs text-purple-200/60">Profilinizi ve hesabınızı yönetmek için giriş yapın.</p><button onClick={() => { setProfileOpen(false); (onOpenLogin ?? onRequireAuth)?.(); }} className="mt-4 w-full rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-4 py-3 text-sm font-bold text-[#1a071e]">Giriş Yap</button></div>}
          </div>
        </div>
      )}

      {selectedOffer && <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 px-5 backdrop-blur-md" onClick={() => setSelectedOffer(null)}><div className="w-full max-w-sm rounded-3xl border border-amber-400/50 bg-gradient-to-b from-[#21082f] to-[#09030f] p-6 text-center" onClick={(e) => e.stopPropagation()}><div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-amber-400/50 bg-amber-500/10"><Check className="h-8 w-8 text-amber-300" /></div><h2 className="mt-4 font-display text-xl font-bold text-amber-100">Satın Alma Başarılı</h2><p className="mt-2 text-sm text-purple-100/80"><strong className="text-amber-200">{selectedOffer.title}</strong> paketiniz aktifleştirildi.</p>{selectedOffer.recurring && <p className="mt-2 text-xs text-purple-200/65">Her gün 20 kredi hesabınıza eklenir ve Premium süresince reklamlar gösterilmez.</p>}<button onClick={() => { setSelectedOffer(null); onNavigate('home'); }} className="mt-5 w-full rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-4 py-3 font-display font-bold text-[#1a071e]">Tamam</button></div></div>}

      <LegalModal type={legalType} onClose={() => setLegalType(null)} />
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) { return <div className="rounded-xl border border-purple-400/15 bg-black/20 p-2"><p className="text-[9px] text-purple-200/50">{label}</p><p className="mt-0.5 font-semibold text-amber-100">{value}</p></div>; }

export default PremiumPage;
