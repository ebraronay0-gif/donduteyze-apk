import { useState, useEffect, useCallback } from 'react';
import { Shield, LayoutDashboard, Users, DollarSign, MessageCircle, Bell, LogOut, Menu, X, Headset } from 'lucide-react';
import { supabase, verifyAdminAccess } from '@/lib/supabase';
import AdminLoginPage from '@/pages/admin/AdminLoginPage';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import UserManagement from '@/pages/admin/UserManagement';
import ContentPricing from '@/pages/admin/ContentPricing';
import SupportChat from '@/pages/admin/SupportChat';
import NotificationsPage from '@/pages/admin/NotificationsPage';
import LiveChatAdmin from '@/pages/admin/LiveChatAdmin';

type AdminSection = 'dashboard' | 'users' | 'pricing' | 'support' | 'livechat' | 'notifications';

const NAV_ITEMS: { id: AdminSection; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Genel Bakış', icon: LayoutDashboard },
  { id: 'users', label: 'Kullanıcılar', icon: Users },
  { id: 'pricing', label: 'İçerik & Fiyat', icon: DollarSign },
  { id: 'livechat', label: 'Canlı Falcı Sohbeti', icon: Headset },
  { id: 'support', label: 'Canlı Destek', icon: MessageCircle },
  { id: 'notifications', label: 'Bildirimler', icon: Bell },
];

function AdminPanel() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [checking, setChecking] = useState(true);
  const [section, setSection] = useState<AdminSection>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    verifyAdminAccess().then((ok) => { setLoggedIn(ok); setChecking(false); });
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_OUT') {
        setLoggedIn(false);
      } else {
        setTimeout(() => { void verifyAdminAccess().then(setLoggedIn); }, 0);
      }
    });
    return () => data.subscription.unsubscribe();
  }, []);

  const handleLogout = useCallback(() => {
    void supabase.auth.signOut();
    setLoggedIn(false);
  }, []);

  if (checking) {
    return <div className="flex min-h-screen items-center justify-center bg-night-900"><span className="h-8 w-8 animate-spin rounded-full border-2 border-gold-400/30 border-t-gold-400" /></div>;
  }

  if (!loggedIn) {
    return <AdminLoginPage onSuccess={() => setLoggedIn(true)} />;
  }

  const currentNav = NAV_ITEMS.find((n) => n.id === section);

  return (
    <div className="flex min-h-screen bg-night-900 text-mystic-100">
      {/* Sidebar - desktop */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-mystic-700/40 bg-night-800/80 backdrop-blur-sm md:flex">
        <div className="flex items-center gap-2 border-b border-mystic-700/40 px-5 py-4">
          <Shield className="h-6 w-6 text-gold-300" />
          <span className="font-display text-lg font-bold tracking-wider text-shimmer">ADMIN</span>
        </div>
        <nav className="flex-1 space-y-1 p-3">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setSection(item.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                  active
                    ? 'bg-gold-900/30 text-gold-200 border border-gold-400/30'
                    : 'text-mystic-300 hover:bg-night-700/60 hover:text-mystic-100'
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="border-t border-mystic-700/40 p-3">
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-rose-300 transition hover:bg-rose-900/20"
          >
            <LogOut className="h-4 w-4" />
            Çıkış Yap
          </button>
        </div>
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 md:hidden" onClick={() => setSidebarOpen(false)}>
          <div className="absolute inset-0 bg-night-900/80 backdrop-blur-sm" />
          <aside
            className="absolute left-0 top-0 h-full w-64 border-r border-mystic-700/40 bg-night-800/95 p-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between px-2">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-gold-300" />
                <span className="font-display text-base font-bold text-shimmer">ADMIN</span>
              </div>
              <button onClick={() => setSidebarOpen(false)} className="text-mystic-300">
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = section === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => { setSection(item.id); setSidebarOpen(false); }}
                    className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                      active ? 'bg-gold-900/30 text-gold-200 border border-gold-400/30' : 'text-mystic-300 hover:bg-night-700/60'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </button>
                );
              })}
            </nav>
            <button
              onClick={handleLogout}
              className="mt-4 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-rose-300 transition hover:bg-rose-900/20"
            >
              <LogOut className="h-4 w-4" />
              Çıkış Yap
            </button>
          </aside>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 overflow-x-hidden">
        {/* Mobile header */}
        <div className="sticky top-0 z-30 flex items-center justify-between border-b border-mystic-700/40 bg-night-800/80 px-4 py-3 backdrop-blur-sm md:hidden">
          <button onClick={() => setSidebarOpen(true)} className="text-mystic-200">
            <Menu className="h-5 w-5" />
          </button>
          <span className="font-display text-sm font-semibold text-gold-200">{currentNav?.label}</span>
          <button onClick={handleLogout} className="text-rose-300">
            <LogOut className="h-5 w-5" />
          </button>
        </div>

        <div className="p-4 md:p-6 lg:p-8">
          {section === 'dashboard' && <AdminDashboard />}
          {section === 'users' && <UserManagement />}
          {section === 'pricing' && <ContentPricing />}
          {section === 'livechat' && <LiveChatAdmin />}
          {section === 'support' && <SupportChat />}
          {section === 'notifications' && <NotificationsPage />}
        </div>
      </main>
    </div>
  );
}

export default AdminPanel;
