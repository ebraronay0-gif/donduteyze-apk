import { X, FileText, Shield } from 'lucide-react';

export type LegalType = 'privacy' | 'user-agreement';
interface LegalModalProps { type: LegalType | null; onClose: () => void; }

const CONTENT: Record<LegalType, { title: string; icon: typeof FileText; intro: string; sections: Array<{ heading: string; paragraphs: string[] }> }> = {
  privacy: {
    title: 'Gizlilik Politikası', icon: Shield, intro: 'Son Güncelleme Tarihi: 29 Ağustos 2026',
    sections: [
      { heading: 'Geliştirici ve İletişim', paragraphs: ['Uygulama: Döndü Teyze. Gizlilik ve veri talepleri için iletişim: donduteyze00@outlook.com.'] },
      { heading: '1. İşlenen Veriler', paragraphs: ['Hesap bilgileri (e-posta ve hesap kimliği), kullanıcı tarafından sağlanan profil bilgileri, kredi ve abonelik bilgileri, fal fotoğrafları, fal soruları ve oluşturulan fal sonuçları, canlı destek/sohbet mesajları, bildirim cihaz tokenı ve uygulamanın çalışması için gerekli teknik/analitik olaylar işlenebilir. Bazı analitik olaylar giriş yapmış kullanıcı hesabıyla ilişkilendirilebilir. Bazı tercih, kredi veya geçmiş bilgileri cihazda yerel olarak saklanabilir.', 'Ödeme kartı numarası gibi tam ödeme bilgileri Döndü Teyze tarafından saklanmaz; dijital satın alımlar Google Play ödeme altyapısı üzerinden yürütülür.'] },
      { heading: '2. Kullanım Amaçları', paragraphs: ['Veriler hesap yönetimi, fal hizmetlerinin sunulması, fal geçmişinin gösterilmesi, kredi ve Premium özelliklerinin çalıştırılması, canlı destek/sohbet, bildirim gönderimi, güvenlik, kötüye kullanımın önlenmesi, hata tespiti, performans ve teknik analiz ile yasal yükümlülüklerin yerine getirilmesi amacıyla işlenir.'] },
      { heading: '3. Fal Fotoğrafları ve İçerikler', paragraphs: ['Kullanıcının yüklediği fal fotoğrafları, sorular ve metinler fal hizmetinin oluşturulması için teknik altyapıda işlenebilir ve gerekli olduğu sürece saklanabilir. Bu içerikler hizmetin sunulması dışında reklam amacıyla satılmaz.'] },
      { heading: '4. Üçüncü Taraf Hizmetler', paragraphs: ['Uygulama; Supabase (kimlik doğrulama, veritabanı ve sunucu altyapısı), Firebase Cloud Messaging (push bildirimleri), Google Play Services/Google Play Billing (Android ve satın alma işlemleri), Google AdMob (reklam hizmetleri) ve fal yorumlama/AI altyapısı gibi üçüncü taraf hizmetlerden yararlanabilir. Bu hizmetler kendi sistemlerinde kendi politikaları kapsamında veri işleyebilir.'] },
      { heading: '5. Reklamlar ve Ödemeler', paragraphs: ['Google AdMob reklamları kullanılabilir. Reklam hizmetleri kendi politikaları kapsamında cihaz, reklam ve kullanım verilerini işleyebilir. Dijital ürün ve Premium abonelik satın alımları Google Play Faturalandırma Sistemi üzerinden yapılır; kart bilgileriniz Döndü Teyze tarafından saklanmaz.'] },
      { heading: '6. Verilerin Saklanması ve Silinmesi', paragraphs: ['Veriler, hizmetin sunulması, güvenlik, yasal yükümlülükler veya meşru iş amaçları için gerekli olduğu sürece saklanabilir. Hesap silme talebinde hesapla ilişkilendirilebilen ve yasal olarak tutulması gerekmeyen veriler silinir. Yasal olarak saklanması gereken veriler ilgili süre boyunca tutulabilir.'] },
      { heading: '7. Hesap Silme', paragraphs: ['Uygulama içinden Profil → Ayarlar → Hesabımı Sil yoluyla hesap silme işlemi başlatılabilir. Ayrıca Google Play gerekliliklerine uygun olarak uygulama dışında da hesap silme talebi alınır.'] },
      { heading: '8. Güvenlik', paragraphs: ['Verilerin yetkisiz erişime karşı korunması için erişim kontrolleri ve güvenli iletişim yöntemleri uygulanır. Ancak internet üzerinden hiçbir aktarım yöntemi mutlak güvenlik garantisi vermez.'] },
      { heading: '9. KVKK ve Veri Koruma Hakları', paragraphs: ['Türkiye bakımından 6698 sayılı KVKK ve uygulanabilir olduğu ölçüde diğer veri koruma mevzuatındaki haklar saklıdır. Veri erişimi, düzeltme ve silme talepleri donduteyze00@outlook.com adresinden iletilebilir.'] },
      { heading: '10. Yaş Sınırı', paragraphs: ['Döndü Teyze 18 yaş ve üzerindeki kullanıcılar için tasarlanmıştır.'] },
      { heading: '11. Değişiklikler', paragraphs: ['Bu politika gerektiğinde güncellenebilir. Güncel sürüm uygulama içinde ve yayınlanan gizlilik politikası sayfasında gösterilir.'] },
      { heading: 'İletişim', paragraphs: ['Gizlilik ve veri talepleri: donduteyze00@outlook.com'] },
    ],
  },
  'user-agreement': {
    title: 'Kullanıcı Sözleşmesi ve Kullanım Şartları', icon: FileText, intro: 'Son Güncelleme Tarihi: 28 Ağustos 2026',
    sections: [
      { heading: '', paragraphs: ['Döndü Teyze uygulamasını kullanarak aşağıdaki şartları kabul etmiş olursunuz.'] },
      { heading: '1. Eğlence Amacı ve Sorumluluk Reddi', paragraphs: ['Kahve falı, tarot, astroloji ve diğer yorumlar yalnızca eğlence ve keyif amaçlıdır. Bilimsel, resmi veya hukuki kesinlik taşımaz.', 'Uygulamadaki içeriklere dayanarak tıbbi, hukuki, finansal veya hayati karar verilmemelidir.'] },
      { heading: '2. Yaş Sınırı', paragraphs: ['Uygulama 18 yaş ve üzeri kullanıcılar için tasarlanmıştır.'] },
      { heading: '3. Abonelik, Kredi ve Ödemeler', paragraphs: ['Dijital ürün ve abonelik satın alımları Google Play Faturalandırma Sistemi üzerinden yapılır.', 'Haftalık, aylık ve yıllık abonelikler iptal edilmediği sürece dönem sonunda yenilenebilir. Abonelik Google Play Hesap Ayarları üzerinden yönetilebilir veya iptal edilebilir.', 'İade işlemleri Google Play politikalarına tabidir.'] },
      { heading: '4. Fikri Mülkiyet', paragraphs: ['Döndü Teyze uygulamasının tasarımı, yazılımı, metinleri, görselleri ve markasına ilişkin haklar saklıdır. İzinsiz kopyalanamaz veya ticari amaçla kullanılamaz.'] },
      { heading: 'İletişim', paragraphs: ['Sorularınız için donduteyze00@outlook.com adresinden veya uygulama içi destekten bize ulaşabilirsiniz.'] },
    ],
  },
};

export default function LegalModal({ type, onClose }: LegalModalProps) {
  if (!type) return null;
  const item = CONTENT[type];
  const Icon = item.icon;
  return <div className="fixed inset-0 z-[120] flex items-center justify-center bg-night-950/90 p-4 backdrop-blur-sm" onClick={onClose}>
    <div className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-gold-400/30 bg-night-800 p-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
      <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><Icon className="h-5 w-5 text-gold-300" /><h2 className="font-display text-xl font-semibold text-gold-100">{item.title}</h2></div><button onClick={onClose} aria-label="Kapat" className="rounded-lg p-2 text-mystic-400 hover:text-mystic-100"><X className="h-5 w-5" /></button></div>
      <div className="mb-4 rounded-xl border border-gold-400/20 bg-gold-950/15 p-3 text-xs font-semibold leading-5 text-gold-100/85">{item.intro}</div>
      <div className="space-y-5 text-sm leading-7 text-mystic-200">
        {item.sections.map((section, i) => <section key={i} className={section.heading ? 'border-t border-mystic-700/40 pt-4' : ''}>
          {section.heading && <h3 className="mb-2 font-display text-base font-semibold text-gold-200">{section.heading}</h3>}
          <div className="space-y-2">{section.paragraphs.map((p, j) => <p key={j}>{p}</p>)}</div>
        </section>)}
      </div>
      <button onClick={onClose} className="mt-6 w-full rounded-xl border border-gold-400/40 bg-gold-900/20 px-4 py-3 text-sm font-semibold text-gold-200">Kapat</button>
    </div>
  </div>;
}
