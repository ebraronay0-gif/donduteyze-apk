import { registerPlugin } from '@capacitor/core';
import { supabase } from './supabase';

interface PushNotificationsPlugin {
  requestPermissions(): Promise<{ receive: 'prompt' | 'prompt-with-rationale' | 'granted' | 'denied' }>;
  register(): Promise<void>;
  addListener(eventName: 'registration', listenerFunc: (token: { value: string }) => void): Promise<{ remove: () => Promise<void> }>;
  addListener(eventName: 'registrationError', listenerFunc: (error: unknown) => void): Promise<{ remove: () => Promise<void> }>;
  addListener(eventName: 'pushNotificationReceived', listenerFunc: (notification: { title?: string; body?: string; data?: Record<string, unknown> }) => void): Promise<{ remove: () => Promise<void> }>;
  addListener(eventName: 'pushNotificationActionPerformed', listenerFunc: (event: { notification?: { data?: Record<string, unknown> } }) => void): Promise<{ remove: () => Promise<void> }>;
}

interface LocalNotificationsPlugin {
  requestPermissions(): Promise<{ display: 'prompt' | 'prompt-with-rationale' | 'granted' | 'denied' }>;
  createChannel?(options: { id: string; name: string; description?: string; importance?: number; sound?: string }): Promise<void>;
  schedule(options: { notifications: Array<{ id: number; title: string; body: string; extra?: Record<string, unknown>; channelId?: string; schedule?: { at: Date } }> }): Promise<void>;
}

const PushNotifications = registerPlugin<PushNotificationsPlugin>('PushNotifications');
const LocalNotifications = registerPlugin<LocalNotificationsPlugin>('LocalNotifications');

let listenersInstalled = false;
let foregroundNotificationId = 1000;

async function saveToken(token: string, ownerId: string, role: 'user' | 'admin'): Promise<void> {
  await supabase.functions.invoke('register-push-token', {
    body: { token, ownerId, role },
  });
}

async function setupNativePush(onRegistered: (token: string) => Promise<void>): Promise<void> {
  try {
    const permission = await PushNotifications.requestPermissions();
    if (permission.receive !== 'granted') return;
    try { await LocalNotifications.requestPermissions(); } catch { /* web/unsupported */ }
    try { await LocalNotifications.createChannel?.({ id: 'donduteyze_chat', name: 'Döndü Teyze Sohbet', description: 'Canlı sohbet mesajları', importance: 5, sound: 'default' }); } catch { /* ignore */ }

    await PushNotifications.addListener('registration', ({ value }) => {
      void onRegistered(value);
    });
    await PushNotifications.addListener('registrationError', (error) => {
      console.error('Push registration error', error);
    });

    if (!listenersInstalled) {
      listenersInstalled = true;
      await PushNotifications.addListener('pushNotificationReceived', async (notification) => {
        // FCM shows notifications automatically in the background. When the
        // app is open, create a native local notification so the phone still
        // alerts the user.
        try {
          await LocalNotifications.requestPermissions();
          await LocalNotifications.schedule({
            notifications: [{
              id: foregroundNotificationId++,
              title: notification.title || 'Döndü Teyze',
              body: notification.body || 'Yeni bir mesajınız var.',
              extra: notification.data,
              channelId: 'donduteyze_chat',
            }],
          });
        } catch {
          // Native local notifications may be unavailable on web builds.
        }
      });
    }

    await PushNotifications.register();
  } catch (error) {
    // Browser/web builds do not have the native Capacitor implementation.
    console.warn('Native push notifications unavailable', error);
  }
}

export async function registerUserPush(userId: string): Promise<void> {
  await setupNativePush((token) => saveToken(token, userId, 'user'));
}

export async function registerAdminPush(): Promise<void> {
  try {
    const permission = await PushNotifications.requestPermissions();
    if (permission.receive !== 'granted') return;
    try { await LocalNotifications.requestPermissions(); } catch { /* web/unsupported */ }
    try { await LocalNotifications.createChannel?.({ id: 'donduteyze_chat', name: 'Döndü Teyze Sohbet', description: 'Canlı sohbet mesajları', importance: 5, sound: 'default' }); } catch { /* ignore */ }

    await PushNotifications.addListener('registration', async ({ value }) => {
      const { error } = await supabase.functions.invoke('register-push-token', {
        body: { token: value, role: 'admin' },
      });
      if (error) console.error('Admin push token registration failed', error);
    });
    await PushNotifications.addListener('registrationError', (error) => {
      console.error('Admin push registration error', error);
    });

    if (!listenersInstalled) {
      listenersInstalled = true;
      await PushNotifications.addListener('pushNotificationReceived', async (notification) => {
        try {
          await LocalNotifications.requestPermissions();
          await LocalNotifications.schedule({
            notifications: [{
              id: foregroundNotificationId++,
              title: notification.title || 'Döndü Teyze',
              body: notification.body || 'Yeni bir mesajınız var.',
              extra: notification.data,
              channelId: 'donduteyze_chat',
            }],
          });
        } catch {
          // Ignore on unsupported platforms.
        }
      });
    }

    await PushNotifications.register();
  } catch (error) {
    console.warn('Native admin push notifications unavailable', error);
  }
}


export async function scheduleFortuneReadyNotification(readingId: string, readyAt: string): Promise<void> {
  try {
    const permission = await LocalNotifications.requestPermissions();
    if (permission.display !== 'granted') return;

    const when = new Date(readyAt);
    if (Number.isNaN(when.getTime())) return;

    // Stable positive numeric ID derived from the reading ID so each fortune
    // gets its own notification without colliding with chat notifications.
    let id = 0;
    for (let i = 0; i < readingId.length; i++) {
      id = (id * 31 + readingId.charCodeAt(i)) % 2000000000;
    }
    id = Math.abs(id) + 1;

    await LocalNotifications.createChannel?.({
      id: 'donduteyze_fortune',
      name: 'Döndü Teyze Fal Sonuçları',
      description: 'Falınız hazır olduğunda bildirimler',
      importance: 5,
      sound: 'default',
    });

    await LocalNotifications.schedule({
      notifications: [{
        id,
        title: 'Döndü Teyze',
        body: 'Canım benim, falını yolladım. Seni bekliyorum.',
        extra: { type: 'fortune_ready', readingId },
        channelId: 'donduteyze_fortune',
        schedule: { at: when },
      }],
    } as any);
  } catch (error) {
    console.warn('Fortune ready notification could not be scheduled', error);
  }
}

export async function sendChatPush(messageId: string, channel: 'live_chat' | 'support'): Promise<void> {
  try {
    await supabase.functions.invoke('send-chat-push', {
      body: { messageId, channel },
    });
  } catch (error) {
    // The chat message is already persisted; push failure must never block chat.
    console.warn('Chat push could not be sent', error);
  }
}
