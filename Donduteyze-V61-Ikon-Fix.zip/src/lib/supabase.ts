import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || import.meta.env.SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.SUPABASE_ANON_KEY || '';

// The Android build can be created without Supabase secrets.  Supabase's
// createClient throws immediately when the URL/key are empty, which makes
// the whole React app fail before the first screen is rendered (black screen).
// Use a harmless placeholder client when secrets are not available; real
// GitHub Actions secrets override these values during the build.
const FALLBACK_URL = 'https://placeholder.supabase.co';
const FALLBACK_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJwbGFjZWhvbGRlciIsInJlZiI6InBsYWNlaG9sZGVyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDAwMDAwMDB9.placeholder-signature';

export const hasSupabaseConfig = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase = createClient(
  hasSupabaseConfig ? supabaseUrl : FALLBACK_URL,
  hasSupabaseConfig ? supabaseAnonKey : FALLBACK_KEY,
);

export async function verifyAdminAccess(): Promise<boolean> {
  if (!hasSupabaseConfig) return false;
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;
    const { data, error } = await supabase.from('admin_users').select('user_id').eq('user_id', user.id).maybeSingle();
    return !error && !!data;
  } catch { return false; }
}

export async function adminSignOut(): Promise<void> {
  try { await supabase.auth.signOut(); } catch { /* ignore */ }
}
