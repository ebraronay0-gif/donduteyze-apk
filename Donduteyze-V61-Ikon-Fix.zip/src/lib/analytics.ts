import { supabase, hasSupabaseConfig } from './supabase';
import { getStoredAuth } from './auth';

const SESSION_KEY = 'donduteyze_analytics_session';
const SESSION_STARTED_KEY = 'donduteyze_analytics_started';

function getSessionId(): string {
  try {
    const existing = localStorage.getItem(SESSION_KEY);
    if (existing) return existing;
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    localStorage.setItem(SESSION_KEY, id);
    return id;
  } catch {
    return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }
}

function getCountryHint(): string {
  try {
    const language = navigator.language || '';
    const match = language.match(/[-_]([A-Z]{2})$/i);
    if (match) return match[1].toUpperCase();
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    if (tz.startsWith('Europe/')) return tz.split('/')[1]?.replace('_', ' ') || 'EU';
    if (tz.startsWith('America/')) return 'US/AMER';
    if (tz.startsWith('Asia/')) return 'ASIA';
    if (tz.startsWith('Africa/')) return 'AFRICA';
    return 'UNKNOWN';
  } catch {
    return 'UNKNOWN';
  }
}

export async function trackEvent(
  eventName: string,
  properties: Record<string, unknown> = {},
): Promise<void> {
  if (!hasSupabaseConfig) return;
  try {
    await supabase.from('analytics_events').insert({
      session_id: getSessionId(),
      user_id: getStoredAuth()?.id || null,
      event_name: eventName,
      country: getCountryHint(),
      properties,
    });
  } catch {
    // Analytics must never block the app.
  }
}

export function startAnalytics(): void {
  if (!hasSupabaseConfig) return;

  let started = false;
  try {
    started = localStorage.getItem(SESSION_STARTED_KEY) === '1';
    if (!started) localStorage.setItem(SESSION_STARTED_KEY, '1');
  } catch {
    // ignore
  }

  if (!started) void trackEvent('app_open');

  const onPageHide = () => {
    void trackEvent('app_close');
  };
  window.addEventListener('pagehide', onPageHide, { once: true });

  void trackEvent('app_session');
}

export function trackFortuneOpen(fortuneType: string): void {
  void trackEvent('fortune_open', { fortune_type: fortuneType });
}

export function trackAd(eventName: 'ad_rewarded' | 'ad_closed'): void {
  void trackEvent(eventName);
}

export function trackPurchase(plan: string): void {
  void trackEvent('purchase', { plan });
}
