# Admin güvenliği - V60

Admin şifresi artık uygulama kodunda, `localStorage` içinde veya `app_config` tablosunda tutulmaz.

## Supabase'de bir kez yapılacak

1. **Authentication > Users** bölümünden admin için ayrı bir e-posta + güçlü şifre ile hesap oluştur.
2. Oluşturulan admin kullanıcısının UUID'sini kopyala.
3. SQL Editor'da çalıştır:

```sql
insert into public.admin_users (user_id)
values ('BURAYA_ADMIN_UUID');
```

4. `/admin` sayfasına bu e-posta ve şifreyle giriş yap.

Eski admin şifresi artık geçerli değildir. Admin paneli ve admin bildirim fonksiyonları Supabase Auth + `admin_users` kaydı ile yetkilendirilir.
