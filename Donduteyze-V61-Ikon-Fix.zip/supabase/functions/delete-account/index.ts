import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const authHeader = req.headers.get('Authorization');
  if (!authHeader) return Response.json({ error: 'Oturum gerekli.' }, { status: 401 });
  const userClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
  const { data: { user }, error: userError } = await userClient.auth.getUser();
  if (userError || !user) return Response.json({ error: 'Geçerli kullanıcı oturumu bulunamadı.' }, { status: 401 });
  const admin = createClient(supabaseUrl, serviceRoleKey);
  const email = user.email || '';
  const remove = async (query: any) => {
    const { error } = await query;
    if (error) throw error;
  };

  try {
    await remove(admin.from('push_tokens').delete().eq('owner_id', user.id));
    await remove(admin.from('live_chat_sessions').delete().eq('user_id', user.id));
    await remove(admin.from('support_messages').delete().eq('user_id', user.id));
    await remove(admin.from('notifications').delete().eq('target_user_id', user.id));
    await remove(admin.from('analytics_events').delete().eq('user_id', user.id));
    if (email) {
      await remove(admin.from('subscriptions').delete().eq('user_email', email));
      await remove(admin.from('fortune_readings').delete().eq('user_email', email));
      await remove(admin.from('app_users').delete().eq('email', email));
    }
  } catch {
    return Response.json({ error: 'Hesap verileri silinemedi. Lütfen tekrar deneyin.' }, { status: 500 });
  }
  const { error: deleteError } = await admin.auth.admin.deleteUser(user.id);
  if (deleteError) return Response.json({ error: 'Hesap silinemedi. Lütfen tekrar deneyin.' }, { status: 500 });
  return Response.json({ success: true });
});
