/* Döndü Teyze - Admin Authentication & RLS hardening */
CREATE TABLE IF NOT EXISTS public.admin_users (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "admins_read_own_admin_record" ON public.admin_users;
CREATE POLICY "admins_read_own_admin_record" ON public.admin_users
FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.admin_users a WHERE a.user_id = auth.uid());
$$;
REVOKE ALL ON FUNCTION public.is_admin() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;

DELETE FROM public.app_config WHERE key = 'admin_password';

DROP POLICY IF EXISTS "read_app_config" ON public.app_config;
DROP POLICY IF EXISTS "write_app_config" ON public.app_config;
DROP POLICY IF EXISTS "update_app_config" ON public.app_config;
DROP POLICY IF EXISTS "public_read_safe_app_config" ON public.app_config;
DROP POLICY IF EXISTS "admin_read_app_config" ON public.app_config;
DROP POLICY IF EXISTS "admin_insert_app_config" ON public.app_config;
DROP POLICY IF EXISTS "admin_update_app_config" ON public.app_config;
DROP POLICY IF EXISTS "admin_delete_app_config" ON public.app_config;
CREATE POLICY "public_read_safe_app_config" ON public.app_config FOR SELECT TO anon, authenticated
USING (key IN ('price_weekly','price_monthly','price_yearly','price_credits250','ticket_cost','lottery_prize'));
CREATE POLICY "admin_read_app_config" ON public.app_config FOR SELECT TO authenticated USING (public.is_admin());
CREATE POLICY "admin_insert_app_config" ON public.app_config FOR INSERT TO authenticated WITH CHECK (public.is_admin());
CREATE POLICY "admin_update_app_config" ON public.app_config FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "admin_delete_app_config" ON public.app_config FOR DELETE TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "read_all_app_users" ON public.app_users;
DROP POLICY IF EXISTS "insert_app_users" ON public.app_users;
DROP POLICY IF EXISTS "update_app_users" ON public.app_users;
DROP POLICY IF EXISTS "delete_app_users" ON public.app_users;
CREATE POLICY "users_read_own_app_user" ON public.app_users FOR SELECT TO authenticated
USING (id = auth.uid() OR email = (auth.jwt() ->> 'email') OR public.is_admin());
CREATE POLICY "users_insert_own_app_user" ON public.app_users FOR INSERT TO authenticated
WITH CHECK (id = auth.uid() OR email = (auth.jwt() ->> 'email') OR public.is_admin());
CREATE POLICY "admins_update_app_users" ON public.app_users FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "admins_delete_app_users" ON public.app_users FOR DELETE TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "read_all_support_messages" ON public.support_messages;
DROP POLICY IF EXISTS "insert_support_messages" ON public.support_messages;
DROP POLICY IF EXISTS "update_support_messages" ON public.support_messages;
CREATE POLICY "users_read_own_support_messages" ON public.support_messages FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.is_admin());
CREATE POLICY "users_insert_own_support_messages" ON public.support_messages FOR INSERT TO authenticated
WITH CHECK ((sender = 'user' AND user_id = auth.uid()) OR (sender = 'admin' AND public.is_admin()));
CREATE POLICY "users_update_own_support_messages" ON public.support_messages FOR UPDATE TO authenticated
USING (user_id = auth.uid() OR public.is_admin()) WITH CHECK (user_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "read_all_notifications" ON public.notifications;
DROP POLICY IF EXISTS "insert_notifications" ON public.notifications;
CREATE POLICY "read_notifications" ON public.notifications FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin_insert_notifications" ON public.notifications FOR INSERT TO authenticated WITH CHECK (public.is_admin());
CREATE POLICY "admin_update_notifications" ON public.notifications FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "admin_delete_notifications" ON public.notifications FOR DELETE TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "read_horoscope_pool" ON public.horoscope_pool;
DROP POLICY IF EXISTS "insert_horoscope_pool" ON public.horoscope_pool;
DROP POLICY IF EXISTS "update_horoscope_pool" ON public.horoscope_pool;
DROP POLICY IF EXISTS "delete_horoscope_pool" ON public.horoscope_pool;
CREATE POLICY "public_read_horoscope_pool" ON public.horoscope_pool FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin_insert_horoscope_pool" ON public.horoscope_pool FOR INSERT TO authenticated WITH CHECK (public.is_admin());
CREATE POLICY "admin_update_horoscope_pool" ON public.horoscope_pool FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "admin_delete_horoscope_pool" ON public.horoscope_pool FOR DELETE TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "select_live_chat_sessions_client" ON public.live_chat_sessions;
DROP POLICY IF EXISTS "insert_live_chat_sessions_client" ON public.live_chat_sessions;
DROP POLICY IF EXISTS "update_live_chat_sessions_client" ON public.live_chat_sessions;
DROP POLICY IF EXISTS "select_live_chat_messages_client" ON public.live_chat_messages;
DROP POLICY IF EXISTS "insert_live_chat_messages_client" ON public.live_chat_messages;
DROP POLICY IF EXISTS "update_live_chat_messages_client" ON public.live_chat_messages;
CREATE POLICY "admin_select_live_chat_sessions" ON public.live_chat_sessions FOR SELECT TO authenticated USING (public.is_admin());
CREATE POLICY "admin_update_live_chat_sessions" ON public.live_chat_sessions FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "admin_select_live_chat_messages" ON public.live_chat_messages FOR SELECT TO authenticated USING (public.is_admin());
CREATE POLICY "admin_insert_live_chat_messages" ON public.live_chat_messages FOR INSERT TO authenticated WITH CHECK (public.is_admin() AND sender = 'admin');
CREATE POLICY "admin_update_live_chat_messages" ON public.live_chat_messages FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "authenticated users can manage own push token" ON public.push_tokens;
CREATE POLICY "users_manage_own_push_token" ON public.push_tokens FOR ALL TO authenticated
USING (owner_id = auth.uid() AND role = 'user') WITH CHECK (owner_id = auth.uid() AND role = 'user');
CREATE POLICY "admins_manage_own_push_token" ON public.push_tokens FOR ALL TO authenticated
USING (owner_id = auth.uid() AND role = 'admin' AND public.is_admin())
WITH CHECK (owner_id = auth.uid() AND role = 'admin' AND public.is_admin());
