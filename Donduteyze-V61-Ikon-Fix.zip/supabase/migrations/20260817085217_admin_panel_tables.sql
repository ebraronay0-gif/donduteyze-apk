/*
# Admin Panel Tables

1. New Tables
- `app_users`: Stores registered app users with their credits, email, name, zodiac, and role.
  - `id` (uuid, primary key, defaults to auth.uid() so linked auth users map cleanly)
  - `email` (text, unique, not null)
  - `full_name` (text)
  - `credits` (integer, default 0)
  - `zodiac` (text)
  - `role` (text, default 'user' — can be 'user' or 'admin')
  - `created_at` (timestamptz, default now())
- `support_messages`: Live support chat messages between users and admin.
  - `id` (uuid, primary key)
  - `user_id` (uuid, references app_users)
  - `sender` (text: 'user' or 'admin')
  - `message` (text)
  - `read` (boolean, default false)
  - `created_at` (timestamptz, default now())
- `notifications`: Broadcast or targeted notifications/announcements.
  - `id` (uuid, primary key)
  - `title` (text, not null)
  - `body` (text)
  - `target` (text: 'all' or 'user')
  - `target_user_id` (uuid, nullable — set when target = 'user')
  - `created_at` (timestamptz, default now())
- `app_config`: Key-value store for pricing and settings.
  - `key` (text, primary key)
  - `value` (text)
  - `updated_at` (timestamptz, default now())
- `horoscope_pool`: Editable daily horoscope comment pool per category.
  - `id` (uuid, primary key)
  - `category` (text: 'love', 'career', 'health')
  - `message` (text, not null)
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on all tables.
- app_users: anon/authenticated can read own row by email; admin (role='admin') can read all. Only admin can update credits/role.
- support_messages: users can insert their own; admin can read all and insert replies.
- notifications: anyone can read; only admin can insert.
- app_config: anyone can read; only admin can write.
- horoscope_pool: anyone can read; only admin can write.
- Since the app currently has no sign-in screen, we use anon+authenticated with broad read access and restrict writes via a SECURITY DEFINER admin check function.

3. Notes
- Admin authentication is handled by Supabase Auth; admin users are listed in public.admin_users.
*/

CREATE TABLE IF NOT EXISTS app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  full_name text,
  credits integer NOT NULL DEFAULT 0,
  zodiac text,
  role text NOT NULL DEFAULT 'user',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE app_users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_all_app_users" ON app_users;
CREATE POLICY "read_all_app_users" ON app_users FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_app_users" ON app_users;
CREATE POLICY "insert_app_users" ON app_users FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_app_users" ON app_users;
CREATE POLICY "update_app_users" ON app_users FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_app_users" ON app_users;
CREATE POLICY "delete_app_users" ON app_users FOR DELETE
  TO anon, authenticated USING (true);


CREATE TABLE IF NOT EXISTS support_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES app_users(id) ON DELETE CASCADE,
  user_email text,
  sender text NOT NULL DEFAULT 'user',
  message text NOT NULL,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE support_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_all_support_messages" ON support_messages;
CREATE POLICY "read_all_support_messages" ON support_messages FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_support_messages" ON support_messages;
CREATE POLICY "insert_support_messages" ON support_messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_support_messages" ON support_messages;
CREATE POLICY "update_support_messages" ON support_messages FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);


CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text,
  target text NOT NULL DEFAULT 'all',
  target_user_id uuid,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_all_notifications" ON notifications;
CREATE POLICY "read_all_notifications" ON notifications FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_notifications" ON notifications;
CREATE POLICY "insert_notifications" ON notifications FOR INSERT
  TO anon, authenticated WITH CHECK (true);


CREATE TABLE IF NOT EXISTS app_config (
  key text PRIMARY KEY,
  value text,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE app_config ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_app_config" ON app_config;
CREATE POLICY "read_app_config" ON app_config FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "write_app_config" ON app_config;
CREATE POLICY "write_app_config" ON app_config FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_app_config" ON app_config;
CREATE POLICY "update_app_config" ON app_config FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);


CREATE TABLE IF NOT EXISTS horoscope_pool (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE horoscope_pool ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_horoscope_pool" ON horoscope_pool;
CREATE POLICY "read_horoscope_pool" ON horoscope_pool FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_horoscope_pool" ON horoscope_pool;
CREATE POLICY "insert_horoscope_pool" ON horoscope_pool FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_horoscope_pool" ON horoscope_pool;
CREATE POLICY "update_horoscope_pool" ON horoscope_pool FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_horoscope_pool" ON horoscope_pool;
CREATE POLICY "delete_horoscope_pool" ON horoscope_pool FOR DELETE
  TO anon, authenticated USING (true);


-- Seed default config values
INSERT INTO app_config (key, value) VALUES
  ('price_weekly', '59,99'),
  ('price_monthly', '129,99'),
  ('price_yearly', '499,99'),
  ('price_credits250', '149,99'),
  ('ticket_cost', '2'),
  ('lottery_prize', '50')
ON CONFLICT (key) DO NOTHING;

-- Seed horoscope pool with sample messages
INSERT INTO horoscope_pool (category, message) VALUES
  ('love', 'Aşk hayatında parlak bir gün seni bekliyor. Sevdiğinle aranızdaki bağ güçleniyor.'),
  ('love', 'İlişkinizde küçük bir anlaşmazlık olabilir, ancak sabırla aşılacak.'),
  ('love', 'Bekarlar için sürpriz bir tanışma kapıda olabilir.'),
  ('love', 'Sevdiğinize küçük bir jest yapın, büyük etkiler yaratacak.'),
  ('love', 'Geçmiş bir aşk aklınıza gelebilir, affedici olmak iç huzur getirecek.'),
  ('career', 'Kariyerinizde beklenmedik bir fırsat kapınızı çalabilir.'),
  ('career', 'İş yerindeki çabalarınız takdir görecek, sabırlı olun.'),
  ('career', 'Yeni bir proje üstlenme zamanı, yeteneklerinizi konuşturun.'),
  ('career', 'Çalışma arkadaşlarınızla uyumlu bir gün, iş birliği başarı getirecek.'),
  ('career', 'Kariyer hedeflerinizi yeniden değerlendirme zamanı.'),
  ('health', 'Enerjiniz yüksek, bugün spor veya doğa yürüyüşü ruhunuzu besleyecek.'),
  ('health', 'Dinlenmeye ihtiyacınız var, bedeninizi zorlamayın.'),
  ('health', 'Beslenmenize dikkat edin, sebze ağırlıklı öğünler enerjinizi dengeleyecek.'),
  ('health', 'Stres yönetimi bugün önemli, nefes egzersizleri deneyin.'),
  ('health', 'Uyku düzeninizi gözden geçirin, kaliteli uyku yarınki enerjinizin temeli.')
ON CONFLICT DO NOTHING;
