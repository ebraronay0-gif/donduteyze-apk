# V58 — Google Play veri ve hesap silme düzeltmeleri

- Gizlilik politikası gerçek veri akışına göre güncellendi.
- Hesap silme Edge Function eklendi.
- Hesap silme: Auth user + app_users + subscriptions + fortune_readings + support_messages + live_chat_sessions (mesajlar cascade) + push_tokens + hedef kullanıcı bildirimleri silinir.
- Analytics olaylarına `user_id` eklendi; oturum açmış kullanıcıların yeni analitik kayıtları hesapla ilişkilendirilir ve hesap silmede kaldırılır.
- Harici hesap silme sayfası `public/account/delete-account.html` eklendi. Bu sayfa Google Play Console'daki harici silme URL'si olarak, projenin gerçek public domain/GitHub Pages adresi üzerinden yayınlanmalıdır.
- Firebase client `google-services.json` içinde servis hesabı private key bulunmadığı doğrulandı.
- Google Play Data Safety beyanı ayrıca Play Console'da gerçek üretim servisleriyle eşleştirilmelidir.
