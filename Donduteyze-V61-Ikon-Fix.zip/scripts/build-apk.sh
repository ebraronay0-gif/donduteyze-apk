#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

if [ ! -s resources/launcher-icon-final.png ]; then
  echo "HATA: Döndü Teyze ikon dosyası bulunamadı."
  exit 1
fi

# Android project is intentionally created from Capacitor, then synchronized.
# The launcher icon is applied ONLY after sync so Capacitor cannot overwrite it.

echo "1/6 Web uygulaması derleniyor..."
npm run build

echo "2/6 Android projesi oluşturuluyor..."
if [ ! -d android ]; then
  npx cap add android
fi

if [ -s firebase-google-services.json ]; then
  cp -f firebase-google-services.json android/app/google-services.json
  python3 - <<'PY2'
from pathlib import Path
root = Path('android/build.gradle')
s = root.read_text()
if 'com.google.gms:google-services' not in s:
    marker = 'dependencies {'
    if marker in s:
        s = s.replace(marker, marker + "\n        classpath 'com.google.gms:google-services:4.4.2'", 1)
        root.write_text(s)
app = Path('android/app/build.gradle')
s = app.read_text()
if 'com.google.gms.google-services' not in s:
    s = "apply plugin: 'com.google.gms.google-services'\n" + s
    app.write_text(s)
PY2
else
  echo 'UYARI: firebase-google-services.json bulunamadı; FCM Android yapılandırması eksik.'
fi

echo "3/6 Capacitor senkronizasyonu..."
npx cap sync android

echo "4/6 Döndü Teyze launcher ikonu senkronizasyondan SONRA uygulanıyor..."
./scripts/apply-launcher-icon.sh

echo "5/6 Manifest ve kaynak doğrulaması..."
grep -q 'android:icon="@mipmap/donduteyze_launcher"' android/app/src/main/AndroidManifest.xml
grep -q 'android:roundIcon="@mipmap/donduteyze_launcher_round"' android/app/src/main/AndroidManifest.xml
if grep -Rqs 'android:icon="@mipmap/ic_launcher"' android/app/src/main; then
  echo 'HATA: Android kaynaklarında eski ic_launcher kullanımı bulundu.'
  exit 1
fi

echo "6/6 İKON TAMAM: @mipmap/donduteyze_launcher"
