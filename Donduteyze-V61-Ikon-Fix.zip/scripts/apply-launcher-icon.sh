#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

ICON="resources/launcher-icon-final.png"
RES="android/app/src/main/res"
MANIFEST="android/app/src/main/AndroidManifest.xml"

[ -s "$ICON" ] || { echo "HATA: $ICON bulunamadı"; exit 1; }
command -v convert >/dev/null 2>&1 || { sudo apt-get update && sudo apt-get install -y imagemagick; }

# Remove every possible Capacitor/default launcher resource.
find "$RES" -type f \( \
  -name 'ic_launcher*' -o \
  -name 'ic_launcher_foreground*' -o \
  -name 'ic_donduteyze*' \
\) -delete || true
rm -rf "$RES/mipmap-anydpi-v26" "$RES/mipmap-anydpi"

mkdir -p "$RES"/mipmap-mdpi "$RES"/mipmap-hdpi "$RES"/mipmap-xhdpi \
  "$RES"/mipmap-xxhdpi "$RES"/mipmap-xxxhdpi \
  "$RES"/mipmap-anydpi-v26 "$RES"/drawable-nodpi "$RES"/values

# Use a unique resource name. Capacitor cannot overwrite or win over this name.
cp -f "$ICON" "$RES/drawable-nodpi/donduteyze_launcher_foreground.png"

cat > "$RES/values/donduteyze_launcher.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="donduteyze_launcher_background">#16052F</color>
</resources>
XML

cat > "$RES/mipmap-anydpi-v26/donduteyze_launcher.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/donduteyze_launcher_background" />
    <foreground android:drawable="@drawable/donduteyze_launcher_foreground" />
</adaptive-icon>
XML
cp "$RES/mipmap-anydpi-v26/donduteyze_launcher.xml" \
   "$RES/mipmap-anydpi-v26/donduteyze_launcher_round.xml"

declare -A SIZES=([mdpi]=48 [hdpi]=72 [xhdpi]=96 [xxhdpi]=144 [xxxhdpi]=192)
for density in "${!SIZES[@]}"; do
  size="${SIZES[$density]}"
  convert "$ICON" -background '#16052F' -gravity center \
    -resize "${size}x${size}" -extent "${size}x${size}" \
    "$RES/mipmap-${density}/donduteyze_launcher.png"
  cp "$RES/mipmap-${density}/donduteyze_launcher.png" \
     "$RES/mipmap-${density}/donduteyze_launcher_round.png"
done

python3 - <<'PY'
from pathlib import Path
import re
p = Path('android/app/src/main/AndroidManifest.xml')
s = p.read_text()
a = s.index('<application')
b = s.index('>', a)
app = s[a:b]
app = re.sub(r'\s+android:icon="[^"]*"', '', app)
app = re.sub(r'\s+android:roundIcon="[^"]*"', '', app)
app += ' android:icon="@mipmap/donduteyze_launcher" android:roundIcon="@mipmap/donduteyze_launcher_round"'
p.write_text(s[:a] + app + s[b:])
PY

# Hard fail if the old Capacitor launcher is still referenced by the app.
if grep -q 'android:icon="@mipmap/ic_launcher"' "$MANIFEST"; then
  echo 'HATA: Manifest hâlâ Capacitor ic_launcher kullanıyor.'
  exit 1
fi

grep -q 'android:icon="@mipmap/donduteyze_launcher"' "$MANIFEST"
test -s "$RES/drawable-nodpi/donduteyze_launcher_foreground.png"
test -s "$RES/mipmap-anydpi-v26/donduteyze_launcher.xml"
test -s "$RES/mipmap-xxxhdpi/donduteyze_launcher.png"

echo "LAUNCHER ICON OK: Döndü Teyze"
