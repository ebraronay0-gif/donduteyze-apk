import { useState, useEffect } from 'react';
import { App as CapacitorApp } from '@capacitor/app';
import { Sparkles, Stars, Crown } from 'lucide-react';
import OnboardingPage from '@/pages/OnboardingPage';
import HomePage from '@/pages/HomePage';
import CoffeeFortunePage from '@/pages/CoffeeFortunePage';
import PalmFortunePage from '@/pages/PalmFortunePage';
import TarotFortunePage from '@/pages/TarotFortunePage';
import KatinaFortunePage from '@/pages/KatinaFortunePage';
import FaceFortunePage from '@/pages/FaceFortunePage';
import DreamFortunePage from '@/pages/DreamFortunePage';
import WheelFortunePage from '@/pages/WheelFortunePage';
import DiceFortunePage from '@/pages/DiceFortunePage';
import LotteryPage from '@/pages/LotteryPage';
import PremiumPage from '@/pages/PremiumPage';
import ZodiacPage from '@/pages/ZodiacPage';
import AuthPage from '@/pages/AuthPage';
import HistoryPage from '@/pages/HistoryPage';
import EarnPage from '@/pages/EarnPage';
import LiveChatPurchasePage from '@/pages/LiveChatPurchasePage';
import LiveChatPage from '@/pages/LiveChatPage';
import AdminPanel from '@/pages/admin/AdminPanel';
import BottomNavBar from '@/components/BottomNavBar';
import CreditHeader from '@/components/CreditHeader';
import SupportModal from '@/components/SupportModal';
import FloatingFortuneButton from '@/components/FloatingFortuneButton';
import BannerAd from '@/components/BannerAd';
import InterstitialAd from '@/components/InterstitialAd';
import { shouldShowInterstitial } from '@/lib/ads';
import { isAdFree } from '@/lib/subscriptions';
import type { UserProfile } from '@/lib/profile';
import { loadProfile } from '@/lib/profile';
import type { NavTabId } from '@/lib/navTabs';
import { getStoredAuth, clearStoredAuth, handleOAuthCallback } from '@/lib/auth';
import type { AuthUser } from '@/lib/auth';
import { supabase, hasSupabaseConfig } from '@/lib/supabase';
import { syncCreditsFromSubscription } from '@/lib/subscriptions';

type AuthView = 'login' | 'signup' | 'premium-warning' | null;

function App() {
  const [profile, setProfile] = useState<UserProfile | null>(() => loadProfile());
  const [activeTab, setActiveTab] = useState<NavTabId>('home');
  const [isAdminRoute, setIsAdminRoute] = useState(() => window.location.pathname === '/admin');
  const [authUser, setAuthUser] = useState<AuthUser | null>(() => getStoredAuth());
  const [authView, setAuthView] = useState<AuthView>(null);
  const [supportOpen, setSupportOpen] = useState(false);
  const [coffeeFortuneOpen, setCoffeeFortuneOpen] = useState(false);
  const [palmFortuneOpen, setPalmFortuneOpen] = useState(false);
  const [tarotFortuneOpen, setTarotFortuneOpen] = useState(false);
  const [katinaFortuneOpen, setKatinaFortuneOpen] = useState(false);
  const [faceFortuneOpen, setFaceFortuneOpen] = useState(false);
  const [dreamFortuneOpen, setDreamFortuneOpen] = useState(false);
  const [wheelOpen, setWheelOpen] = useState(false);
  const [diceOpen, setDiceOpen] = useState(false);
  const [lotteryOpen, setLotteryOpen] = useState(false);
  const [chatPurchaseOpen, setChatPurchaseOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [interstitialOpen, setInterstitialOpen] = useState(false);
  const [pendingNav, setPendingNav] = useState<(() => void) | null>(null);
  const fortuneOpen = coffeeFortuneOpen || palmFortuneOpen || tarotFortuneOpen || katinaFortuneOpen || faceFortuneOpen || dreamFortuneOpen || wheelOpen || diceOpen || lotteryOpen || chatPurchaseOpen || chatOpen;

  useEffect(() => {
    let listener: { remove: () => Promise<void> } | null = null;
    const processUrl = async (url?: string) => {
      if (!url || !url.startsWith('com.donduteyze.app://auth/callback')) return;
      const result = await handleOAuthCallback(url);
      if (result.user) {
        setAuthUser(result.user);
        setAuthView(null);
      } else if (result.error) {
        console.error(result.error);
      }
    };
    CapacitorApp.getLaunchUrl().then(({ url }) => processUrl(url));
    CapacitorApp.addListener('appUrlOpen', ({ url }) => processUrl(url)).then((handle) => { listener = handle; });
    return () => { listener?.remove(); };
  }, []);

  useEffect(() => {
    if (!hasSupabaseConfig) return;

    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      (async () => {
        if (event === 'SIGNED_IN' && session?.user) {
          const user: AuthUser = { id: session.user.id, email: session.user.email || '' };
          localStorage.setItem('donduteyze_auth_user', JSON.stringify(user));
          setAuthUser(user);
          setAuthView(null);
          syncCreditsFromSubscription(user);
        } else if (event === 'SIGNED_OUT') {
          clearStoredAuth();
          setAuthUser(null);
        }
      })();
    });
    return () => data.subscription.unsubscribe();
  }, []);

  const handleSignOut = () => {
    clearStoredAuth();
    if (hasSupabaseConfig) {
      supabase.auth.signOut();
    }
    setAuthUser(null);
  };

  const openFortuneWithAd = (openFn: () => void) => {
    if (!isAdFree() && shouldShowInterstitial()) {
      setPendingNav(() => openFn);
      setInterstitialOpen(true);
    } else {
      openFn();
    }
  };

  const handleInterstitialClose = () => {
    setInterstitialOpen(false);
    if (pendingNav) {
      pendingNav();
      setPendingNav(null);
    }
  };

  const authScreenActive = authView !== null || ((chatPurchaseOpen || chatOpen) && !authUser);

  if (authScreenActive && !isAdminRoute) {
    return (
      <>
        {authView === 'premium-warning' && (
          <AuthPage
            mode="signup"
            reasonText="Aldığınız krediyi saklayabilmek ve cihaz değiştirdiğinizde kaybetmemek için bir hesap oluşturmanız gerekiyor. Hesabınızla kredileriniz güvende kalır."
            onSuccess={() => { setAuthView(null); setActiveTab('premium'); }}
            onSwitchMode={(m) => setAuthView(m)}
            onBack={() => setAuthView(null)}
          />
        )}
        {authView === 'login' && (
          <AuthPage
            mode="login"
            compact
            topAligned
            showLegal
            onSuccess={() => setAuthView(null)}
            onSwitchMode={(m) => setAuthView(m)}
            onBack={() => setAuthView(null)}
          />
        )}
        {authView === 'signup' && (
          <AuthPage
            mode="signup"
            compact
            topAligned
            showLegal
            onSuccess={() => setAuthView(null)}
            onSwitchMode={(m) => setAuthView(m)}
            onBack={() => setAuthView(null)}
          />
        )}
        {authView === null && chatPurchaseOpen && !authUser && (
          <AuthPage mode="login" compact topAligned showLegal onSuccess={() => { setChatPurchaseOpen(false); setChatOpen(true); }} onSwitchMode={(m) => setAuthView(m)} onBack={() => { setChatPurchaseOpen(false); setAuthView(null); }} />
        )}
        {authView === null && chatOpen && !authUser && (
          <AuthPage mode="login" compact topAligned showLegal onSuccess={() => setAuthView(null)} onSwitchMode={(m) => setAuthView(m)} onBack={() => { setChatOpen(false); setAuthView(null); }} />
        )}
      </>
    );
  }

  if (isAdminRoute) {
    return <AdminPanel />;
  }

  if (!profile) {
    return <OnboardingPage onComplete={setProfile} />;
  }

  let page;
  if (coffeeFortuneOpen) {
    page = <CoffeeFortunePage onNavigate={(tab) => { setCoffeeFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (palmFortuneOpen) {
    page = <PalmFortunePage onNavigate={(tab) => { setPalmFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (tarotFortuneOpen) {
    page = <TarotFortunePage onNavigate={(tab) => { setTarotFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (katinaFortuneOpen) {
    page = <KatinaFortunePage onNavigate={(tab) => { setKatinaFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (faceFortuneOpen) {
    page = <FaceFortunePage onNavigate={(tab) => { setFaceFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (dreamFortuneOpen) {
    page = <DreamFortunePage onNavigate={(tab) => { setDreamFortuneOpen(false); setActiveTab(tab); }} />;
  } else if (wheelOpen) {
    page = <WheelFortunePage onNavigate={(tab) => { setWheelOpen(false); setActiveTab(tab); }} />;
  } else if (diceOpen) {
    page = <DiceFortunePage onNavigate={(tab) => { setDiceOpen(false); setActiveTab(tab); }} />;
  } else if (lotteryOpen) {
    page = <LotteryPage onNavigate={(tab) => { setLotteryOpen(false); setActiveTab(tab); }} />;
  } else if (chatPurchaseOpen) {
    page = (
      <LiveChatPurchasePage
        onNavigate={(tab) => { setChatPurchaseOpen(false); setActiveTab(tab); }}
        onOpenChat={() => { setChatPurchaseOpen(false); setChatOpen(true); }}
        authUser={authUser!}
        onRequireAuth={() => { setChatPurchaseOpen(false); setAuthView('login'); }}
        isLoggedIn={!!authUser}
      />
    );
  } else if (chatOpen) {
    page = (
      <LiveChatPage onNavigate={(tab) => { setChatOpen(false); setActiveTab(tab); }} authUser={authUser!} />
    );
  } else {
  switch (activeTab) {
    case 'home':
      page = <HomePage profile={profile} onNavigate={setActiveTab} onOpenCoffeeFortune={() => openFortuneWithAd(() => setCoffeeFortuneOpen(true))} onOpenPalmFortune={() => openFortuneWithAd(() => setPalmFortuneOpen(true))} onOpenTarotFortune={() => openFortuneWithAd(() => setTarotFortuneOpen(true))} onOpenKatinaFortune={() => openFortuneWithAd(() => setKatinaFortuneOpen(true))} onOpenFaceFortune={() => openFortuneWithAd(() => setFaceFortuneOpen(true))} onOpenDreamFortune={() => openFortuneWithAd(() => setDreamFortuneOpen(true))} onOpenWheel={() => openFortuneWithAd(() => setWheelOpen(true))} onOpenDice={() => openFortuneWithAd(() => setDiceOpen(true))} onOpenLottery={() => openFortuneWithAd(() => setLotteryOpen(true))} onOpenLiveChat={() => setChatPurchaseOpen(true)} />;
      break;
    case 'earn':
      page = <EarnPage onNavigate={setActiveTab} />;
      break;
    case 'history':
      page = <HistoryPage onNavigate={setActiveTab} />;
      break;
    case 'zodiac':
      page = <ZodiacPage userZodiac={profile.zodiac} />;
      break;
    case 'premium':
      page = <PremiumPage onNavigate={setActiveTab} onRequireAuth={() => setAuthView('premium-warning')} isLoggedIn={!!authUser} onOpenLiveChat={() => setChatPurchaseOpen(true)} authUser={authUser} />;
      break;
    default:
      page = <HomePage profile={profile} onNavigate={setActiveTab} onOpenCoffeeFortune={() => openFortuneWithAd(() => setCoffeeFortuneOpen(true))} onOpenPalmFortune={() => openFortuneWithAd(() => setPalmFortuneOpen(true))} onOpenTarotFortune={() => openFortuneWithAd(() => setTarotFortuneOpen(true))} onOpenKatinaFortune={() => openFortuneWithAd(() => setKatinaFortuneOpen(true))} onOpenFaceFortune={() => openFortuneWithAd(() => setFaceFortuneOpen(true))} onOpenDreamFortune={() => openFortuneWithAd(() => setDreamFortuneOpen(true))} onOpenWheel={() => openFortuneWithAd(() => setWheelOpen(true))} onOpenDice={() => openFortuneWithAd(() => setDiceOpen(true))} onOpenLottery={() => openFortuneWithAd(() => setLotteryOpen(true))} onOpenLiveChat={() => setChatPurchaseOpen(true)} />;
  }
  }

  return (
    <>
      <CreditHeader
        onNavigate={setActiveTab}
        onAdminAccess={() => setIsAdminRoute(true)}
        authUser={authUser}
        onAuthClick={() => setAuthView(authUser ? null : 'login')}
        onSignOut={handleSignOut}
      />
      {page}
      {!fortuneOpen && <FloatingFortuneButton onClick={() => setChatPurchaseOpen(true)} />}
      <BottomNavBar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onSupportClick={() => setSupportOpen(true)}
      />
      <SupportModal open={supportOpen} onClose={() => setSupportOpen(false)} />
      <InterstitialAd open={interstitialOpen} onClose={handleInterstitialClose} />
    </>
  );
}

export default App;
