import { useState, useCallback, useEffect, useRef } from 'react';
import { ArrowLeft, Send, MessageSquare, Sparkles, ShieldCheck } from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import { supabase } from '@/lib/supabase'; // Supabase bağlantısı

interface LiveChatPageProps {
  onNavigate: (tab: NavTabId) => void;
}

interface Message {
  id: string;
  sender: 'user' | 'admin';
  text: string;
  created_at: string;
}

function LiveChatPage({ onNavigate }: LiveChatPageProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'admin',
      text: 'Merhaba! Döndü Teyze Canlı Destek hattına hoş geldiniz. Size nasıl yardımcı olabilirim?',
      created_at: new Date().toISOString(),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = useCallback(async () => {
    if (!inputText.trim() || sending) return;

    const userMessageText = inputText.trim();
    setInputText('');
    setSending(true);

    const newUserMessage: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: userMessageText,
      created_at: new Date().toISOString(),
    };

    // Mesajları anında ekrana ekle
    setMessages((prev) => [...prev, newUserMessage]);

    try {
      // Mesajı Supabase veritabanına (Admin paneline düşmesi için) kaydediyoruz
      if (supabase) {
        await supabase.from('live_chat_messages').insert([
          {
            message: userMessageText,
            sender_type: 'user',
            created_at: new Date().toISOString(),
            is_read: false,
          },
        ]);
      }
    } catch (err) {
      console.error('Mesaj gönderilemedi:', err);
    } finally {
      setSending(false);

      // Admin simülasyonu / otomatik yanıt (Opsiyonel karşılama)
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            id: (Date.now() + 1).toString(),
            sender: 'admin',
            text: 'Mesajınız yetkili uzmanımıza iletildi. En kısa sürede buradan size yanıt vereceğiz.',
            created_at: new Date().toISOString(),
          },
        ]);
      }, 1500);
    }
  }, [inputText, sending]);

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-night-900 pb-24">
      <StarField count={50} />

      {/* Arka plan ışıkları */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-indigo-950/50 via-night-900/80 to-night-900" />

      {/* Üst Bar */}
      <div className="relative z-10 border-b border-indigo-500/20 bg-night-900/80 px-4 py-4 backdrop-blur-md">
        <div className="mx-auto flex max-w-2xl items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-indigo-400/30 bg-indigo-900/20 text-indigo-200 transition hover:border-indigo-400/60"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="relative">
                <div className="flex h-10 w-10 items-center justify-center rounded-full border border-indigo-400/40 bg-indigo-900/40 text-indigo-200">
                  <MessageSquare className="h-5 w-5" />
                </div>
                <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-night-900 bg-emerald-500" />
              </div>
              <div>
                <h1 className="font-display text-base font-semibold text-indigo-100">Canlı Destek</h1>
                <p className="text-xs text-emerald-400 font-medium">Müşteri Temsilcisi Çevrimiçi</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1 rounded-full border border-indigo-500/30 bg-indigo-950/40 px-3 py-1 text-[11px] text-indigo-300">
            <ShieldCheck className="h-3.5 w-3.5 text-indigo-400" />
            <span>Güvenli Hat</span>
          </div>
        </div>
      </div>

      {/* Mesajlaşma Alanı */}
      <div className="relative z-10 mx-auto w-full max-w-2xl flex-1 px-4 py-6 overflow-y-auto space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-gradient-to-r from-indigo-700 to-indigo-800 text-indigo-50 rounded-br-none border border-indigo-500/30 shadow-lg'
                  : 'bg-night-800/90 text-indigo-100 rounded-bl-none border border-indigo-500/20 shadow-md backdrop-blur-sm'
              }`}
            >
              {msg.sender === 'admin' && (
                <div className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold text-indigo-300">
                  <Sparkles className="h-3 w-3" />
                  <span>Döndü Teyze Destek Ekibi</span>
                </div>
              )}
              <p>{msg.text}</p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Mesaj Yazma Çubuğu */}
      <div className="fixed bottom-0 left-0 right-0 z-20 border-t border-indigo-500/20 bg-night-900/95 p-4 backdrop-blur-md">
        <div className="mx-auto flex max-w-2xl items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Mesajınızı yazın..."
            className="flex-1 rounded-2xl border border-indigo-500/30 bg-night-800/90 px-4 py-3 text-sm text-indigo-100 placeholder:text-indigo-300/40 focus:border-indigo-400 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputText.trim() || sending}
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-r from-indigo-600 to-indigo-800 text-indigo-100 shadow-lg transition hover:scale-105 disabled:opacity-50 disabled:hover:scale-100"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default LiveChatPage;
