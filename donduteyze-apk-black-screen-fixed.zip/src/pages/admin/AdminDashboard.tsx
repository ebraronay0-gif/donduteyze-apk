import { useState, useEffect } from 'react';
import { Users, Coins, TrendingUp, MessageCircle, Bell, Activity } from 'lucide-react';
import { supabase } from '@/lib/supabase';

function StatCard({ icon: Icon, label, value, color, glow }: { icon: typeof Users; label: string; value: string; color: string; glow: string }) {
  return (
    <div className="rounded-2xl border border-mystic-700/40 bg-night-800/60 p-5 backdrop-blur-sm" style={{ boxShadow: `0 4px 16px ${glow}` }}>
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-mystic-600/40 bg-night-700/60">
          <Icon className={`h-5 w-5 ${color}`} />
        </div>
        <div>
          <p className="text-xs text-mystic-400">{label}</p>
          <p className="font-display text-xl font-bold text-mystic-100">{value}</p>
        </div>
      </div>
    </div>
  );
}

function AdminDashboard() {
  const [stats, setStats] = useState({ users: 0, credits: 0, messages: 0, notifications: 0, revenue: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [usersRes, msgRes, notifRes] = await Promise.all([
          supabase.from('app_users').select('id, credits'),
          supabase.from('support_messages').select('id', { count: 'exact', head: true }),
          supabase.from('notifications').select('id', { count: 'exact', head: true }),
        ]);

        const users = usersRes.data || [];
        const totalCredits = users.reduce((sum, u) => sum + (u.credits || 0), 0);
        const estimatedRevenue = users.length * 50;

        setStats({
          users: users.length,
          credits: totalCredits,
          messages: msgRes.count || 0,
          notifications: notifRes.count || 0,
          revenue: estimatedRevenue,
        });
      } catch {
        // ignore
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return <div className="flex h-64 items-center justify-center"><span className="h-8 w-8 animate-spin rounded-full border-2 border-gold-400/30 border-t-gold-400" /></div>;
  }

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-bold text-mystic-100">Genel Bakış</h1>
      <p className="mb-6 text-sm text-mystic-400">Uygulama istatistikleri ve genel durum</p>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard icon={Users} label="Toplam Kullanıcı" value={String(stats.users)} color="text-sky-300" glow="rgba(56,189,248,0.15)" />
        <StatCard icon={Coins} label="Toplam Kredi" value={String(stats.credits)} color="text-gold-300" glow="rgba(251,191,36,0.15)" />
        <StatCard icon={TrendingUp} label="Tahmini Gelir" value={`${stats.revenue} TL`} color="text-emerald-300" glow="rgba(16,185,129,0.15)" />
        <StatCard icon={MessageCircle} label="Destek Mesajı" value={String(stats.messages)} color="text-rose-300" glow="rgba(244,63,94,0.15)" />
        <StatCard icon={Bell} label="Gönderilen Bildirim" value={String(stats.notifications)} color="text-indigo-300" glow="rgba(99,102,241,0.15)" />
        <StatCard icon={Activity} label="Aktif Oran" value={`${stats.users > 0 ? '100' : '0'}%`} color="text-amber-300" glow="rgba(245,158,11,0.15)" />
      </div>

      <div className="mt-6 rounded-2xl border border-mystic-700/40 bg-night-800/60 p-5">
        <h2 className="mb-3 font-display text-lg font-semibold text-mystic-100">Hızlı İşlemler</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { label: 'Kullanıcı Ekle', color: 'text-sky-300' },
            { label: 'Bildirim Gönder', color: 'text-indigo-300' },
            { label: 'Fiyat Güncelle', color: 'text-gold-300' },
            { label: 'Yorum Ekle', color: 'text-emerald-300' },
          ].map((action) => (
            <div key={action.label} className="rounded-xl border border-mystic-700/30 bg-night-700/40 p-3 text-center text-xs text-mystic-300">
              {action.label}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;
