import { useState } from 'react';
import { Sparkles, ChevronDown, Check } from 'lucide-react';
import StarField from '@/components/StarField';
import SparkleStars from '@/components/SparkleStars';
import {
  ZODIAC_SIGNS,
  MARITAL_STATUSES,
  saveProfile,
  type UserProfile,
  type ZodiacSign,
  type MaritalStatus,
} from '@/lib/profile';

interface OnboardingPageProps {
  onComplete: (profile: UserProfile) => void;
}

const FORTUNE_TELLER_IMG =
  'https://images.pexels.com/photos/7012897/pexels-photo-7012897.jpeg?auto=compress&cs=tinysrgb&w=800';

function OnboardingPage({ onComplete }: OnboardingPageProps) {
  const [fullName, setFullName] = useState('');
  const [age, setAge] = useState('');
  const [zodiac, setZodiac] = useState<ZodiacSign | ''>('');
  const [maritalStatus, setMaritalStatus] = useState<MaritalStatus | ''>('');
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  function validate(): boolean {
    const next: Record<string, string> = {};
    if (!fullName.trim()) next.fullName = 'Lütfen isim ve soyisminizi girin.';
    const ageNum = Number(age);
    if (!age || isNaN(ageNum) || ageNum < 18 || ageNum > 120)
      next.age = 'Yaş 18 ile 120 arasında olmalı.';
    if (!zodiac) next.zodiac = 'Lütfen burcunuzu seçin.';
    if (!maritalStatus) next.maritalStatus = 'Lütfen medeni halinizi seçin.';
    if (!agreed) next.agreed = 'Devam etmek için sözleşmeyi onaylamalısınız.';
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    const profile: UserProfile = {
      fullName: fullName.trim(),
      age: Number(age),
      zodiac: zodiac as ZodiacSign,
      maritalStatus: maritalStatus as MaritalStatus,
      createdAt: new Date().toISOString(),
    };
    saveProfile(profile);
    setTimeout(() => onComplete(profile), 600);
  }

  const inputBase =
    'w-full rounded-xl border border-mystic-700/60 bg-night-700/60 px-4 py-3 text-mystic-100 placeholder-mystic-400/50 outline-none transition focus:border-gold-400 focus:glow-border-gold';

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900">
      <StarField count={70} />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-40 -left-40 h-96 w-96 rounded-full bg-mystic-700/30 animate-glow-pulse" />
      <div className="pointer-events-none absolute -bottom-40 -right-40 h-96 w-96 rounded-full bg-gold-700/20 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-6xl flex-col items-center justify-center px-4 py-10 lg:flex-row lg:gap-12">
        {/* Fortune teller illustration */}
        <div className="relative mb-10 w-full max-w-sm animate-fade-in lg:mb-0 lg:max-w-md lg:flex-1">
          <div className="relative overflow-hidden rounded-[2rem] border border-mystic-600/40 glow-border">
            <img
              src={FORTUNE_TELLER_IMG}
              alt="Mistik falcı"
              className="h-[420px] w-full object-cover lg:h-[560px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-night-900 via-night-900/30 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-night-900/60 via-transparent to-night-900/60" />
          </div>
          {/* Floating orbs */}
          <div className="absolute -top-6 -right-6 h-16 w-16 animate-float-slow rounded-full bg-gold-400/20 blur-xl" />
          <div className="absolute -bottom-6 -left-6 h-20 w-20 animate-float-slow rounded-full bg-mystic-500/20 blur-xl" style={{ animationDelay: '3s' }} />
        </div>

        {/* Form card */}
        <div className="relative w-full max-w-md animate-fade-in-up lg:flex-1">
          <div className="relative rounded-3xl border border-mystic-600/50 bg-night-800/70 p-8 backdrop-blur-xl glow-border">
            <SparkleStars />

            {/* Header */}
            <div className="mb-8 text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-gold-400/40 bg-night-700/60">
                <Sparkles className="h-8 w-8 text-gold-300" />
              </div>
              <h1 className="font-display text-3xl font-semibold text-shimmer">
                Kaderine Yolculuk
              </h1>
              <p className="mt-2 font-serif text-lg italic text-mystic-300">
                Geleceğini öğrenmek için bir adım at
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Full Name */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-mystic-200">
                  İsim - Soyisim
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Adınız ve soyadınız"
                  className={inputBase}
                />
                {errors.fullName && (
                  <p className="mt-1 text-xs text-red-400">{errors.fullName}</p>
                )}
              </div>

              {/* Age */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-mystic-200">
                  Yaş
                </label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="Yaşınız"
                  min={18}
                  max={120}
                  className={inputBase}
                />
                {errors.age && (
                  <p className="mt-1 text-xs text-red-400">{errors.age}</p>
                )}
              </div>

              {/* Zodiac */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-mystic-200">
                  Burç
                </label>
                <div className="relative">
                  <select
                    value={zodiac}
                    onChange={(e) => setZodiac(e.target.value as ZodiacSign)}
                    className={`${inputBase} appearance-none pr-10`}
                  >
                    <option value="" disabled>
                      Burcunuzu seçin
                    </option>
                    {ZODIAC_SIGNS.map((sign) => (
                      <option key={sign} value={sign}>
                        {sign}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-mystic-400" />
                </div>
                {errors.zodiac && (
                  <p className="mt-1 text-xs text-red-400">{errors.zodiac}</p>
                )}
              </div>

              {/* Marital Status */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-mystic-200">
                  Medeni Hal
                </label>
                <div className="relative">
                  <select
                    value={maritalStatus}
                    onChange={(e) => setMaritalStatus(e.target.value as MaritalStatus)}
                    className={`${inputBase} appearance-none pr-10`}
                  >
                    <option value="" disabled>
                      Medeni halinizi seçin
                    </option>
                    {MARITAL_STATUSES.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-mystic-400" />
                </div>
                {errors.maritalStatus && (
                  <p className="mt-1 text-xs text-red-400">{errors.maritalStatus}</p>
                )}
              </div>

              {/* Terms checkbox */}
              <label className="flex cursor-pointer items-start gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setAgreed((v) => !v)}
                  className={`mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-md border transition ${
                    agreed
                      ? 'border-gold-400 bg-gold-400/20 text-gold-300'
                      : 'border-mystic-600 bg-night-700/60'
                  }`}
                  aria-pressed={agreed}
                >
                  {agreed && <Check className="h-3.5 w-3.5" />}
                </button>
                <span className="text-sm text-mystic-300">
                  <span className="text-mystic-200">
                    Kullanıcı Sözleşmesi
                  </span>
                  'ni okudum ve kabul ediyorum. Bilgilerim yalnızca bu cihazda
                  saklanacaktır.
                </span>
              </label>
              {errors.agreed && (
                <p className="text-xs text-red-400">{errors.agreed}</p>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={submitting}
                className="group relative mt-2 w-full overflow-hidden rounded-xl border border-gold-400/50 bg-gradient-to-r from-mystic-700 to-mystic-900 px-6 py-3.5 font-display text-lg font-semibold text-gold-100 transition hover:from-mystic-600 hover:to-mystic-800 disabled:opacity-60 glow-border-gold"
              >
                <span className="relative z-10 flex items-center justify-center gap-2">
                  <Sparkles className="h-5 w-5 text-gold-300" />
                  {submitting ? 'Yıldızlar hizalanıyor...' : 'Falımı Gör'}
                </span>
                <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-gold-300/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OnboardingPage;
