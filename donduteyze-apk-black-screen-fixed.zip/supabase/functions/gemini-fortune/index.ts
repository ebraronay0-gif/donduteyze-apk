import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const GEMINI_MODEL = "gemini-2.0-flash";
const GEMINI_VISION_MODEL = "gemini-2.0-flash";

let cachedApiKey: string | null = null;

async function getGeminiApiKey(supabase: any): Promise<string> {
  if (cachedApiKey !== null) return cachedApiKey;
  const envKey = Deno.env.get("GEMINI_API_KEY") || "";
  if (envKey) {
    cachedApiKey = envKey;
    return envKey;
  }
  try {
    const { data } = await supabase
      .from("app_secrets")
      .select("value")
      .eq("key", "gemini_api_key")
      .single();
    cachedApiKey = data?.value || "";
  } catch {
    cachedApiKey = "";
  }
  return cachedApiKey;
}

const FORTUNE_PERSONA = `Sen yılların tecrübesine sahip, sezgileri çok güçlü, samimi, sıcakkanlı ve gizemli bir profesyonel falcısın. Asla ama asla "Bir yapay zeka olarak", "Verilen bilgilere göre", "Analiz sonucunda", "Algoritma", "Sistem", "Veri" gibi dijital, teknik veya robotik ifadeler kullanmıyorsun. Daima mistik, edebi, metaforik ve akıcı bir Türkçe konuşuyorsun. Kahve telvesini, tarot kartlarını, el çizgilerini, yüz hatlarını veya rüya sembollerini yorumlarken hayal gücünü harekete geçiren, dertleşir gibi sıcak bir üslup benimsiyorsun. Yıldızlardan, aydan, gizemli güçlerden, kaderden, sezgilerden bahsediyorsun. Yorumun başında "Merhaba canım" veya "Hoş geldin" gibi sıcak bir karşılama yapıyorsun. Yorumun sonunda mutlaka şu uyarıyı ekliyorsun: "Bu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur."`;

const FORTUNE_TYPE_PROMPTS: Record<string, string> = {
  coffee: "Kullanıcı kahve fincanı ve tabak fotoğrafı gönderdi. Telve içinde gördüğün sembolleri, şekilleri ve figürleri mistik bir dille yorumla. Aşk, kariyer, sağlık ve gelecekten bahset.",
  tarot: "Kullanıcı 3 tarot kartı seçti. Kartların sırasıyla geçmişi, bugünü ve geleceği temsil ettiğini düşün. Her kartın anlamını açıklayıp bir bütüne var.",
  palm: "Kullanıcı sağ ve sol el avuç fotoğrafı gönderdi. Hayat çizgisini, kalp çizgisini, kafa çizgisini ve kader çizgisini yorumla.",
  face: "Kullanıcı yüz fotoğrafı gönderdi. Yüz hatlarındaki gizli anlamları, alın, kaş, göz, burun ve çene yapısını yorumla.",
  dream: "Kullanıcı gördüğü rüyayı yazdı. Rüyadaki sembolleri yorumla, gizli mesajları çöz.",
  katina: "Kullanıcı 3 katina kartı seçti. Kartların renklerini ve sıralarını yorumla.",
  dice: "Kullanıcı zar attı. Çıkan sayıların mistik anlamlarını yorumla.",
  wheel: "Kullanıcı şans çarkı çevirdi. Çıkan sonucu yorumla.",
  lottery: "Kullanıcı piyango bileti aldı. Biletteki sayıların anlamlarını yorumla.",
};

const REJECTION_TEXT = "Lütfen bizimle dalga geçmeyiniz. Profesyonelliğimizi sorgulamayınız.";

interface FortuneRequest {
  fortuneType: string;
  imageData?: string[];
  userInput?: string;
  userEmail: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body: FortuneRequest = await req.json();
    const { fortuneType, imageData, userInput, userEmail } = body;

    if (!fortuneType || !userEmail) {
      return new Response(
        JSON.stringify({ error: "Eksik bilgi." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") || "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || ""
    );

    // Create a pending reading record with 5-min delay
    const { data: reading, error: insertError } = await supabase
      .from("fortune_readings")
      .insert({
        user_email: userEmail,
        fortune_type: fortuneType,
        status: "pending",
        image_data: imageData ? JSON.stringify(imageData.slice(0, 2)) : null,
        user_input: userInput || null,
        ready_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
      })
      .select()
      .single();

    if (insertError || !reading) {
      return new Response(
        JSON.stringify({ error: "Fal kaydedilemedi." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const readingId = reading.id;

    // Process asynchronously — don't block the response
    EdgeRuntime.waitUntil((async () => {
      try {
        const apiKey = await getGeminiApiKey(supabase);
        let result = "";

        if (imageData && imageData.length > 0) {
          // Image-based fortune — first validate, then generate
          const isValid = await validateImage(imageData[0], fortuneType, apiKey);

          if (!isValid) {
            await supabase
              .from("fortune_readings")
              .update({ status: "rejected", result: REJECTION_TEXT })
              .eq("id", readingId);
            return;
          }

          result = await generateImageFortune(imageData, fortuneType, userInput, apiKey);
        } else {
          // Text-based fortune (dream, tarot cards, etc.)
          result = await generateTextFortune(fortuneType, userInput, apiKey);
        }

        // Keep the reading hidden for the full 5-minute delay. The result is
        // generated now, but the client only exposes it after ready_at.
        await supabase
          .from("fortune_readings")
          .update({ status: "pending", result })
          .eq("id", readingId);
      } catch (err) {
        await supabase
          .from("fortune_readings")
          .update({ status: "pending", result: "Falınız şu an yıldızlarda yorumlanıyor, lütfen biraz sonra tekrar kontrol edin." })
          .eq("id", readingId);
      }
    })());

    return new Response(
      JSON.stringify({ success: true, readingId }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: "Sunucu hatası." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function validateImage(imageBase64: string, fortuneType: string, apiKey: string): Promise<boolean> {
  if (!apiKey) return true; // skip validation if no key

  const base64Data = imageBase64.replace(/^data:image\/[a-z]+;base64,/, "");

  const validObjects: Record<string, string[]> = {
    coffee: ["coffee cup", "coffee grounds", "turkish coffee", "fincan", "kahve fincanı", "coffee cup and saucer"],
    tarot: ["tarot card", "playing card", "card deck"],
    palm: ["hand", "palm", "open hand", "avuç içi"],
    face: ["human face", "portrait", "selfie", "yüz"],
    katina: ["card", "playing card", "katina card"],
  };

  const expectedObjects = validObjects[fortuneType] || ["fortune related object"];

  const prompt = `Look at this image carefully. Is this image showing any of the following: ${expectedObjects.join(", ")}? If the image shows a random object, landscape, animal, or anything unrelated to fortune telling, answer "NO". If it clearly shows one of the expected objects, answer "YES". Answer only with "YES" or "NO".`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_VISION_MODEL}:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{
            parts: [
              { text: prompt },
              { inline_data: { mime_type: "image/jpeg", data: base64Data } },
            ],
          }],
        }),
      }
    );

    if (!response.ok) return true;

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim().toUpperCase() || "";
    return text.includes("YES");
  } catch {
    return true;
  }
}

async function generateImageFortune(imageData: string[], fortuneType: string, userInput?: string, apiKey: string = ""): Promise<string> {
  const typePrompt = FORTUNE_TYPE_PROMPTS[fortuneType] || "Bu falı yorumla.";

  if (!apiKey) {
    return generateFallbackFortune(fortuneType);
  }

  const parts: any[] = [
    { text: `${FORTUNE_PERSONA}\n\n${typePrompt}\n\nGörseli incele ve mistik bir fal yorumu yap. Türkçe yaz.` },
  ];

  for (const img of imageData.slice(0, 2)) {
    const base64Data = img.replace(/^data:image\/[a-z]+;base64,/, "");
    parts.push({ inline_data: { mime_type: "image/jpeg", data: base64Data } });
  }

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_VISION_MODEL}:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: [{ parts }] }),
      }
    );

    if (!response.ok) return generateFallbackFortune(fortuneType);

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) return generateFallbackFortune(fortuneType);
    return text;
  } catch {
    return generateFallbackFortune(fortuneType);
  }
}

async function generateTextFortune(fortuneType: string, userInput?: string, apiKey: string = ""): Promise<string> {
  const typePrompt = FORTUNE_TYPE_PROMPTS[fortuneType] || "Bu falı yorumla.";
  const contextText = userInput ? `Kullanıcının girdisi: ${userInput}` : "";

  if (!apiKey) {
    return generateFallbackFortune(fortuneType);
  }

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{
            parts: [{ text: `${FORTUNE_PERSONA}\n\n${typePrompt}\n\n${contextText}\n\nTürkçe olarak mistik bir fal yorumu yap.` }],
          }],
        }),
      }
    );

    if (!response.ok) return generateFallbackFortune(fortuneType);

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) return generateFallbackFortune(fortuneType);
    return text;
  } catch {
    return generateFallbackFortune(fortuneType);
  }
}

function generateFallbackFortune(fortuneType: string): string {
  const fallbacks: Record<string, string> = {
    coffee: "Merhaba canım, fincanındaki teller bana çok şey fısıldadı. Öncelikle, kalbinde bir umut ışığı görüyorum; önündeki günlerde seni bekleyen güzel haberler var. Aşk hayatında, içten içe beklediğin bir karşılaşma kapıda olabilir. Kariyerinde ise sabırlı olman gerektiğini, emeklerinin yakında meyve vereceğini görüyorum. Sağlığına dikkat et, bol bol su iç ve dinlenmeyi ihmal etme.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.",
    tarot: "Merhaba canım, seçtiğin kartlar bana geçmişini, bugününü ve geleceğini gösteriyor. Geçmişinde bir hikâyeyi kapatmaya hazırlanıyorsun; bu seni rahatlatacak. Bugün, kalbinin sesini dinlemen gerekiyor; sezgilerin seni doğru yola götürecek. Gelecekte ise sürpriz bir fırsat seni bekliyor; cesur ol ve kaçırma.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.",
    palm: "Merhaba canım, avuç içindeki çizgiler bana hayat yolculuğunu anlatıyor. Hayat çizgin uzun ve güçlü; önünde uzun ve bereketli bir ömür var. Kalp çizgin derin; sevme ve sevilme kapasiten çok yüksek. Kafa çizgin net; zekân keskin ve kararlı. Kader çizgin ise biraz kıvrımlı; hayat seni bazen sürpriz yollara götürecek ama her zaman iyilik için.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.",
    face: "Merhaba canım, yüz hatların bana karakterini ve kaderini fısıldıyor. Alnın geniş ve açık; zekân ve vizyonun ile öne çıkıyorsun. Gözlerin derin; iç dünyan zengin ve sezgilerin güçlü. Burun yapın kararlılık ve özgüveni temsil ediyor; hayatta pes etmeyen bir yapın var. Çenen ise azmini gösteriyor; hedeflerine ulaşacaksın.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.",
    dream: "Merhaba canım, rüyan bana çok şey anlatıyor. Rüyanda gördüğün semboller, iç dünyandaki arzuları ve korkuları yansıtıyor. Yıldızlar bana, içten içe beklediğin bir değişimin yaklaştığını söylüyor. Rüyanın mesajı şu: korkma, kalbinin sesini dinle ve adım at. Önündeki günlerde seni şaşırtacak güzel gelişmeler olabilir.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.",
    katina: "Merhaba canım, seçtiğin katina kartları bana renklerin dilini konuşuyor. Kartların sırasıyla geçmişini, bugününü ve geleceğini anlatıyor. Geçmişinde bir dönemi kapatıyorsun, bugün yenileniyorsun, gelecekte ise altın bir çağ seni bekliyor. Renklerin enerjisi seni çevreliyor; kendine güven.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.",
    dice: "Merhaba canım, attığın zarlar kaderin zarını temsil ediyor. Çıkan sayılar bana önündeki dönemin enerjisini gösteriyor. Şans senin yanında olacak ama yine de sen de çabalamalısın. Yıldızlar senden yana; cesur ol, adımlarını at.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.",
    wheel: "Merhaba canım, şans çarkın senin için döndü. Çıkan sonuç, önündeki dönemin bereketli olacağını müjdeliyor. Yıldızlar senin için parlıyor; fırsatları kaçırma, kendine güven ve ilerle.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.",
    lottery: "Merhaba canım, biletindeki sayılar bana gizemli mesajlar veriyor. Rakamların toplamı, önündeki dönemin şanslı enerjisini yansıtıyor. Büyük bir kazanç olmasa da, küçük sürprizler seni bekliyor. Şansın açık olsun canım.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.",
  };

  return fallbacks[fortuneType] || fallbacks.coffee;
}
