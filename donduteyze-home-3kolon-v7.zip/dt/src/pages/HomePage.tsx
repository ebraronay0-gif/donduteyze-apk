import { Sparkles, Stars, Heart, Briefcase, Hash, Palette, History, Gift, Crown, Gamepad2, Dices, Trophy, MessageCircle, ArrowRight } from 'lucide-react';
import StarField from '@/components/StarField';
import FortuneCard from '@/components/FortuneCard';
import BannerAd from '@/components/BannerAd';
import { FORTUNE_CATEGORIES } from '@/lib/fortuneCategories';
import { getDailyHoroscope } from '@/lib/horoscope';
import type { UserProfile } from '@/lib/profile';
import type { NavTabId } from '@/lib/navTabs';

interface HomePageProps {
  profile: UserProfile;
  onNavigate: (tab: NavTabId) => void;
  onOpenCoffeeFortune: () => void;
  onOpenPalmFortune: () => void;
  onOpenTarotFortune: () => void;
  onOpenKatinaFortune: () => void;
  onOpenFaceFortune: () => void;
  onOpenDreamFortune: () => void;
  onOpenWheel: () => void;
  onOpenDice: () => void;
  onOpenLottery: () => void;
  onOpenLiveChat: () => void;
}

const EARN_GAMES = [
  { id: 'wheel', name: 'Çarkıfelek', icon: Gamepad2, gradient: 'from-rose-600/20 to-rose-950/40', glow: 'rgba(244, 63, 94, 0.3)', iconColor: 'text-rose-300' },
  { id: 'dice', name: 'Zar Oyunu', icon: Dices, gradient: 'from-emerald-600/20 to-emerald-950/40', glow: 'rgba(16, 185, 129, 0.3)', iconColor: 'text-emerald-300' },
  { id: 'lottery', name: 'Çekiliş', icon: Trophy, gradient: 'from-amber-600/20 to-amber-950/40', glow: 'rgba(217, 119, 6, 0.3)', iconColor: 'text-amber-300' },
];

function HomePage({ profile, onNavigate, onOpenCoffeeFortune, onOpenPalmFortune, onOpenTarotFortune, onOpenKatinaFortune, onOpenFaceFortune, onOpenDreamFortune, onOpenWheel, onOpenDice, onOpenLottery, onOpenLiveChat }: HomePageProps) {
  const horoscope = getDailyHoroscope(profile.zodiac);
  const today = new Date().toLocaleDateString('tr-TR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={50} />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-mystic-700/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/3 -left-40 h-72 w-72 rounded-full bg-gold-700/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-8">
        {/* Döndü Teyze hero — mevcut içerikleri bozmadan, ana sayfanın ikonik vitrini */}
        <section className="relative mb-7 overflow-hidden rounded-[2rem] border border-gold-400/30 bg-[radial-gradient(circle_at_50%_20%,rgba(126,34,206,0.38),transparent_45%),linear-gradient(145deg,rgba(24,10,45,0.96),rgba(7,4,18,0.98))] shadow-[0_20px_70px_rgba(91,33,182,0.32)]">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-gold-400/10 to-transparent" />
          <div className="pointer-events-none absolute -left-16 top-8 h-40 w-28 rounded-full bg-fuchsia-700/20 blur-3xl" />
          <div className="pointer-events-none absolute -right-16 top-12 h-48 w-32 rounded-full bg-indigo-700/25 blur-3xl" />

          <div className="relative min-h-[390px] px-4 pt-5 sm:min-h-[430px]">
            <div className="relative z-20 text-center">
              <div className="inline-flex items-center gap-2 rounded-full border border-gold-300/20 bg-black/20 px-3 py-1 backdrop-blur-sm">
                <Sparkles className="h-3.5 w-3.5 text-gold-300" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.28em] text-gold-200/90">Fal • Rüya • Gizem</span>
                <Sparkles className="h-3.5 w-3.5 text-gold-300" />
              </div>
            </div>

            <img
              src="/dondu-teyze-hero.png"
              alt="Döndü Teyze"
              className="pointer-events-none absolute left-1/2 top-5 z-10 w-[78%] max-w-[360px] -translate-x-1/2 object-contain drop-shadow-[0_18px_35px_rgba(124,58,237,0.45)] sm:w-[68%]"
            />

            <div className="absolute inset-x-0 bottom-5 z-20 text-center">
              <div className="mx-auto w-fit max-w-[95%] rounded-[1.5rem] border border-gold-300/40 bg-[#11071f]/90 px-5 py-3 shadow-[0_0_28px_rgba(251,191,36,0.18)] backdrop-blur-md">
                <div className="font-display text-3xl font-bold leading-none text-shimmer sm:text-4xl">DÖNDÜ TEYZE</div>
                <div className="mt-1 flex items-center justify-center gap-2 text-[11px] font-medium text-mystic-200">
                  <span>Fallar, rüyalar ve daha fazlası</span>
                  <ArrowRight className="h-3.5 w-3.5 text-gold-300" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Welcome + Daily Horoscope */}
        <div className="relative mb-8 overflow-hidden rounded-2xl border border-mystic-700/40 bg-gradient-to-br from-night-700/70 to-night-800/80 p-5 backdrop-blur-sm glow-border">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <p className="text-sm text-mystic-400">{today}</p>
              <h2 className="font-display text-2xl font-semibold text-gold-100">
                Hoş geldin, {profile.fullName.split(' ')[0]}
              </h2>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-full border border-gold-400/30 bg-night-700/60">
              <Stars className="h-6 w-6 text-gold-300" />
            </div>
          </div>

          <div className="mb-3 flex items-center gap-2">
            <span className="rounded-full bg-mystic-700/40 px-3 py-1 text-xs font-medium text-mystic-200">
              {profile.zodiac}
            </span>
            <span className="text-xs text-mystic-500">Günlük Yorum</span>
          </div>

          <p className="font-serif text-base italic leading-relaxed text-mystic-100">
            "{horoscope.general}"
          </p>

          <div className="mt-4 grid grid-cols-2 gap-3">
            <div className="flex items-center gap-2 rounded-lg border border-mystic-700/30 bg-night-700/40 px-3 py-2">
              <Heart className="h-4 w-4 text-rose-400" />
              <div>
                <p className="text-[10px] text-mystic-400">Aşk</p>
                <p className="text-xs text-mystic-200 line-clamp-1">{horoscope.love}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 rounded-lg border border-mystic-700/30 bg-night-700/40 px-3 py-2">
              <Briefcase className="h-4 w-4 text-sky-400" />
              <div>
                <p className="text-[10px] text-mystic-400">Kariyer</p>
                <p className="text-xs text-mystic-200 line-clamp-1">{horoscope.career}</p>
              </div>
            </div>
          </div>

          <div className="mt-3 flex gap-3">
            <div className="flex items-center gap-1.5 rounded-lg border border-gold-400/20 bg-gold-900/10 px-3 py-1.5">
              <Hash className="h-3.5 w-3.5 text-gold-400" />
              <span className="text-xs text-gold-200">Şanslı Sayı: {horoscope.luckyNumber}</span>
            </div>
            <div className="flex items-center gap-1.5 rounded-lg border border-gold-400/20 bg-gold-900/10 px-3 py-1.5">
              <Palette className="h-3.5 w-3.5 text-gold-400" />
              <span className="text-xs text-gold-200">Şanslı Renk: {horoscope.luckyColor}</span>
            </div>
          </div>
        </div>

        {/* Fortune Categories */}
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display text-lg font-semibold text-mystic-100">Fal Kategorileri</h3>
          <span className="text-xs text-mystic-500">15 kredi / fal</span>
        </div>
        <div className="mb-8 grid grid-cols-3 gap-2.5 sm:gap-3">
          {FORTUNE_CATEGORIES.map((category) => (
            <FortuneCard
              key={category.id}
              category={category}
              onClick={category.id === 'kahve' ? onOpenCoffeeFortune : category.id === 'el' ? onOpenPalmFortune : category.id === 'tarot' ? onOpenTarotFortune : category.id === 'katina' ? onOpenKatinaFortune : category.id === 'yuz' ? onOpenFaceFortune : category.id === 'ruya' ? onOpenDreamFortune : undefined}
            />
          ))}
        </div>

        {/* Live Chat CTA */}
        <button
          onClick={onOpenLiveChat}
          className="group relative mb-8 flex w-full items-center gap-3 overflow-hidden rounded-2xl border border-gold-400/50 bg-gradient-to-r from-amber-700/40 via-gold-800/30 to-night-800/80 px-5 py-4 backdrop-blur-sm transition hover:from-amber-600/50 hover:to-night-700/80 glow-border-gold"
        >
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 16px rgba(251, 191, 36, 0.3)' }}>
            <MessageCircle className="h-6 w-6 text-gold-300" />
          </div>
          <div className="flex-1 text-left">
            <p className="font-display text-base font-semibold text-gold-100">Yorumcularımıza Fal Baktır</p>
            <p className="text-xs text-gold-200/70">Falcılarımızla canlı sohbet — 99,99 TL</p>
          </div>
          <div className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-gold-300/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
        </button>

        {/* My Fortunes Button */}
        <button
          onClick={() => onNavigate('history')}
          className="group relative mb-8 flex w-full items-center justify-center gap-3 overflow-hidden rounded-2xl border border-gold-400/40 bg-gradient-to-r from-mystic-800/60 to-night-800/80 px-6 py-4 backdrop-blur-sm transition hover:from-mystic-700/60 hover:to-night-700/80 glow-border-gold"
        >
          <History className="h-5 w-5 text-gold-300" />
          <span className="font-display text-lg font-semibold text-gold-100">Fallarım</span>
          <span className="rounded-full bg-gold-400/20 px-2 py-0.5 text-xs text-gold-200">0</span>
          <div className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-gold-300/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
        </button>

        {/* Earn Credits Games */}
        <div className="mb-3 flex items-center gap-2">
          <Gift className="h-5 w-5 text-gold-300" />
          <h3 className="font-display text-lg font-semibold text-mystic-100">Kredi Kazan</h3>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {EARN_GAMES.map((game) => {
            const Icon = game.icon;
            return (
              <button
                key={game.id}
                onClick={() => game.id === 'wheel' ? onOpenWheel() : game.id === 'dice' ? onOpenDice() : game.id === 'lottery' ? onOpenLottery() : onNavigate('earn')}
                className="group relative aspect-square overflow-hidden rounded-2xl border border-mystic-700/40 bg-gradient-to-br p-3 transition hover:scale-[1.03] hover:border-gold-400/40"
                style={{ boxShadow: `0 4px 16px ${game.glow}` }}
              >
                <div
                  className="pointer-events-none absolute -top-6 -right-6 h-20 w-20 rounded-full opacity-25 blur-2xl transition group-hover:opacity-50"
                  style={{ backgroundColor: game.glow }}
                />
                <div className="relative flex h-full flex-col items-center justify-center gap-2">
                  <div
                    className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-br from-white/10 to-transparent transition-transform duration-500 group-hover:scale-110 group-hover:[transform:rotateY(15deg)_rotateX(-10deg)]"
                    style={{
                      boxShadow: `0 6px 16px ${game.glow}, inset 0 1px 1px rgba(255,255,255,0.12)`,
                      transformStyle: 'preserve-3d',
                    }}
                  >
                    <Icon className={`h-6 w-6 ${game.iconColor}`} strokeWidth={1.5} />
                  </div>
                  <span className="text-center text-xs font-medium text-mystic-200">
                    {game.name}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Premium hint */}
        <button
          onClick={() => onNavigate('premium')}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl border border-gold-400/30 bg-gold-900/10 px-4 py-3 text-sm text-gold-200 transition hover:bg-gold-900/20"
        >
          <Crown className="h-4 w-4 text-gold-300" />
          Daha fazla kredi için Premium'a geç
        </button>

        {/* Banner Ad */}
        <div className="mt-6">
          <BannerAd inline />
        </div>
      </div>
    </div>
  );
}

export default HomePage;
