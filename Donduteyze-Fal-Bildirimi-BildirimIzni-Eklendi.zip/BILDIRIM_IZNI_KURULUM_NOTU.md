# Bildirim İzni

Bildirim izni kullanıcıdan bir kez istenmelidir.

Beklenen akış:
1. Uygulama açıldığında mevcut Android bildirim izni kontrol edilir.
2. İzin verilmemişse uygulama içindeki “Bildirimleri Aç” alanı gösterilir.
3. Kullanıcı butona bastığında Capacitor Push Notifications izin penceresi açılır.
4. Kullanıcı izin verirse FCM token kayıt akışı çalışır.
5. İzin zaten verilmişse tekrar izin penceresi açılmaz.
6. Kullanıcı Android ayarlarından bildirimi kapatırsa uygulama bunu kapalı olarak algılayıp tekrar “Bildirimleri Aç” yönlendirmesi gösterebilir.

Not: Mevcut ZIP'in bildirim kodu değiştirilmeden korunmuştur. Gerçek Android davranışı APK üzerinde test edilmelidir.
