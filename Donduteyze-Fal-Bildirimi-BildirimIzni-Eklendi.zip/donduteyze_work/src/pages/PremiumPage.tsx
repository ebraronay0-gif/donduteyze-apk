import { useEffect, useMemo, useState } from 'react';
import {
  CalendarDays,
  Check,
  Crown,
  CreditCard,
  LogIn,
  ShieldCheck,
  Sparkles,
  X,
  Loader2,
} from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import {
  cancelAutoRenew,
  purchasePlan,
  refreshSubscription,
  type PlanId,
  type SubscriptionInfo,
} from '@/lib/subscriptions';
import type { AuthUser } from '@/lib/auth';
import LegalAcceptance from '@/components/LegalAcceptance';

interface PremiumPageProps {
  onNavigate: (tab: NavTabId) => void;
  onRequireAuth?: () => void;
  onOpenLogin?: () => void;
  isLoggedIn?: boolean;
  authUser?: AuthUser | null;
}

interface Offer {
  id: PlanId;
  title: string;
  price: string;
  compactNote: string;
  features: string[];
  featured?: boolean;
  recurring?: boolean;
}

const SUBSCRIPTIONS: Offer[] = [
  { id: 'weekly', title: 'HAFTALIK', price: '59,99 TL', compactNote: 'Her hafta yenilenir', features: ['Günlük 20 kredi', 'Reklamsız kullanım', 'Öncelikli fal'], recurring: true },
  { id: 'monthly', title: 'AYLIK', price: '129,99 TL', compactNote: 'Her ay yenilenir', features: ['Günlük 20 kredi', 'Reklamsız kullanım', 'Öncelikli fal'], recurring: true, featured: true },
  { id: 'yearly', title: 'YILLIK', price: '599,99 TL', compactNote: 'Her yıl yenilenir', features: ['Günlük 20 kredi', 'Reklamsız kullanım', 'Öncelikli fal'], recurring: true },
];

const CREDIT_PACKS: Offer[] = [
  { id: 'credits72', title: '72 KREDİ', price: '89,99 TL', compactNote: 'Tek seferlik', features: ['15 gün reklamsız', 'Sınırsız kullanım'] },
  { id: 'credits150', title: '150 KREDİ', price: '129,99 TL', compactNote: 'Tek seferlik', features: ['15 gün reklamsız', 'Sınırsız kullanım'], featured: true },
  { id: 'credits500', title: '500 KREDİ', price: '499,99 TL', compactNote: 'Tek seferlik', features: ['15 gün reklamsız', 'Sınırsız kullanım'] },
];

const PLAN_NAMES: Record<string, string> = {
  weekly: 'Haftalık Üyelik',
  monthly: 'Aylık Üyelik',
  yearly: 'Yıllık Üyelik',
};

function formatDate(value: string | null) {
  if (!value) return '—';
  return new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(value));
}

function PremiumPage({ onNavigate, onRequireAuth, onOpenLogin, authUser }: PremiumPageProps) {
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);
  const [subscription, setSubscription] = useState<SubscriptionInfo | null>(null);
  const [subscriptionOpen, setSubscriptionOpen] = useState(false);
  const [purchasing, setPurchasing] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);
  const [legalAccepted, setLegalAccepted] = useState(false);
  const [cancelMessage, setCancelMessage] = useState<string | null>(null);

  const loadSubscription = async () => {
    const info = await refreshSubscription(authUser ?? null);
    setSubscription(info);
  };

  useEffect(() => { loadSubscription(); }, [authUser?.id]);

  const activePlanName = useMemo(() => subscription ? (PLAN_NAMES[subscription.plan] || subscription.plan) : 'Aktif abonelik yok', [subscription]);

  const handleBuy = async (offer: Offer) => {
    if (!legalAccepted) {
      setPurchaseError('Satın alma işlemine devam etmek için yasal metinleri okuyup gerekli kutucukları işaretleyin.');
      return;
    }
    setPurchasing(true);
    setPurchaseError(null);
    try {
      const result = await purchasePlan(offer.id, authUser ?? undefined);
      if (result.success) {
        setSelectedOffer(offer);
        await loadSubscription();
      } else {
        setPurchaseError(result.error || 'Satın alma başarısız oldu.');
      }
    } finally {
      setPurchasing(false);
    }
  };

  const handleCancel = async () => {
    if (!subscription || cancelling) return;
    setCancelling(true);
    setCancelMessage(null);
    const result = await cancelAutoRenew(subscription);
    setCancelling(false);
    if (!result.success) {
      setCancelMessage(result.error || 'Otomatik yenileme iptal edilemedi.');
      return;
    }
    setSubscription({ ...subscription, autoRenew: false });
    setCancelMessage(`Aboneliğiniz ${formatDate(subscription.expiresAt)} tarihinde sona erecek. Bu tarihe kadar Premium avantajlarından yararlanmaya devam edebilirsiniz.`);
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-[#07030f] pb-20 text-white">
      <StarField count={65} />
      <div className="pointer-events-none absolute -top-28 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-purple-700/20 blur-3xl" />
      <div className="pointer-events-none absolute top-[52%] -right-32 h-72 w-72 rounded-full bg-amber-500/10 blur-3xl" />

      <div className="relative z-10 mx-auto w-full max-w-3xl px-2 pb-5 pt-2 sm:px-4">
        <header className="mb-2 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
          <button onClick={() => setSubscriptionOpen(true)} className="flex h-10 items-center justify-center gap-1 rounded-full border border-amber-400/45 bg-[#180a28]/90 px-2 text-[10px] font-bold text-amber-100 shadow-[0_0_16px_rgba(245,158,11,.08)] sm:px-4 sm:text-xs">
            <Crown className="h-4 w-4 text-amber-300" /> ABONELİĞİM
          </button>
          <img src="/icon.png" alt="Döndü Teyze" className="h-12 w-12 rounded-full border border-amber-400/50 object-cover shadow-[0_0_22px_rgba(245,158,11,.2)]" />
          <button onClick={onOpenLogin ?? onRequireAuth} className="flex h-10 items-center justify-center gap-1 rounded-full border border-amber-400/45 bg-[#180a28]/90 px-2 text-[10px] font-bold text-amber-100 shadow-[0_0_16px_rgba(245,158,11,.08)] sm:px-4 sm:text-xs">
            <LogIn className="h-4 w-4 text-amber-300" /> {authUser ? 'HESABIM' : 'GİRİŞ YAP'}
          </button>
        </header>

        <section className="relative overflow-hidden rounded-[26px] border border-amber-400/30 bg-gradient-to-b from-[#180526] via-[#10041d] to-[#08030f] shadow-[0_0_45px_rgba(168,85,247,.16)]">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_14%,rgba(168,85,247,.22),transparent_40%)]" />
          <div className="relative px-2 pb-3 pt-2 sm:px-4">
            <div className="text-center">
              <p className="font-display text-[10px] tracking-[.35em] text-amber-300">DÖNDÜ TEYZE</p>
              <h1 className="font-display text-3xl font-bold tracking-[.12em] text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-yellow-400 to-amber-600">PREMIUM</h1>
              <p className="mt-0.5 text-xs font-semibold text-fuchsia-300">Daha fazlasını keşfetmeye hazır mısın?</p>
            </div>
            <div className="relative mx-auto mt-2 h-24 max-w-xl overflow-hidden rounded-2xl border border-amber-400/25 bg-black/25">
              <img src="/dondu-teyze-hero.png" alt="Döndü Teyze" className="h-full w-full object-cover object-center" />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#10041d] via-transparent to-transparent" />
            </div>

            <div className="mt-2 rounded-xl border border-amber-400/25 bg-black/25 px-3 py-2 text-center text-[9px] leading-snug text-purple-100/75">
              <span className="font-bold text-amber-200">Önemli:</span> Giriş yapmadan alınan krediler telefon değişikliğinde veya uygulama silindiğinde kaybolabilir. Giriş yaparak satın alma yapmanız önerilir. Sorumluluk tamamen kullanıcıya aittir.
            </div>

            <LegalAcceptance onValidityChange={setLegalAccepted} />

            <SectionTitle title="ABONELİK PAKETLERİ" />
            <div className="grid grid-cols-3 gap-1.5 sm:gap-3">
              {SUBSCRIPTIONS.map((offer) => <OfferCard key={offer.id} offer={offer} onBuy={handleBuy} purchasing={purchasing} />)}
            </div>

            <SectionTitle title="TEK SEFERLİK KREDİ PAKETLERİ" />
            <div className="grid grid-cols-3 gap-1.5 sm:gap-3">
              {CREDIT_PACKS.map((offer) => <OfferCard key={offer.id} offer={offer} onBuy={handleBuy} purchasing={purchasing} />)}
            </div>

            {purchaseError && <div className="mt-2 rounded-xl border border-red-500/30 bg-red-950/40 px-3 py-2 text-center text-[10px] text-red-200">{purchaseError}</div>}

            <div className="mt-2 grid grid-cols-3 gap-1 rounded-xl border border-purple-400/20 bg-black/20 p-1.5 text-center text-[8px] text-purple-100/60 sm:text-[9px]">
              <div><ShieldCheck className="mx-auto mb-0.5 h-4 w-4 text-amber-300" /><b className="text-amber-200">Güvenli ödeme</b><br />Korunan ödeme</div>
              <div><CalendarDays className="mx-auto mb-0.5 h-4 w-4 text-amber-300" /><b className="text-amber-200">Otomatik yenileme</b><br />İstediğin zaman iptal</div>
              <div><Sparkles className="mx-auto mb-0.5 h-4 w-4 text-amber-300" /><b className="text-amber-200">Premium</b><br />Öncelikli fal</div>
            </div>
          </div>
        </section>
      </div>

      {subscriptionOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4 backdrop-blur-md" onClick={() => setSubscriptionOpen(false)}>
          <div className="w-full max-w-md rounded-3xl border border-amber-400/45 bg-gradient-to-b from-[#21082f] to-[#09030f] p-5 shadow-[0_0_55px_rgba(245,158,11,.18)]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <div><p className="text-[10px] tracking-[.2em] text-amber-300">DÖNDÜ TEYZE</p><h2 className="font-display text-2xl font-bold text-amber-100">Aboneliğim</h2></div>
              <button onClick={() => setSubscriptionOpen(false)} className="rounded-full border border-purple-400/30 p-2 text-purple-200"><X className="h-4 w-4" /></button>
            </div>

            {subscription ? (
              <div className="mt-4 space-y-3">
                <div className="rounded-2xl border border-amber-400/35 bg-amber-500/10 p-4">
                  <div className="flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-full bg-amber-500/15"><Crown className="h-6 w-6 text-amber-300" /></div><div><p className="text-xs text-purple-200/60">Aktif paket</p><p className="font-display text-lg font-bold text-amber-100">{activePlanName}</p></div></div>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-xs"><InfoRow label="Günlük kredi" value={`${subscription.dailyCredits}`} /><InfoRow label="Reklam" value={subscription.adFree ? 'Kapalı' : 'Açık'} /><InfoRow label="Bitiş tarihi" value={formatDate(subscription.expiresAt)} /><InfoRow label="Otomatik yenileme" value={subscription.autoRenew ? 'Açık' : 'İptal edildi'} /></div>
                </div>

                {!subscription.autoRenew ? (
                  <div className="rounded-2xl border border-emerald-400/25 bg-emerald-500/10 p-3 text-xs leading-relaxed text-emerald-100">Aboneliğiniz {formatDate(subscription.expiresAt)} tarihinde sona erecek. Bu tarihe kadar Premium avantajlarından yararlanmaya devam edebilirsiniz. Dönem sonunda kartınızdan tekrar ücret çekilmez.</div>
                ) : (
                  <>
                    <div className="rounded-2xl border border-purple-400/20 bg-black/20 p-3 text-xs leading-relaxed text-purple-100/75">Aboneliğiniz aktif olduğu sürece her gün 20 kredi hesabınıza eklenir ve reklamlar gösterilmez.</div>
                    <button disabled={cancelling} onClick={handleCancel} className="w-full rounded-xl border border-red-400/35 bg-red-950/30 px-4 py-3 text-sm font-bold text-red-200 disabled:opacity-60">{cancelling ? <Loader2 className="mx-auto h-4 w-4 animate-spin" /> : 'Otomatik yenilemeyi iptal et'}</button>
                  </>
                )}
                {cancelMessage && <div className="rounded-xl border border-emerald-400/25 bg-emerald-500/10 p-3 text-xs leading-relaxed text-emerald-100">{cancelMessage}</div>}
                <p className="text-center text-[9px] text-purple-300/50">İptal, mevcut haftalık/aylık/yıllık döneminizi sonlandırmaz; yalnızca sonraki yenilemeyi durdurur.</p>
              </div>
            ) : (
              <div className="mt-6 rounded-2xl border border-purple-400/20 bg-black/20 p-5 text-center"><CreditCard className="mx-auto h-9 w-9 text-amber-300" /><p className="mt-2 font-semibold text-amber-100">Aktif aboneliğiniz yok</p><p className="mt-1 text-xs text-purple-200/60">Bir paket seçerek Premium avantajlarından yararlanabilirsiniz.</p><button onClick={() => setSubscriptionOpen(false)} className="mt-4 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-5 py-2.5 text-sm font-bold text-[#1a071e]">Paketleri Gör</button></div>
            )}
          </div>
        </div>
      )}

      {selectedOffer && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 px-5 backdrop-blur-md" onClick={() => setSelectedOffer(null)}>
          <div className="w-full max-w-sm rounded-3xl border border-amber-400/50 bg-gradient-to-b from-[#21082f] to-[#09030f] p-6 text-center shadow-[0_0_55px_rgba(245,158,11,.2)]" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-amber-400/50 bg-amber-500/10"><Check className="h-8 w-8 text-amber-300" /></div>
            <h2 className="mt-4 font-display text-xl font-bold text-amber-100">Satın Alma Başarılı</h2>
            <p className="mt-2 text-sm text-purple-100/80"><strong className="text-amber-200">{selectedOffer.title}</strong> paketiniz aktifleştirildi.</p>
            <button onClick={() => { setSelectedOffer(null); onNavigate('home'); }} className="mt-5 w-full rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-4 py-3 font-display font-bold text-[#1a071e]">Tamam</button>
          </div>
        </div>
      )}
    </div>
  );
}

function SectionTitle({ title }: { title: string }) {
  return <div className="my-2 flex items-center gap-2"><div className="h-px flex-1 bg-gradient-to-r from-transparent to-amber-400/40" /><h2 className="shrink-0 font-display text-[10px] font-bold tracking-[.1em] text-amber-200 sm:text-xs">{title}</h2><div className="h-px flex-1 bg-gradient-to-l from-transparent to-amber-400/40" /></div>;
}

function OfferCard({ offer, onBuy, purchasing }: { offer: Offer; onBuy: (offer: Offer) => void; purchasing: boolean }) {
  return <article className={`relative min-w-0 rounded-2xl border p-1.5 text-center shadow-[0_0_18px_rgba(168,85,247,.08)] sm:p-3 ${offer.featured ? 'border-amber-300/70 bg-gradient-to-b from-amber-500/12 to-purple-950/70' : 'border-purple-400/25 bg-purple-950/45'}`}>
    {offer.featured && <span className="absolute -top-2 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-amber-300 to-yellow-500 px-1.5 py-0.5 text-[7px] font-black text-[#1a071e]">POPÜLER</span>}
    <div className="mt-1 text-[9px] font-bold tracking-wide text-purple-100 sm:text-xs">{offer.title}</div>
    <div className="mt-1 whitespace-nowrap font-display text-[14px] font-black text-amber-200 sm:text-xl">{offer.price}</div>
    <div className="mt-0.5 text-[7px] text-purple-200/50 sm:text-[9px]">{offer.compactNote}</div>
    <div className="my-1.5 space-y-1 text-left sm:my-2">{offer.features.map((feature) => <div key={feature} className="flex items-start gap-1 text-[7px] leading-tight text-purple-100/80 sm:text-[9px]"><Check className="mt-px h-2.5 w-2.5 shrink-0 text-amber-300 sm:h-3 sm:w-3" />{feature}</div>)}</div>
    <button onClick={() => onBuy(offer)} disabled={purchasing} className={`w-full rounded-lg border px-1 py-1.5 text-[8px] font-black sm:rounded-xl sm:py-2 sm:text-[10px] ${offer.featured ? 'border-amber-200 bg-gradient-to-r from-amber-400 to-yellow-500 text-[#1a071e]' : 'border-amber-400/40 bg-purple-700/70 text-amber-50'}`}>{purchasing ? <Loader2 className="mx-auto h-3 w-3 animate-spin" /> : offer.recurring ? 'ABONE OL' : 'SATIN AL'}</button>
  </article>;
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-purple-400/15 bg-black/20 p-2"><p className="text-[9px] text-purple-200/50">{label}</p><p className="mt-0.5 font-semibold text-amber-100">{value}</p></div>;
}

export default PremiumPage;
