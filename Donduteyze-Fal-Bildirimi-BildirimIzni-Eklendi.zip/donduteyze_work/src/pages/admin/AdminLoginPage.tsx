import { useState } from 'react';
import { Shield, Lock, Eye, EyeOff, ArrowRight } from 'lucide-react';
import StarField from '@/components/StarField';
import { verifyAdminPassword, setAdminLoggedIn } from '@/lib/supabase';
import { registerAdminPush } from '@/lib/pushNotifications';

interface AdminLoginPageProps {
  onSuccess: () => void;
}

function AdminLoginPage({ onSuccess }: AdminLoginPageProps) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password || loading) return;
    setLoading(true);
    setError(null);
    const valid = await verifyAdminPassword(password);
    if (valid) {
      setAdminLoggedIn(true);
      void registerAdminPush(password);
      onSuccess();
    } else {
      setError('Hatalı şifre. Lütfen tekrar deneyin.');
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900">
      <StarField count={60} />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-gold-700/20 animate-glow-pulse" />

      <div className="relative z-10 flex min-h-screen items-center justify-center px-4">
        <div className="w-full max-w-sm">
          <div className="mb-6 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/30 glow-border-gold">
              <Shield className="h-8 w-8 text-gold-300" />
            </div>
            <h1 className="font-display text-2xl font-bold tracking-widest text-shimmer">YÖNETİCİ</h1>
            <p className="mt-1 text-xs text-mystic-400">Döndü Teyze Admin Paneli</p>
          </div>

          <form onSubmit={handleSubmit} className="rounded-2xl border border-mystic-700/40 bg-night-800/80 p-6 backdrop-blur-sm">
            <label className="mb-2 block text-sm font-medium text-mystic-200">Yönetici Şifresi</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-mystic-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Şifrenizi girin"
                autoFocus
                className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 py-3 pl-10 pr-10 text-sm text-mystic-100 outline-none transition focus:border-gold-400/50"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-mystic-400 hover:text-mystic-200"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>

            {error && (
              <p className="mt-3 rounded-lg border border-rose-500/30 bg-rose-900/20 px-3 py-2 text-xs text-rose-200">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading || !password}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-gold-400/50 bg-gradient-to-r from-gold-700 to-gold-800 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:scale-[1.02] disabled:opacity-50"
            >
              {loading ? (
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-gold-200/30 border-t-gold-200" />
              ) : (
                <>
                  Giriş Yap <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
          </form>

          <p className="mt-4 text-center text-[11px] text-mystic-500">
            Bu alan yetkili personel içindir. Yetkisiz erişim yasaktır.
          </p>
        </div>
      </div>
    </div>
  );
}

export default AdminLoginPage;
