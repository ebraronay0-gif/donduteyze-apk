#!/bin/bash
set -e

echo "Building web app..."
npm run build

echo "Creating Android project..."
if [ ! -d android ]; then
  npx cap add android
fi

echo "Generating Android launcher icons..."
test -s resources/launcher-icon-final.png
# Use the dedicated launcher artwork, not the transparent in-app character/logo.
# The previous build copied public/icon.png here, which is why Android could keep
# showing the old launcher artwork.
cp -f resources/launcher-icon-final.png resources/icon.png
if [ -d android/app/src/main/res ]; then
  find android/app/src/main/res -maxdepth 1 -type d -name 'mipmap-*' -exec rm -rf {} + || true
fi
npx capacitor-assets generate --android

# Force the manifest to use the Döndü Teyze artwork. Do not leave Capacitor's
# default ic_launcher as the active launcher icon.
mkdir -p android/app/src/main/res/values android/app/src/main/res/mipmap-anydpi-v26
cat > android/app/src/main/res/values/donduteyze_icon_colors.xml <<'EOF'
<resources><color name="donduteyze_icon_background">#16052F</color></resources>
EOF
cat > android/app/src/main/res/mipmap-anydpi-v26/ic_donduteyze.xml <<'EOF'
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
  <background android:drawable="@color/donduteyze_icon_background" />
  <foreground android:drawable="@drawable/ic_donduteyze_foreground" />
</adaptive-icon>
EOF
mkdir -p android/app/src/main/res/drawable-nodpi
cp -f resources/launcher-icon-final.png android/app/src/main/res/drawable-nodpi/ic_donduteyze_foreground.png
# Legacy launcher fallback for Android versions without adaptive icons.
declare -A ICON_SIZES=([mdpi]=48 [hdpi]=72 [xhdpi]=96 [xxhdpi]=144 [xxxhdpi]=192)
for density in "${!ICON_SIZES[@]}"; do
  size=${ICON_SIZES[$density]}
  mkdir -p "android/app/src/main/res/mipmap-${density}"
  convert resources/launcher-icon-final.png -background '#16052F' -gravity center -resize "${size}x${size}" -extent "${size}x${size}" "android/app/src/main/res/mipmap-${density}/ic_donduteyze.png"
done
python3 - <<'PY2'
from pathlib import Path
import re
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
a=s.index('<application')
b=s.index('>', a)
app=s[a:b]
app=re.sub(r'\s+android:icon="[^"]*"', '', app)
app=re.sub(r'\s+android:roundIcon="[^"]*"', '', app)
app += ' android:icon="@mipmap/ic_donduteyze" android:roundIcon="@mipmap/ic_donduteyze"'
p.write_text(s[:a]+app+s[b:])
PY2

test -s android/app/src/main/res/drawable-nodpi/ic_donduteyze_foreground.png
grep -q 'android:icon="@mipmap/ic_donduteyze"' android/app/src/main/AndroidManifest.xml

echo "Syncing to Android..."
npx cap sync android
./scripts/configure-oauth-android.sh

echo "Done. APK can be built with:"
echo "  cd android && ./gradlew assembleDebug"
