import { useState } from 'react';
import { ArrowLeft, Sparkles, Star, MessageCircle, ShieldCheck, Heart, Check, ChevronRight, Crown, Gem, Clock3 } from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import { getCredits, spendCredits } from '@/lib/credits';
import { FORTUNE_TELLER_PRICE, purchaseChatSession } from '@/lib/liveChat';
import { hasSupabaseConfig, supabase } from '@/lib/supabase';
import type { AuthUser } from '@/lib/auth';

interface Props { onNavigate: (tab: NavTabId) => void; onOpenChat: (user: AuthUser, counselor: string) => void; }

const TELLERS = [
  { name: 'Aliye Teyze', quote: 'Gönlünden geçenleri bilirim.', rating: '4.9', reviews: '12.458', specialty: ['Tarot', 'Kahve Falı', 'Aşk Falı', 'Ruhsal Rehberlik'], avatar: '/teller-aliye.svg', tone: 'from-fuchsia-500/20 via-purple-950/80 to-[#090116]' },
  { name: 'Sultan Teyze', quote: 'Kaderini birlikte aydınlatalım.', rating: '4.8', reviews: '9.876', specialty: ['Yıldız Falı', 'Melek Kartları', 'Enerji Falı', 'Numeroloji'], avatar: '/teller-sultan.svg', tone: 'from-emerald-500/15 via-purple-950/80 to-[#090116]' },
  { name: 'Yasemen Bacı', quote: 'İçindeki sesi duymana yardım ederim.', rating: '4.9', reviews: '11.203', specialty: ['Tarot', 'Kahve Falı', 'Ruhsal Rehberlik', 'Aşk Falı'], avatar: '/teller-yasemin.svg', tone: 'from-rose-500/15 via-purple-950/80 to-[#090116]' },
  { name: 'Döndü Teyze', quote: 'Hayatın sırlarını birlikte çözelim.', rating: '4.9', reviews: '15.692', specialty: ['Kahve Falı', 'Tarot', 'Melek Kartları', 'Yıldız Falı'], avatar: '/icon.png', tone: 'from-amber-500/20 via-purple-950/80 to-[#090116]', expert: true },
];

async function getOrCreateGuest(): Promise<AuthUser | null> {
  const { data } = await supabase.auth.getSession();
  if (data.session?.user) return { id: data.session.user.id, email: data.session.user.email || '' };
  const { data: anon, error } = await supabase.auth.signInAnonymously();
  if (error || !anon.user) return null;
  return { id: anon.user.id, email: anon.user.email || '' };
}

function FortuneTellerPage({ onNavigate, onOpenChat }: Props) {
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [done, setDone] = useState('');

  const choose = async (name: string) => {
    if (busy) return;
    setError('');
    if (getCredits() < FORTUNE_TELLER_PRICE) {
      setError(`Bu falcıyla görüşmek için ${FORTUNE_TELLER_PRICE} kredi gerekiyor.`);
      return;
    }
    if (!hasSupabaseConfig) {
      setError('Falcı mesajlaşma sunucusu şu anda yapılandırılmamış.');
      return;
    }
    setBusy(name);
    const buyer = await getOrCreateGuest();
    if (!buyer) {
      setBusy(null);
      setError('Mesajlaşma bağlantısı kurulamadı. Lütfen tekrar deneyin.');
      return;
    }
    const result = spendCredits(FORTUNE_TELLER_PRICE);
    if (!result.success) { setBusy(null); setError('Yeterli krediniz yok.'); return; }
    const session = await purchaseChatSession(buyer, name);
    if (!session) {
      const { addCredits } = await import('@/lib/credits');
      addCredits(FORTUNE_TELLER_PRICE);
      setBusy(null);
      setError('Falcı sohbeti oluşturulamadı; krediniz iade edildi.');
      return;
    }
    setDone(name);
    setBusy(null);
    window.dispatchEvent(new Event('credits-updated'));
    setTimeout(() => onOpenChat(buyer, name), 450);
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#070116] pb-28 text-mystic-100">
      <StarField count={75} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_12%,rgba(168,85,247,.24),transparent_28%),radial-gradient(circle_at_85%_25%,rgba(245,158,11,.12),transparent_24%),linear-gradient(180deg,rgba(9,1,24,.12),#070116_70%)]" />

      <div className="relative z-10 mx-auto max-w-2xl px-3 pb-8 pt-4">
        <div className="mb-4 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold-400/45 bg-[#120520]/90 text-gold-100 shadow-[0_0_20px_rgba(168,85,247,.18)]">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex-1 rounded-full border border-gold-400/25 bg-[#120520]/75 px-4 py-2 backdrop-blur-md">
            <p className="text-[9px] uppercase tracking-[.28em] text-gold-300/70">Döndü Teyze'nin mistik dünyası</p>
            <p className="font-display text-base text-gold-100">Gerçek Yorumcular</p>
          </div>
        </div>

        <section className="relative mb-5 overflow-hidden rounded-[32px] border border-gold-300/35 bg-[radial-gradient(circle_at_15%_35%,rgba(168,85,247,.34),transparent_30%),radial-gradient(circle_at_88%_15%,rgba(251,191,36,.16),transparent_24%),linear-gradient(145deg,#2a0b4a,#10031f_65%,#070116)] p-5 shadow-[0_28px_80px_rgba(0,0,0,.55),inset_0_1px_0_rgba(255,255,255,.1)]">
          <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full border border-gold-300/15 bg-purple-500/10 blur-sm" />
          <div className="pointer-events-none absolute bottom-0 left-0 h-28 w-full bg-[linear-gradient(180deg,transparent,rgba(124,58,237,.10))]" />
          <div className="relative flex items-center gap-4">
            <div className="relative h-24 w-24 shrink-0 [perspective:700px]">
              <div className="absolute inset-0 rounded-[28px] border border-gold-200/70 bg-gradient-to-br from-violet-500/40 via-purple-950 to-black/80 shadow-[0_18px_35px_rgba(0,0,0,.6),0_0_30px_rgba(168,85,247,.3)] [transform:rotateY(-10deg) rotateX(5deg)]" />
              <img src="/teller-yasemin.svg" alt="Yasemen Bacı" className="relative h-full w-full object-contain p-1 drop-shadow-[0_14px_16px_rgba(0,0,0,.55)] [transform:translateZ(24px)]" />
              <span className="absolute bottom-1 right-1 h-3.5 w-3.5 rounded-full border-2 border-[#170525] bg-emerald-400 shadow-[0_0_15px_rgba(74,222,128,.9)]" />
            </div>
            <div className="min-w-0">
              <div className="mb-1 flex items-center gap-2 text-gold-300"><Sparkles className="h-4 w-4" /><span className="text-[9px] uppercase tracking-[.28em]">Döndü Teyze'nin seçkin kadrosu</span></div>
              <h1 className="font-display text-[28px] leading-none text-gold-100 sm:text-3xl">FALCILARIMIZ</h1>
              <p className="mt-2 max-w-md text-xs leading-5 text-mystic-300">Deneyimli yorumcular arasından seçimini yap. Görüşme başladıktan sonra falcın görüşmeyi sonlandırana kadar mesajlaşabilirsiniz.</p>
            </div>
          </div>
          <div className="relative mt-5 grid grid-cols-3 overflow-hidden rounded-2xl border border-gold-300/20 bg-black/25 backdrop-blur-sm">
            <div className="flex items-center gap-2 border-r border-gold-400/15 p-3"><Crown className="h-4 w-4 text-gold-300" /><span className="text-[9px] text-gold-100"><b className="block">Seçkin</b>Yorumcular</span></div>
            <div className="flex items-center gap-2 border-r border-gold-400/15 p-3"><Gem className="h-4 w-4 text-violet-300" /><span className="text-[9px] text-gold-100"><b className="block">72 Kredi</b>Tek ücret</span></div>
            <div className="flex items-center gap-2 p-3"><Clock3 className="h-4 w-4 text-emerald-300" /><span className="text-[9px] text-gold-100"><b className="block">Sınırsız</b>Mesajlaşma</span></div>
          </div>
        </section>

        {error && <div className="mb-4 rounded-2xl border border-rose-500/30 bg-rose-950/35 p-3 text-center text-xs text-rose-200">{error}</div>}

        <div className="mb-2 flex items-end justify-between px-1"><div><p className="text-[9px] uppercase tracking-[.28em] text-gold-300/60">Canlı yorumcular</p><h2 className="font-display text-xl text-gold-100">Sana uygun falcıyı seç</h2></div><span className="rounded-full border border-gold-400/25 bg-purple-950/50 px-3 py-1 text-[9px] text-gold-200">4 yorumcu</span></div>
        <div className="space-y-4">
          {TELLERS.map((t) => (
            <article key={t.name} className={`group relative overflow-hidden rounded-[28px] border border-gold-300/30 bg-gradient-to-br ${t.tone} p-3.5 shadow-[0_18px_50px_rgba(0,0,0,.52),inset_0_1px_0_rgba(255,255,255,.08)]`}>
              <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_10%,rgba(255,255,255,.08),transparent_22%),linear-gradient(115deg,transparent_45%,rgba(255,255,255,.035),transparent_65%)]" />
              <div className="relative grid grid-cols-[92px_1fr] gap-3 sm:grid-cols-[112px_1fr_135px]">
                <div className="relative mx-auto h-[96px] w-[96px] [perspective:800px] sm:h-[108px] sm:w-[108px]">
                  <div className="absolute inset-1 rounded-[30px] border border-gold-200/60 bg-gradient-to-br from-violet-500/35 via-purple-950 to-black/80 shadow-[10px_18px_28px_rgba(0,0,0,.6),0_0_28px_rgba(168,85,247,.24)] [transform:rotateY(-10deg) rotateX(6deg)]" />
                  <div className="absolute inset-3 rounded-[25px] border border-white/10 bg-black/20 backdrop-blur-[1px] [transform:translateZ(10px)]" />
                  <img src={t.avatar} alt={t.name} className="relative h-full w-full object-contain p-1 drop-shadow-[0_15px_16px_rgba(0,0,0,.65)] [transform:translateZ(30px)] transition-transform duration-300 group-hover:scale-[1.03]" />
                  <span className="absolute bottom-1 right-1 h-3.5 w-3.5 rounded-full border-2 border-[#170525] bg-emerald-400 shadow-[0_0_15px_rgba(74,222,128,.9)]" />
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-display text-[20px] leading-tight text-gold-100">{t.name}</h2>
                    {t.expert && <span className="rounded-full border border-gold-300/35 bg-gold-500/15 px-2 py-0.5 text-[8px] font-semibold uppercase tracking-wider text-gold-100">Kurucu</span>}
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-[10px] text-emerald-300"><span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(74,222,128,.9)]" /> Çevrimiçi</div>
                  <p className="mt-1.5 text-[11px] leading-4 text-mystic-300">“{t.quote}”</p>
                  <div className="mt-2 flex items-center gap-2 text-[9px] text-gold-200"><span className="flex items-center gap-1"><Star className="h-3 w-3 fill-gold-300 text-gold-300" />{t.rating}</span><span className="opacity-40">•</span><span>{t.reviews} yorum</span></div>
                  <div className="mt-2 flex flex-wrap gap-1">{t.specialty.map(s => <span key={s} className="rounded-full border border-violet-300/20 bg-violet-500/10 px-1.5 py-0.5 text-[8px] text-violet-100">{s}</span>)}</div>
                </div>
                <div className="col-span-2 flex flex-col gap-2 sm:col-span-1 sm:justify-center">
                  <div className="flex items-center justify-center gap-1 rounded-xl border border-gold-300/35 bg-black/30 px-2 py-2 text-[11px] font-black text-gold-100"><span className="text-gold-300">✦</span>{FORTUNE_TELLER_PRICE} KREDİ</div>
                  <button onClick={() => choose(t.name)} disabled={!!busy} className="rounded-xl border border-gold-200/70 bg-gradient-to-r from-violet-700 via-purple-600 to-fuchsia-600 px-2 py-3 font-display text-[12px] text-white shadow-[0_0_24px_rgba(168,85,247,.42)] transition hover:brightness-110 active:scale-[.98] disabled:opacity-60">{busy === t.name ? 'Sohbet açılıyor...' : 'FAL BAKTIR'}</button>
                  <div className="flex items-start gap-1 text-[8px] leading-3 text-mystic-400"><Heart className="mt-0.5 h-3 w-3 shrink-0 text-pink-300" />Görüşme falcı tarafından sonlandırılana kadar mesajlaşabilirsiniz.</div>
                </div>
              </div>
            </article>
          ))}
        </div>

        {done && <div className="mt-4 flex items-center justify-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-950/30 p-3 text-xs text-emerald-200"><Check className="h-4 w-4" /> {done} seçildi · {FORTUNE_TELLER_PRICE} kredi harcandı · mesaj kutusu açılıyor</div>}

        <section className="mt-5 rounded-[24px] border border-gold-400/30 bg-gradient-to-br from-[#21083b] to-[#0b021b] p-4 shadow-[0_18px_45px_rgba(0,0,0,.4)]">
          <div className="mb-4 flex items-center justify-center gap-2"><Sparkles className="h-4 w-4 text-gold-300" /><h3 className="font-display text-lg text-gold-100">NASIL ÇALIŞIR?</h3><Sparkles className="h-4 w-4 text-gold-300" /></div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[['1','Yorumcunu seç','Sana uygun yorumcuyu seç ve sohbete başla.'],['2','Sorunu sor','Merak ettiklerini yorumcuna yaz.'],['3','Cevabını al','Yorumcundan detaylı fal yorumunu al.'],['4','Sohbet devam eder','Falcı görüşmeyi sonlandırana kadar özgürce mesajlaş.']].map(([n,title,text]) => (
              <div key={n} className="rounded-2xl border border-gold-400/15 bg-black/20 p-3 text-center">
                <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-full border border-gold-300/40 bg-purple-700/30 font-display text-gold-100">{n}</div>
                <p className="mt-2 text-[11px] font-semibold text-gold-100">{title}</p><p className="mt-1 text-[9px] leading-4 text-mystic-400">{text}</p>
              </div>
            ))}
          </div>
        </section>
        <p className="mt-4 flex items-center justify-center gap-1 text-[9px] text-mystic-600"><ChevronRight className="h-3 w-3" /> Yorumcuların görüşleri eğlence amaçlıdır.</p>
      </div>
    </div>
  );
}

export default FortuneTellerPage;
