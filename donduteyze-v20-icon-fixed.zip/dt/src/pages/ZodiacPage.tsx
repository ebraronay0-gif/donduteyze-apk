import { useState } from 'react';
import { X, Heart, Briefcase, Activity, Sparkles, Hash, Palette } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { ZodiacSign } from '@/lib/profile';
import { ZODIAC_INFO, getZodiacDailyReading } from '@/lib/zodiacHoroscope';

interface ZodiacPageProps {
  userZodiac?: ZodiacSign;
}

const ELEMENT_COLORS: Record<string, { border: string; glow: string; text: string; bg: string }> = {
  'Ateş': { border: 'border-rose-400/40', glow: 'rgba(244, 63, 94, 0.3)', text: 'text-rose-200', bg: 'from-rose-900/20' },
  'Toprak': { border: 'border-emerald-400/40', glow: 'rgba(16, 185, 129, 0.3)', text: 'text-emerald-200', bg: 'from-emerald-900/20' },
  'Hava': { border: 'border-sky-400/40', glow: 'rgba(56, 189, 248, 0.3)', text: 'text-sky-200', bg: 'from-sky-900/20' },
  'Su': { border: 'border-indigo-400/40', glow: 'rgba(99, 102, 241, 0.3)', text: 'text-indigo-200', bg: 'from-indigo-900/20' },
};

function ZodiacPage({ userZodiac }: ZodiacPageProps) {
  const [selected, setSelected] = useState<ZodiacSign | null>(null);
  const [pendingZodiac, setPendingZodiac] = useState<ZodiacSign | null>(null);
  const [mode, setMode] = useState<'gun'|'ask'|'para'|'kariyer'|'sans'>('gun');

  const today = new Date().toLocaleDateString('tr-TR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const reading = selected ? getZodiacDailyReading(selected) : null;
  const selectedInfo = selected ? ZODIAC_INFO.find((z) => z.sign === selected) : null;
  const elementStyle = selectedInfo ? ELEMENT_COLORS[selectedInfo.element] : null;

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={60} />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-mystic-700/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/2 -right-32 h-64 w-64 rounded-full bg-gold-700/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 text-center">
          <h1 className="font-display text-3xl font-bold tracking-widest text-shimmer">BURÇLAR</h1>
          <div className="mx-auto mt-2 h-px w-40 bg-gradient-to-r from-transparent via-gold-400/50 to-transparent" />
          <p className="mt-3 font-serif text-sm italic text-mystic-300">{today}</p>
          <p className="mt-1 text-xs text-mystic-400">Burcunu seç, günlük yorumunu keşfet</p>
          <div className="mt-4 grid grid-cols-5 gap-1.5 rounded-2xl border border-purple-400/20 bg-black/15 p-1">{([['gun','Bugün'],['ask','Aşk'],['para','Para'],['kariyer','Kariyer'],['sans','Şans']] as const).map(([id,label])=><button key={id} onClick={()=>setMode(id)} className={`rounded-xl px-1 py-2 text-[9px] font-bold ${mode===id?'bg-gradient-to-r from-purple-700/60 to-amber-500/20 text-gold-100':'text-mystic-400'}`}>{label}</button>)}</div>
        </div>

        {/* Alternative daily focus */}
        <section className="mb-5 rounded-[24px] border border-gold-400/20 bg-gradient-to-r from-[#251044]/80 to-[#0e0620]/90 p-4"><div className="flex items-center justify-between"><div><p className="text-[10px] uppercase tracking-[.2em] text-gold-300/70">Bugünün odağı</p><h2 className="mt-1 font-display text-lg text-gold-100">{mode==='gun'?'Günün Enerjisi':mode==='ask'?'Aşk Enerjisi':mode==='para'?'Para & Bolluk':mode==='kariyer'?'Kariyer Rotası':'Şans & Fırsat'}</h2></div><span className="text-2xl">{mode==='ask'?'❤️':mode==='para'?'💰':mode==='kariyer'?'💼':mode==='sans'?'🍀':'✨'}</span></div><p className="mt-2 text-xs leading-5 text-mystic-300">{mode==='gun'?'Bugün sezgilerini dinle; acele etmeden kararlarını netleştir.':mode==='ask'?'Kalp meselelerinde açık iletişim bugün sana avantaj sağlayabilir.':mode==='para'?'Küçük bir fırsat büyüyebilir; gereksiz harcamaları ertele.':mode==='kariyer'?'Bir işi tamamlamak yeni bir kapının açılmasına yardım edebilir.':'Şansını küçük ama doğru adımlarda ara; özellikle günün ilerleyen saatlerinde.'}</p><div className="mt-3 grid grid-cols-3 gap-2 text-center"><div className="rounded-xl bg-white/5 p-2"><b className="text-sm text-gold-100">{mode==='sans'?9:7}</b><p className="text-[8px] text-mystic-500">Şans sayısı</p></div><div className="rounded-xl bg-white/5 p-2"><b className="text-sm text-gold-100">21:40</b><p className="text-[8px] text-mystic-500">Şanslı saat</p></div><div className="rounded-xl bg-white/5 p-2"><b className="text-sm text-gold-100">Mor</b><p className="text-[8px] text-mystic-500">Şanslı renk</p></div></div></section>

        {/* Zodiac grid */}
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
          {ZODIAC_INFO.map((z) => {
            const style = ELEMENT_COLORS[z.element];
            const isUserSign = z.sign === userZodiac;
            return (
              <button
                key={z.sign}
                onClick={() => setPendingZodiac(z.sign)}
                className={`group relative aspect-square overflow-hidden rounded-2xl border ${style.border} bg-gradient-to-br ${style.bg} via-night-700/60 to-night-800/80 p-3 text-center transition hover:scale-[1.05]`}
                style={{ boxShadow: `0 4px 16px ${style.glow}` }}
              >
                {isUserSign && (
                  <div className="absolute top-1 right-1 flex h-5 w-5 items-center justify-center rounded-full bg-gold-500/80">
                    <Sparkles className="h-3 w-3 text-night-900" />
                  </div>
                )}
                <div className="pointer-events-none absolute -top-4 -right-4 h-16 w-16 rounded-full opacity-20 blur-2xl transition group-hover:opacity-40" style={{ backgroundColor: style.glow }} />
                <div className="relative flex h-full flex-col items-center justify-center gap-1">
                  <span className="font-display text-3xl font-bold" style={{ color: style.glow.replace('0.3', '0.9') }}>{z.symbol}</span>
                  <span className="font-display text-xs font-semibold text-mystic-100">{z.sign}</span>
                  <span className="text-[9px] text-mystic-400">{z.range}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Element legend */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-3 text-[11px] text-mystic-400">
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-rose-400" /> Ateş</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-400" /> Toprak</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-sky-400" /> Hava</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-indigo-400" /> Su</span>
        </div>
      </div>

      <RewardedAdModal
        open={pendingZodiac !== null}
        onComplete={() => {
          setSelected(pendingZodiac);
          setPendingZodiac(null);
        }}
        onClose={() => setPendingZodiac(null)}
        rewardLabel="Burç Yorumu"
      />

      {/* Detail modal */}
      {selected && reading && selectedInfo && elementStyle && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-night-900/80 backdrop-blur-sm animate-fade-in sm:items-center" onClick={() => setSelected(null)}>
          <div
            className="relative max-h-[95vh] w-full max-w-lg overflow-y-auto rounded-t-3xl border-t-2 border-gold-400/40 bg-gradient-to-b from-night-700/95 to-night-900/95 p-6 pb-10 animate-fade-in-up sm:rounded-3xl sm:border-2"
            style={{ boxShadow: '0 0 16px rgba(251, 191, 36, 0.3), 0 0 32px rgba(251, 191, 36, 0.2)' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-gold-500/20 blur-3xl" />

            {/* Close button */}
            <button
              onClick={() => setSelected(null)}
              className="absolute right-4 top-4 z-10 flex h-8 w-8 items-center justify-center rounded-full border border-mystic-700/40 bg-night-900/60 text-mystic-300 transition hover:text-mystic-100"
              aria-label="Kapat"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Header */}
            <div className="relative mb-5 text-center">
              <div className="mb-2 flex items-center justify-center gap-3">
                <span className="font-display text-5xl font-bold" style={{ color: elementStyle.glow.replace('0.3', '0.9') }}>{selectedInfo.symbol}</span>
              </div>
              <h2 className="font-display text-2xl font-semibold text-shimmer">{selectedInfo.sign}</h2>
              <p className="mt-1 text-xs text-mystic-400">{selectedInfo.range} • {selectedInfo.element} grubu</p>
              <p className="mt-2 font-serif text-sm italic text-mystic-300">{today}</p>
            </div>

            {/* Lucky info */}
            <div className="relative mb-5 flex justify-center gap-3">
              <div className="flex items-center gap-1.5 rounded-full border border-gold-400/30 bg-gold-900/20 px-3 py-1.5 text-xs text-gold-200">
                <Hash className="h-3.5 w-3.5" />
                Şanslı Sayı: <span className="font-semibold">{reading.luckyNumber}</span>
              </div>
              <div className="flex items-center gap-1.5 rounded-full border border-mystic-400/30 bg-mystic-900/20 px-3 py-1.5 text-xs text-mystic-200">
                <Palette className="h-3.5 w-3.5" />
                Şanslı Renk: <span className="font-semibold">{reading.luckyColor}</span>
              </div>
            </div>

            {/* Readings */}
            <div className="relative space-y-5">
              {/* Love */}
              <div className="rounded-2xl border border-rose-400/30 bg-rose-900/10 p-5">
                <div className="mb-3 flex items-center gap-2">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full border border-rose-400/30 bg-rose-900/30">
                    <Heart className="h-4 w-4 text-rose-300" />
                  </span>
                  <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-rose-200">Aşk</h3>
                </div>
                <p className="font-serif text-sm italic leading-relaxed text-mystic-200">{reading.love}</p>
              </div>

              {/* Career */}
              <div className="rounded-2xl border border-sky-400/30 bg-sky-900/10 p-5">
                <div className="mb-3 flex items-center gap-2">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full border border-sky-400/30 bg-sky-900/30">
                    <Briefcase className="h-4 w-4 text-sky-300" />
                  </span>
                  <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-sky-200">Kariyer</h3>
                </div>
                <p className="font-serif text-sm italic leading-relaxed text-mystic-200">{reading.career}</p>
              </div>

              {/* Health */}
              <div className="rounded-2xl border border-emerald-400/30 bg-emerald-900/10 p-5">
                <div className="mb-3 flex items-center gap-2">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full border border-emerald-400/30 bg-emerald-900/30">
                    <Activity className="h-4 w-4 text-emerald-300" />
                  </span>
                  <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-emerald-200">Sağlık</h3>
                </div>
                <p className="font-serif text-sm italic leading-relaxed text-mystic-200">{reading.health}</p>
              </div>
            </div>

            <p className="relative mt-8 text-center text-[11px] text-mystic-500">
              Döndü Teyze bir eğlence uygulamasıdır. Burç yorumları yalnızca eğlence amaçlıdır.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default ZodiacPage;
