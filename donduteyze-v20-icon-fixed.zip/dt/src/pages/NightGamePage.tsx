import { useState } from 'react';
import { ArrowLeft, Moon, Sparkles, Star, Trophy, Coins } from 'lucide-react';
import StarField from '@/components/StarField';
import { addCredits } from '@/lib/credits';
import { shouldShowInterstitial } from '@/lib/ads';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { NavTabId } from '@/lib/navTabs';
import { unlockBadge } from '@/lib/badges';

const prompts = ['Ay ışığında ilk aklına gelen renk?', 'Bugün seni en çok ne mutlu etti?', 'Bir dilek hakkın olsa ne dilerdin?', 'Kalbin şu an hangi kelimeyi seçiyor?'];
function NightGamePage({onNavigate}:{onNavigate:(tab:NavTabId)=>void}) {
  const [index,setIndex]=useState(0); const [answer,setAnswer]=useState(''); const [reward,setReward]=useState(false); const [won,setWon]=useState(false);
  const play=()=>{ if(!answer.trim()) return; setWon(true); unlockBadge('explorer'); if(shouldShowInterstitial()) setReward(true); else { addCredits(1); } };
  const close=()=>{ setReward(false); addCredits(1); };
  return <div className="relative min-h-screen overflow-hidden bg-[#050313] pb-28"><StarField count={75}/><div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_15%,rgba(99,102,241,.28),transparent_35%),radial-gradient(circle_at_80%_70%,rgba(168,85,247,.18),transparent_32%)]"/><div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
    <div className="mb-6 flex items-center gap-3"><button onClick={()=>onNavigate('home')} className="flex h-10 w-10 items-center justify-center rounded-full border border-indigo-400/30 bg-indigo-950/50 text-indigo-200"><ArrowLeft className="h-5 w-5"/></button><div><p className="text-[10px] uppercase tracking-[.3em] text-indigo-300/70">Gece ritüeli</p><h1 className="font-display text-2xl text-gold-100">Ay Işığı Oyunu</h1></div></div>
    <section className="luxury-section p-6 text-center"><div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full border border-gold-300/40 bg-indigo-950/80 shadow-[0_0_35px_rgba(129,140,248,.35)]"><Moon className="h-12 w-12 text-gold-200"/></div><h2 className="mt-5 font-display text-xl text-gold-100">Geceye bir dilek bırak</h2><p className="mt-2 text-sm leading-6 text-mystic-300">Soruyu cevapla, gecenin yıldızlarından küçük bir sürpriz kredi kazan.</p><div className="mt-5 rounded-2xl border border-indigo-400/25 bg-black/20 p-5"><p className="font-serif text-lg italic text-mystic-100">{prompts[index]}</p><input value={answer} onChange={e=>setAnswer(e.target.value)} placeholder="Cevabını yaz..." className="mt-4 w-full rounded-xl border border-indigo-400/25 bg-[#0b0820] px-4 py-3 text-sm text-white outline-none focus:border-gold-400/50"/><button onClick={play} className="mt-3 w-full rounded-xl border border-gold-300/50 bg-gradient-to-r from-indigo-700 to-purple-700 py-3 font-display font-semibold text-gold-100">Yıldızları Aç</button></div>{won&&<div className="mt-4 flex items-center justify-center gap-2 rounded-xl border border-emerald-400/30 bg-emerald-950/20 p-3 text-sm text-emerald-200"><Trophy className="h-4 w-4"/> Gece tamamlandı · +1 kredi</div>}<button onClick={()=>{setIndex((index+1)%prompts.length);setAnswer('');setWon(false)}} className="mt-4 text-xs text-indigo-300">Başka bir soru seç</button></section>
    <section className="mt-5 grid grid-cols-3 gap-3"><div className="luxury-section p-4 text-center"><Star className="mx-auto h-5 w-5 text-gold-300"/><p className="mt-2 text-[11px] text-mystic-300">Gece puanı</p><b className="font-display text-gold-100">{won?'1':'0'}</b></div><div className="luxury-section p-4 text-center"><Coins className="mx-auto h-5 w-5 text-gold-300"/><p className="mt-2 text-[11px] text-mystic-300">Ödül</p><b className="font-display text-gold-100">1 kredi</b></div><div className="luxury-section p-4 text-center"><Sparkles className="mx-auto h-5 w-5 text-gold-300"/><p className="mt-2 text-[11px] text-mystic-300">Seri</p><b className="font-display text-gold-100">Gece</b></div></section>
  </div><RewardedAdModal open={reward} onComplete={close} onClose={()=>setReward(false)} rewardLabel="1 Kredi"/></div>
}
export default NightGamePage;
