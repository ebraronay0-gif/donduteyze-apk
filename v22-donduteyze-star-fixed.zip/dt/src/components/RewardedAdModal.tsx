import { useState, useEffect, useRef } from 'react';
import { Capacitor } from '@capacitor/core';
import { AdMob, RewardAdPluginEvents } from '@capacitor-community/admob';
import { X, Play, Gift, AlertCircle } from 'lucide-react';
import { getAdUnitId, USE_TEST_ADS } from '@/lib/ads';
import { trackAd } from '@/lib/analytics';

interface RewardedAdModalProps {
  open: boolean;
  onComplete: () => void;
  onClose: () => void;
  duration?: number;
  rewardLabel?: string;
}

function RewardedAdModal({
  open,
  onComplete,
  onClose,
  duration = 5,
  rewardLabel = 'ödül',
}: RewardedAdModalProps) {
  const [secondsLeft, setSecondsLeft] = useState(duration);
  const [completed, setCompleted] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [nativeError, setNativeError] = useState('');
  const timerRef = useRef<number | null>(null);
  const nativeStarted = useRef(false);

  useEffect(() => {
    let cancelled = false;
    if (!open) {
      setSecondsLeft(duration);
      setCompleted(false);
      setShowConfirm(false);
      setNativeError('');
      nativeStarted.current = false;
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }

    if (Capacitor.isNativePlatform()) {
      nativeStarted.current = true;
      let rewarded = false;
      let rewardListener: { remove: () => Promise<void> } | null = null;
      let failedListener: { remove: () => Promise<void> } | null = null;
      let showed = false;

      (async () => {
        try {
          rewardListener = await AdMob.addListener(RewardAdPluginEvents.Rewarded, () => {
            rewarded = true;
            if (!cancelled) onComplete();
          });
          failedListener = await AdMob.addListener(RewardAdPluginEvents.FailedToShow, () => {
            if (!cancelled && !rewarded) setNativeError('Reklam şu anda gösterilemedi. Lütfen tekrar deneyin.');
          });
          await AdMob.prepareRewardVideoAd({ adId: getAdUnitId('rewarded'), isTesting: USE_TEST_ADS });
          if (cancelled) return;
          showed = true;
          const rewardItem = await AdMob.showRewardVideoAd();
          if (!cancelled && !rewarded && rewardItem && Number(rewardItem.amount) > 0) {
            rewarded = true;
            onComplete();
          } else if (!cancelled && !showed) {
            onClose();
          }
        } catch (error) {
          console.error('Rewarded AdMob gösterilemedi:', error);
          if (!cancelled) setNativeError('Reklam yüklenemedi. Tekrar deneyin.');
        }
      })();
      return () => {
        cancelled = true;
        rewardListener?.remove();
        failedListener?.remove();
      };
    }

    timerRef.current = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          setCompleted(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => {
      cancelled = true;
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [open, duration, onComplete, onClose]);

  if (!open) return null;
  if (nativeStarted.current && Capacitor.isNativePlatform() && !nativeError) return null;
  if (nativeStarted.current && Capacitor.isNativePlatform() && nativeError) {
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-night-900/90 px-4 backdrop-blur-sm">
        <div className="w-full max-w-sm rounded-2xl border border-rose-400/30 bg-gradient-to-br from-night-700 to-night-900 p-6 text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-rose-400/30 bg-rose-900/20"><AlertCircle className="h-7 w-7 text-rose-300"/></div>
          <h3 className="mt-4 font-display text-lg text-gold-100">Reklam hazırlanamadı</h3>
          <p className="mt-2 text-xs text-mystic-400">{nativeError}</p>
          <button onClick={()=>setNativeError('')} className="mt-5 w-full rounded-xl border border-gold-400/40 bg-gold-900/30 px-4 py-3 text-sm font-semibold text-gold-100">Tekrar Dene</button>
          <button onClick={onClose} className="mt-2 w-full rounded-xl border border-white/10 px-4 py-3 text-xs text-mystic-400">Kapat</button>
        </div>
      </div>
    );
  }

  const progress = ((duration - secondsLeft) / duration) * 100;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-night-900/90 px-4 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-mystic-600/40 bg-gradient-to-br from-night-700 to-night-900 shadow-2xl animate-fade-in-up">
        {/* Ad label bar */}
        <div className="flex items-center justify-between bg-mystic-800/60 px-4 py-2">
          <span className="text-xs font-medium text-mystic-300">Reklam</span>
          <button
            onClick={() => {
              if (completed) { trackAd('ad_rewarded'); onComplete(); }
              else setShowConfirm(true);
            }}
            className="flex h-7 w-7 items-center justify-center rounded-full text-mystic-400 transition hover:text-mystic-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Ad content */}
        <div className="relative flex min-h-[220px] flex-col items-center justify-center p-6">
          <div className="pointer-events-none absolute -top-10 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-gold-500/10 blur-3xl" />

          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-gold-400/30 bg-gold-900/20">
            <Play className="h-8 w-8 text-gold-300" />
          </div>
          <p className="font-display text-lg font-semibold text-mystic-100">
            {USE_TEST_ADS ? 'Test Reklamı' : 'Reklam'}
          </p>
          <p className="mt-1 text-[10px] text-mystic-500">
            AdMob Birim: {getAdUnitId('rewarded')}
          </p>
          {USE_TEST_ADS && (
            <p className="mt-0.5 text-[9px] text-mystic-700">Test modu aktif</p>
          )}

          {/* Progress bar */}
          <div className="mt-5 h-1.5 w-full overflow-hidden rounded-full bg-mystic-700/40">
            <div
              className="h-full rounded-full bg-gold-400 transition-all duration-1000 ease-linear"
              style={{ width: `${progress}%` }}
            />
          </div>

          {completed ? (
            <div className="mt-5 flex flex-col items-center gap-3">
              <p className="text-sm font-medium text-emerald-300">Reklam tamamlandı!</p>
              <button
                onClick={onComplete}
                className="flex items-center gap-2 rounded-xl border border-gold-400/40 bg-gold-900/30 px-6 py-3 font-display text-sm font-semibold text-gold-100 transition hover:bg-gold-800/40"
              >
                <Gift className="h-4 w-4" />
                {rewardLabel} Al
              </button>
            </div>
          ) : (
            <p className="mt-4 text-xs text-mystic-400">
              Reklam {secondsLeft} saniye içinde bitecek...
            </p>
          )}
        </div>
      </div>

      {/* Confirm close dialog */}
      {showConfirm && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-night-900/80 px-6 animate-fade-in"
          onClick={() => setShowConfirm(false)}
        >
          <div
            className="max-w-sm rounded-2xl border border-rose-500/30 bg-gradient-to-br from-night-700 to-night-900 p-6 text-center animate-fade-in-up"
            onClick={(e) => e.stopPropagation()}
          >
            <AlertCircle className="mx-auto h-10 w-10 text-rose-400" />
            <p className="mt-3 font-display text-base font-semibold text-mystic-100">
              Reklamı kapatmak istediğinize emin misiniz?
            </p>
            <p className="mt-2 text-sm text-mystic-400">
              Reklamı tam izlerseniz {rewardLabel} kazanırsınız. Şimdi kapatırsanız ödül verilmeyecektir.
            </p>
            <div className="mt-5 flex gap-3">
              <button
                onClick={() => setShowConfirm(false)}
                className="flex-1 rounded-xl border border-gold-400/40 bg-gold-900/30 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:bg-gold-800/40"
              >
                Reklama Dön
              </button>
              <button
                onClick={() => {
                  setShowConfirm(false);
                  trackAd('ad_closed');
                  onClose();
                }}
                className="flex-1 rounded-xl border border-rose-500/30 bg-rose-900/20 px-4 py-3 font-display text-sm font-semibold text-rose-200 transition hover:bg-rose-800/30"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default RewardedAdModal;
