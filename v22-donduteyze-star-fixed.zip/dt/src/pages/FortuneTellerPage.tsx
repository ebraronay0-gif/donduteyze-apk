import { useState } from 'react';
import { ArrowLeft, Sparkles, Star, MessageCircle, Coins, Check } from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import { getCredits, spendCredits } from '@/lib/credits';
import { FORTUNE_TELLER_PRICE, purchaseChatSession } from '@/lib/liveChat';
import { hasSupabaseConfig, supabase } from '@/lib/supabase';
import type { AuthUser } from '@/lib/auth';

interface Props { onNavigate: (tab: NavTabId) => void; onOpenChat: (user: AuthUser, counselor: string) => void; }

const TELLERS = [
  { name: 'Melek Hanım', specialty: 'Kahve · Aşk', avatar: '🔮', glow: 'from-fuchsia-500/30 to-purple-950/60' },
  { name: 'Sultan Teyze', specialty: 'Tarot · Genel', avatar: '🪬', glow: 'from-amber-500/30 to-purple-950/60' },
  { name: 'Nehir', specialty: 'Yıldız · Burç', avatar: '🌙', glow: 'from-indigo-500/30 to-purple-950/60' },
  { name: 'Derya', specialty: 'Rüya · Katina', avatar: '✨', glow: 'from-violet-500/30 to-purple-950/60' },
];

async function getOrCreateGuest(): Promise<AuthUser | null> {
  const { data } = await supabase.auth.getSession();
  if (data.session?.user) return { id: data.session.user.id, email: data.session.user.email || '' };
  const { data: anon, error } = await supabase.auth.signInAnonymously();
  if (error || !anon.user) return null;
  return { id: anon.user.id, email: anon.user.email || '' };
}

function FortuneTellerPage({ onNavigate, onOpenChat }: Props) {
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [done, setDone] = useState('');

  const choose = async (name: string) => {
    if (busy) return;
    setError('');
    if (getCredits() < FORTUNE_TELLER_PRICE) {
      setError(`Bu falcıyla görüşmek için ${FORTUNE_TELLER_PRICE} kredi gerekiyor.`);
      return;
    }
    if (!hasSupabaseConfig) {
      setError('Falcı mesajlaşma sunucusu şu anda yapılandırılmamış.');
      return;
    }
    setBusy(name);
    const buyer = await getOrCreateGuest();
    if (!buyer) {
      setBusy(null);
      setError('Mesajlaşma bağlantısı kurulamadı. Lütfen tekrar deneyin.');
      return;
    }
    const result = spendCredits(FORTUNE_TELLER_PRICE);
    if (!result.success) { setBusy(null); setError('Yeterli krediniz yok.'); return; }
    const session = await purchaseChatSession(buyer, name);
    if (!session) {
      // If server session creation fails, return the spent credits.
      const { addCredits } = await import('@/lib/credits');
      addCredits(FORTUNE_TELLER_PRICE);
      setBusy(null);
      setError('Falcı sohbeti oluşturulamadı; krediniz iade edildi.');
      return;
    }
    setDone(name);
    setBusy(null);
    window.dispatchEvent(new Event('credits-updated'));
    setTimeout(() => onOpenChat(buyer, name), 500);
  };

  return <div className="relative min-h-screen overflow-hidden bg-[#08021a] pb-28">
    <StarField count={55}/>
    <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,rgba(126,34,206,.28),transparent_35%),radial-gradient(circle_at_90%_70%,rgba(245,158,11,.12),transparent_35%)]"/>
    <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
      <div className="mb-6 flex items-center gap-3">
        <button onClick={()=>onNavigate('home')} className="flex h-10 w-10 items-center justify-center rounded-full border border-gold-400/30 bg-gold-900/20 text-gold-200"><ArrowLeft className="h-5 w-5"/></button>
        <div><p className="text-[10px] uppercase tracking-[.25em] text-gold-300/70">Gerçek yorumcular</p><h1 className="font-display text-2xl text-gold-100">Falcını Seç</h1></div>
      </div>
      <div className="mb-5 rounded-[26px] border border-gold-400/25 bg-gradient-to-br from-[#2a0f47] to-[#0e0420] p-5 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold-300/40 bg-purple-950/60 text-3xl">🔮</div>
        <h2 className="mt-3 font-display text-xl text-gold-100">Birebir falcı mesajlaşması</h2>
        <p className="mt-1 text-xs text-mystic-400">Falcını seç. <b className="text-gold-200">{FORTUNE_TELLER_PRICE} kredi</b> düşsün ve mesaj kutun otomatik açılsın.</p>
      </div>
      {error && <div className="mb-4 rounded-2xl border border-rose-500/30 bg-rose-950/30 p-3 text-center text-xs text-rose-200">{error}</div>}
      <div className="grid grid-cols-2 gap-3">
        {TELLERS.map(t => <button key={t.name} onClick={()=>choose(t.name)} disabled={!!busy} className={`relative overflow-hidden rounded-[26px] border border-gold-400/25 bg-gradient-to-br ${t.glow} p-4 text-left shadow-[0_10px_30px_rgba(96,44,190,.16)] disabled:opacity-60`}>
          <div className="absolute right-3 top-3 rounded-full border border-gold-300/40 bg-black/35 px-2 py-1 text-[9px] font-bold text-gold-100">70 KREDİ</div>
          <div className="flex h-24 items-center justify-center text-6xl drop-shadow-[0_8px_15px_rgba(0,0,0,.35)]">{t.avatar}</div>
          <p className="mt-2 font-display text-base text-gold-100">{t.name}</p><p className="text-[10px] text-mystic-400">{t.specialty}</p>
          <div className="mt-3 flex items-center justify-between"><span className="flex items-center gap-1 text-[9px] text-gold-200"><Star className="h-3 w-3"/> Aktif</span><span className="flex items-center gap-1 rounded-xl border border-gold-300/30 bg-gold-500/10 px-2 py-1 text-[9px] text-gold-100"><MessageCircle className="h-3 w-3"/> Mesajlaş</span></div>
        </button>)}
      </div>
      {done && <div className="mt-5 flex items-center justify-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-950/25 p-3 text-xs text-emerald-200"><Check className="h-4 w-4"/> {done} seçildi · 70 kredi harcandı · mesaj kutusu açılıyor</div>}
      <p className="mt-6 text-center text-[9px] text-mystic-600">Yorumcuların yanıtları eğlence amaçlıdır.</p>
    </div>
  </div>;
}
export default FortuneTellerPage;
