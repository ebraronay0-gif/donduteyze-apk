import { useState, useEffect, useCallback, useRef } from 'react';
import { Send, MessageCircle, Clock, CheckCircle2, PhoneOff, Users, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { ChatSession, ChatMessage } from '@/lib/liveChat';

type AdminSession = ChatSession & { unread_count?: number };

function counselorFromMessages(messages: ChatMessage[]): string | null {
  const first = messages.find((m) => m.message.startsWith('FALCI SEÇİMİ:'));
  return first ? first.message.replace('FALCI SEÇİMİ:', '').trim() : null;
}

function LiveChatAdmin() {
  const [sessions, setSessions] = useState<AdminSession[]>([]);
  const [selectedSession, setSelectedSession] = useState<AdminSession | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchSessions = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('live_chat_sessions')
        .select('*')
        .in('status', ['pending', 'active'])
        .order('created_at', { ascending: true });
      if (!error && data) {
        const sessionsWithUnread = await Promise.all(
          (data as ChatSession[]).map(async (s) => {
            const { count } = await supabase
              .from('live_chat_messages')
              .select('*', { count: 'exact', head: true })
              .eq('session_id', s.id)
              .eq('sender', 'user')
              .eq('read', false);
            return { ...s, unread_count: count || 0 };
          })
        );
        setSessions(sessionsWithUnread);
      }
    } catch { /* ignore */ }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchSessions();
    const interval = setInterval(fetchSessions, 5000);
    return () => clearInterval(interval);
  }, [fetchSessions]);

  const loadMessages = useCallback(async (sessionId: string) => {
    const { data, error } = await supabase
      .from('live_chat_messages')
      .select('*')
      .eq('session_id', sessionId)
      .order('created_at', { ascending: true });
    if (!error && data) {
      setMessages(data as ChatMessage[]);
    }
    // Mark user messages as read
    await supabase
      .from('live_chat_messages')
      .update({ read: true })
      .eq('session_id', sessionId)
      .eq('sender', 'user')
      .eq('read', false);
  }, []);

  useEffect(() => {
    if (!selectedSession) return;
    loadMessages(selectedSession.id);
    const interval = setInterval(() => loadMessages(selectedSession.id), 3000);
    return () => clearInterval(interval);
  }, [selectedSession?.id, loadMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleConnect = async () => {
    if (!selectedSession || actionLoading) return;
    setActionLoading(true);
    await supabase
      .from('live_chat_sessions')
      .update({ status: 'active', connected_at: new Date().toISOString() })
      .eq('id', selectedSession.id);
    const updated = { ...selectedSession, status: 'active' as const, connected_at: new Date().toISOString() };
    setSelectedSession(updated);
    setSessions((prev) => prev.map((s) => (s.id === updated.id ? { ...s, status: 'active' } : s)));
    setActionLoading(false);
  };

  const handleEndChat = async () => {
    if (!selectedSession || actionLoading) return;
    setActionLoading(true);
    await supabase
      .from('live_chat_sessions')
      .update({ status: 'ended', ended_at: new Date().toISOString() })
      .eq('id', selectedSession.id);
    setSessions((prev) => prev.filter((s) => s.id !== selectedSession.id));
    setSelectedSession(null);
    setMessages([]);
    setActionLoading(false);
  };

  const handleSend = async () => {
    if (!input.trim() || !selectedSession || sending) return;
    setSending(true);
    setInput('');
    const { data } = await supabase
      .from('live_chat_messages')
      .insert({
        session_id: selectedSession.id,
        sender: 'admin',
        message: input.trim(),
        read: true,
      })
      .select()
      .maybeSingle();
    if (data) {
      setMessages((prev) => [...prev, data as ChatMessage]);
    }
    setSending(false);
  };

  const pendingCount = sessions.filter((s) => s.status === 'pending').length;
  const activeCount = sessions.filter((s) => s.status === 'active').length;

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="mb-1 font-display text-2xl font-bold text-mystic-100">Canlı Falcı Sohbeti</h1>
          <p className="text-sm text-mystic-400">Kullanıcı sohbetlerini yönetin</p>
        </div>
        <div className="flex gap-3">
          <div className="flex items-center gap-2 rounded-lg border border-gold-400/30 bg-gold-900/20 px-3 py-2">
            <Clock className="h-4 w-4 text-gold-300" />
            <span className="text-sm font-semibold text-gold-200">{pendingCount} Bekleyen</span>
          </div>
          <div className="flex items-center gap-2 rounded-lg border border-emerald-500/30 bg-emerald-900/20 px-3 py-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-300" />
            <span className="text-sm font-semibold text-emerald-200">{activeCount} Aktif</span>
          </div>
        </div>
      </div>

      <div className="flex h-[calc(100vh-280px)] min-h-[400px] gap-4">
        {/* Session list */}
        <div className="w-64 shrink-0 overflow-y-auto rounded-2xl border border-mystic-700/40 bg-night-800/60">
          <div className="border-b border-mystic-700/40 p-3">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-gold-300" />
              <span className="text-sm font-semibold text-mystic-100">Sohbetler</span>
            </div>
          </div>
          <div className="space-y-1 p-2">
            {sessions.length === 0 ? (
              <p className="p-4 text-center text-xs text-mystic-500">Aktif sohbet yok</p>
            ) : (
              sessions.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSelectedSession(s)}
                  className={`block w-full rounded-lg px-3 py-2.5 text-left transition ${
                    selectedSession?.id === s.id ? 'bg-gold-900/30 border border-gold-400/30' : 'hover:bg-night-700/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="truncate text-xs font-medium text-mystic-100">
                      {s.user_email || 'Bilinmeyen'}
                    </span>
                    {s.status === 'pending' ? (
                      <span className="shrink-0 rounded-full bg-gold-400/20 px-2 py-0.5 text-[9px] font-medium text-gold-200">
                        Bekliyor
                      </span>
                    ) : (
                      <span className="shrink-0 rounded-full bg-emerald-400/20 px-2 py-0.5 text-[9px] font-medium text-emerald-200">
                        Aktif
                      </span>
                    )}
                  </div>
                  {s.unread_count && s.unread_count > 0 ? (
                    <span className="mt-1 inline-block rounded-full bg-rose-500/20 px-2 py-0.5 text-[9px] text-rose-200">
                      {s.unread_count} yeni mesaj
                    </span>
                  ) : null}
                </button>
              ))
            )}
          </div>
        </div>

        {/* Chat area */}
        <div className="flex flex-1 flex-col overflow-hidden rounded-2xl border border-mystic-700/40 bg-night-800/60">
          {selectedSession ? (
            <>
              <div className="border-b border-mystic-700/40 px-4 py-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageCircle className="h-4 w-4 text-gold-300" />
                    <span className="font-display text-sm font-semibold text-mystic-100">
                      {selectedSession.user_email || 'Bilinmeyen'}
                    </span>{counselorFromMessages(messages) && <span className="ml-2 rounded-full border border-gold-400/30 bg-gold-900/20 px-2 py-0.5 text-[9px] text-gold-200">{counselorFromMessages(messages)}</span>}
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedSession.status === 'pending' && (
                      <button
                        onClick={handleConnect}
                        disabled={actionLoading}
                        className="flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-900/30 px-3 py-1.5 text-xs font-semibold text-emerald-200 transition hover:bg-emerald-800/40 disabled:opacity-50"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        Bağlan
                      </button>
                    )}
                    {selectedSession.status === 'active' && (
                      <button
                        onClick={handleEndChat}
                        disabled={actionLoading}
                        className="flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-900/30 px-3 py-1.5 text-xs font-semibold text-rose-200 transition hover:bg-rose-800/40 disabled:opacity-50"
                      >
                        <PhoneOff className="h-3.5 w-3.5" />
                        Sohbeti Sonlandır
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex-1 space-y-3 overflow-y-auto p-4">
                {messages.length === 0 && selectedSession.status === 'pending' && (
                  <div className="flex h-full items-center justify-center text-center">
                    <div>
                      <Clock className="mx-auto mb-3 h-8 w-8 text-gold-300/40" />
                      <p className="text-sm text-mystic-400">Kullanıcı bekliyor. "Bağlan" butonuna basarak sohbeti başlatın.</p>
                    </div>
                  </div>
                )}
                {messages.length === 0 && selectedSession.status === 'active' && (
                  <div className="flex h-full items-center justify-center text-center">
                    <div>
                      <MessageCircle className="mx-auto mb-3 h-8 w-8 text-gold-300/40" />
                      <p className="text-sm text-mystic-400">Sohbet başlatıldı. İlk mesajı gönderin.</p>
                    </div>
                  </div>
                )}
                {messages.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.sender === 'admin' ? 'justify-end' : 'justify-start'}`}>
                    <div
                      className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${
                        msg.sender === 'admin'
                          ? 'bg-gradient-to-r from-gold-700 to-gold-800 text-gold-100'
                          : 'bg-night-700/60 text-mystic-100'
                      }`}
                    >
                      <p className="leading-relaxed whitespace-pre-wrap">{msg.message}</p>
                      <p className="mt-1 text-[10px] opacity-60">
                        {new Date(msg.created_at).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>

              {selectedSession.status === 'active' && (
                <div className="border-t border-mystic-700/40 p-3">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                      placeholder="Mesaj yazın..."
                      className="flex-1 rounded-xl border border-mystic-700/50 bg-night-900/60 px-4 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50"
                    />
                    <button
                      onClick={handleSend}
                      disabled={sending || !input.trim()}
                      className="flex items-center justify-center rounded-xl border border-gold-400/50 bg-gradient-to-r from-gold-700 to-gold-800 px-4 text-gold-100 transition hover:scale-105 disabled:opacity-50"
                    >
                      <Send className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="flex flex-1 items-center justify-center text-center">
              <div>
                <MessageCircle className="mx-auto mb-3 h-10 w-10 text-mystic-600" />
                <p className="text-sm text-mystic-400">Bir sohbet seçin</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default LiveChatAdmin;
