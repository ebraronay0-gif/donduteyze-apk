import { useState } from 'react';
import { ArrowLeft, Layers, CheckCircle2, AlertCircle } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { NavTabId } from '@/lib/navTabs';
import { submitFortune } from '@/lib/fortuneApi';

interface KatinaFortunePageProps {
  onNavigate: (tab: NavTabId) => void;
}

const TOTAL_CARDS = 22;
const REQUIRED_PICKS = 3;

const CARD_FACES = [
  'Kırmızı Katina',
  'Mavi Katina',
  'Yeşil Katina',
  'Siyah Katina',
  'Beyaz Katina',
  'Altın Katina',
];

function KatinaFortunePage({ onNavigate }: KatinaFortunePageProps) {
  const [picks, setPicks] = useState<number[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAd, setShowAd] = useState(false);

  const canSubmit = picks.length === REQUIRED_PICKS;

  const togglePick = (idx: number) => {
    if (submitting || success) return;
    setPicks((prev) => {
      if (prev.includes(idx)) return prev.filter((p) => p !== idx);
      if (prev.length >= REQUIRED_PICKS) return prev;
      return [...prev, idx];
    });
  };

  const handleSubmit = async () => {
    if (!canSubmit || submitting) return;
    setShowAd(true);
  };

  const handleAdComplete = async () => {
    setShowAd(false);
    setSubmitting(true);
    setError(null);
    const cardNames = picks.map((idx) => CARD_FACES[idx % CARD_FACES.length]).join(', ');
    const result = await submitFortune({
      fortuneType: 'katina',
      userInput: `Seçilen 3 katina kartı: ${cardNames}.`,
    });
    if (result.success) {
      setSubmitting(false);
      setSuccess(true);
      setTimeout(() => {
        onNavigate('history');
      }, 4000);
    } else {
      setSubmitting(false);
      setError(result.error || 'Fal gönderilemedi.');
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={60} />

      {/* Red ambient glows */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-rose-600/25 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/3 -left-32 h-72 w-72 rounded-full bg-rose-700/20 animate-glow-pulse" style={{ animationDelay: '1.5s' }} />
      <div className="pointer-events-none absolute bottom-0 -right-32 h-72 w-72 rounded-full bg-red-800/20 animate-glow-pulse" style={{ animationDelay: '3s' }} />

      {/* Red vignette overlay */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-rose-950/20 via-transparent to-rose-950/20" />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-rose-400/30 bg-rose-900/20 text-rose-200 transition hover:border-rose-400/60 hover:text-rose-100"
          >
            <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <div className="flex items-center gap-2">
            <Layers className="h-6 w-6 text-rose-400" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">Katina Falı</h1>
          </div>
        </div>

        {/* Intro card */}
        <div className="relative mb-8 overflow-hidden rounded-2xl border border-rose-500/30 bg-gradient-to-br from-rose-900/30 via-night-700/70 to-night-800/80 p-5 backdrop-blur-sm" style={{ boxShadow: '0 0 12px rgba(244, 63, 94, 0.25), 0 0 24px rgba(244, 63, 94, 0.15), inset 0 0 10px rgba(244, 63, 94, 0.08)' }}>
          <div className="pointer-events-none absolute -top-10 -right-10 h-32 w-32 rounded-full bg-rose-500/20 blur-3xl" />
          <div className="relative flex items-start gap-3">
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-rose-400/30 bg-rose-900/30"
              style={{ boxShadow: '0 6px 18px rgba(244, 63, 94, 0.35), inset 0 1px 1px rgba(255,255,255,0.15)' }}
            >
              <Layers className="h-6 w-6 text-rose-300" />
            </div>
            <div>
              <h2 className="font-display text-lg font-semibold text-rose-100">Katina Falına Bak</h2>
              <p className="mt-1 font-serif text-sm italic leading-relaxed text-rose-100/80">
                Desteden {REQUIRED_PICKS} kart seçin, yorumcularımız sizin için gizli anlamları keşfetsin.
              </p>
            </div>
          </div>
        </div>

        {/* Pick counter */}
        <div className="mb-4 flex items-center justify-between">
          <span className="font-display text-sm font-medium text-rose-200">
            Seçilen Kartlar: {picks.length} / {REQUIRED_PICKS}
          </span>
          <div className="flex gap-1.5">
            {Array.from({ length: REQUIRED_PICKS }).map((_, i) => (
              <div
                key={i}
                className={`h-2 w-8 rounded-full transition-colors duration-300 ${
                  i < picks.length ? 'bg-rose-400' : 'bg-night-600'
                }`}
                style={i < picks.length ? { boxShadow: '0 0 8px rgba(244, 63, 94, 0.6)' } : undefined}
              />
            ))}
          </div>
        </div>

        {/* Card deck */}
        <div className="mb-8 grid grid-cols-4 gap-3 sm:grid-cols-6">
          {Array.from({ length: TOTAL_CARDS }).map((_, idx) => {
            const isPicked = picks.includes(idx);
            const pickOrder = picks.indexOf(idx);
            return (
              <button
                key={idx}
                onClick={() => togglePick(idx)}
                disabled={submitting || success}
                className="fortune-deck-card group relative aspect-[2/3] border transition-all duration-300 disabled:cursor-not-allowed"
                style={{
                  perspective: '600px',
                  boxShadow: isPicked
                    ? '0 8px 24px rgba(244, 63, 94, 0.5), inset 0 0 12px rgba(244, 63, 94, 0.15)'
                    : '0 4px 12px rgba(0,0,0,0.4)',
                }}
              >
                <div
                  className="relative h-full w-full transition-transform duration-500"
                  style={{ transformStyle: 'preserve-3d', transform: isPicked ? 'rotateY(180deg)' : 'none' }}
                >
                  {/* Card back */}
                  <div
                    className={`absolute inset-0 flex items-center justify-center rounded-lg border bg-transparent ${
                      isPicked ? 'border-transparent' : 'border-rose-400/30 group-hover:border-rose-400/60'
                    }`}
                    style={{ backfaceVisibility: 'hidden', transform: 'rotateY(0deg)' }}
                  >
                    <div className="flex flex-col items-center gap-1">
                      <Layers className="h-5 w-5 text-rose-400/60" strokeWidth={1.5} />
                      <div className="h-px w-6 bg-gradient-to-r from-transparent via-rose-400/40 to-transparent" />
                      <Layers className="h-5 w-5 text-rose-400/60" strokeWidth={1.5} />
                    </div>
                  </div>
                  {/* Card face (revealed) */}
                  <div
                    className="absolute inset-0 flex flex-col items-center justify-center gap-1 rounded-lg border border-rose-300/40 bg-gradient-to-br from-rose-700/25 to-violet-950/80 p-1"
                    style={{
                      backfaceVisibility: 'hidden',
                      transform: 'rotateY(180deg)',
                    }}
                  >
                    <Layers className="h-5 w-5 text-rose-300" strokeWidth={1.5} />
                    <span className="text-center text-[8px] font-medium leading-tight text-rose-100">
                      {CARD_FACES[idx % CARD_FACES.length]}
                    </span>
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-rose-400/30 text-[9px] font-bold text-rose-100">
                      {pickOrder + 1}
                    </span>
                  </div>
                </div>
                {/* Hover glow */}
                {!isPicked && !submitting && !success && (
                  <div className="pointer-events-none absolute inset-0 rounded-lg opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ boxShadow: 'inset 0 0 16px rgba(244, 63, 94, 0.25)' }} />
                )}
              </button>
            );
          })}
        </div>

        {/* Submit button */}
        <button
          onClick={handleSubmit}
          disabled={!canSubmit || submitting || success}
          className="group relative mb-6 flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl border border-rose-400/50 bg-gradient-to-r from-rose-700 via-rose-800 to-night-800 px-6 py-4 transition-all duration-300 enabled:hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50"
          style={{ boxShadow: '0 0 12px rgba(244, 63, 94, 0.3), 0 0 24px rgba(244, 63, 94, 0.2)' }}
        >
          <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-rose-300/25 to-transparent transition-transform duration-1000 enabled:group-hover:translate-x-full" />
          {submitting ? (
            <>
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-rose-200/30 border-t-rose-200" />
              <span className="font-display text-lg font-semibold text-rose-100">Yorumculara iletiliyor...</span>
            </>
          ) : success ? (
            <>
              <CheckCircle2 className="h-5 w-5 text-emerald-300" />
              <span className="font-display text-lg font-semibold text-emerald-200">İletildi</span>
            </>
          ) : (
            <>
              <Layers className="h-5 w-5 text-rose-300" />
              <span className="font-display text-lg font-semibold text-rose-100">Falıma Bak</span>
            </>
          )}
        </button>

        {error && (
          <div className="mb-4 flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-900/20 px-4 py-3 text-sm text-rose-200">
            <AlertCircle className="h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        {/* Legal disclaimer */}
        <p className="mx-auto max-w-md text-center text-[9px] leading-relaxed text-mystic-500/40">
          Döndü Teyze bir eğlence uygulamasıdır. Yorumcularımızın yorumları yalnızca eğlence amaçlıdır,
          profesyonel tavsiye niteliği taşımaz. Sonuçlar gerçek hayat olaylarını etkilemez veya
          öngörmez.
        </p>
      </div>

      <RewardedAdModal
        open={showAd}
        onComplete={handleAdComplete}
        onClose={() => setShowAd(false)}
        rewardLabel="Fal Yorumu"
      />

      {/* Success overlay */}
      {success && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in">
          <div className="relative max-w-sm rounded-2xl border border-rose-400/40 bg-gradient-to-br from-rose-900/40 via-night-700/90 to-night-800/95 p-8 text-center animate-fade-in-up" style={{ boxShadow: '0 0 12px rgba(244, 63, 94, 0.3), 0 0 24px rgba(244, 63, 94, 0.2)' }}>
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-rose-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div
                className="flex h-20 w-20 items-center justify-center rounded-full border border-rose-400/40 bg-rose-900/30"
                style={{ boxShadow: '0 0 36px rgba(244, 63, 94, 0.5)' }}
              >
                <CheckCircle2 className="h-10 w-10 text-rose-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-rose-100">Falınız İletildi</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              Falınız yıldızlara iletildi. Fallarım sayfasından takip edebilirsiniz.
            </p>
            <p className="mt-4 text-xs text-mystic-500">Fallarım sayfasına yönlendiriliyorsunuz...</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default KatinaFortunePage;
