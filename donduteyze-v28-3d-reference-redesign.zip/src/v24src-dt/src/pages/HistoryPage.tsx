import { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, History, Clock, Sparkles, AlertCircle, RefreshCw } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import BannerAd from '@/components/BannerAd';
import type { NavTabId } from '@/lib/navTabs';
import { fetchReadings, getCachedReadings, type FortuneReading } from '@/lib/fortuneApi';
import { FORTUNE_TYPE_LABELS, FORTUNE_TYPE_ICONS } from '@/lib/fortuneApi';

interface HistoryPageProps {
  onNavigate: (tab: NavTabId) => void;
}

function formatTimeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Az önce';
  if (mins < 60) return `${mins} dk önce`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} saat önce`;
  const days = Math.floor(hours / 24);
  return `${days} gün önce`;
}

function HistoryPage({ onNavigate }: HistoryPageProps) {
  // Show cached readings immediately; the network refresh happens in the background.
  // This prevents the whole page from being blocked by a slow Supabase request.
  const [readings, setReadings] = useState<FortuneReading[]>(() => getCachedReadings());
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [adForReading, setAdForReading] = useState<string | null>(null);

  const load = useCallback(async () => {
    setRefreshing(true);
    try {
      // Do not let a slow/hung network request block the UI.
      const data = await Promise.race([
        fetchReadings(),
        new Promise<FortuneReading[]>((resolve) => setTimeout(() => resolve(getCachedReadings()), 2500)),
      ]);
      setReadings(data);
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const refresh = () => { void load(); };
    const onVisible = () => {
      if (document.visibilityState === 'visible') refresh();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [load]);
  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={18} />

      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-gold-700/15 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/3 -right-40 h-72 w-72 rounded-full bg-mystic-700/10 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-mystic-700/40 bg-night-700/60 text-mystic-200 transition hover:border-gold-400/40 hover:text-gold-300"
          >
            <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <div className="flex items-center gap-2">
            <History className="h-6 w-6 text-gold-300" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">Fallarım</h1>
          </div>
          <button
            onClick={load}
            className="ml-auto flex h-9 w-9 items-center justify-center rounded-full border border-mystic-700/40 bg-night-700/60 text-mystic-300 transition hover:text-gold-300"
            aria-label="Yenile"
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {readings.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full border border-gold-400/20 bg-night-700/40">
              <Sparkles className="h-10 w-10 text-gold-300/40" />
            </div>
            <h2 className="font-display text-lg font-semibold text-mystic-200">Henüz falınız yok</h2>
            <p className="mt-2 max-w-xs text-sm text-mystic-400">
              Ana sayfadan bir fal türü seçip fal baktırın, sonuçlarınız burada görünecek.
            </p>
            <button
              onClick={() => onNavigate('home')}
              className="mt-6 rounded-xl border border-gold-400/40 bg-gold-900/30 px-5 py-2.5 font-display text-sm font-semibold text-gold-100 transition hover:bg-gold-800/40"
            >
              Fal Baktır
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {readings.map((reading) => {
              const isPending = reading.status === 'pending';
              const isRejected = reading.status === 'rejected';
              const isCompleted = reading.status === 'completed';
              const isExpanded = expandedId === reading.id;
              const label = FORTUNE_TYPE_LABELS[reading.fortune_type] || reading.fortune_type;
              const icon = FORTUNE_TYPE_ICONS[reading.fortune_type] || '✨';

              return (
                <div
                  key={reading.id}
                  className={`relative overflow-hidden rounded-2xl border backdrop-blur-sm transition ${
                    isPending
                      ? 'border-gold-400/30 bg-gradient-to-br from-gold-900/20 via-night-700/80 to-night-800/90'
                      : isRejected
                      ? 'border-rose-500/30 bg-gradient-to-br from-rose-900/20 via-night-700/80 to-night-800/90'
                      : 'border-mystic-700/40 bg-gradient-to-br from-night-700/80 to-night-800/90'
                  }`}
                >
                  <div className="pointer-events-none absolute -top-8 -right-8 h-24 w-24 rounded-full bg-gold-500/10 blur-2xl" />

                  {/* Card header */}
                  <button
                    onClick={() => isCompleted && setExpandedId(isExpanded ? null : reading.id)}
                    className="relative flex w-full items-center gap-3 p-4 text-left"
                  >
                    <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border text-2xl ${
                      isPending
                        ? 'border-gold-400/40 bg-gold-900/30'
                        : isRejected
                        ? 'border-rose-500/40 bg-rose-900/20'
                        : 'border-mystic-700/40 bg-night-900/40'
                    }`}>
                      {icon}
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="font-display text-base font-semibold text-gold-100">{label}</h3>
                      <p className="text-xs text-mystic-400">{formatTimeAgo(reading.created_at)}</p>
                    </div>
                    {isPending && (
                      <div className="flex items-center gap-1.5 rounded-full border border-gold-400/30 bg-gold-900/20 px-3 py-1.5">
                        <Clock className="h-3.5 w-3.5 text-gold-300" />
                        <span className="text-xs font-medium text-gold-200">Bekliyor</span>
                      </div>
                    )}
                    {isRejected && (
                      <div className="flex items-center gap-1.5 rounded-full border border-rose-500/30 bg-rose-900/20 px-3 py-1.5">
                        <AlertCircle className="h-3.5 w-3.5 text-rose-300" />
                        <span className="text-xs font-medium text-rose-200">Reddedildi</span>
                      </div>
                    )}
                    {isCompleted && (
                      <div className="flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-900/20 px-3 py-1.5">
                        <Sparkles className="h-3.5 w-3.5 text-emerald-300" />
                        <span className="text-xs font-medium text-emerald-200">Hazır</span>
                      </div>
                    )}
                  </button>

                  {/* Pending state */}
                  {isPending && (
                    <div className="relative px-4 pb-4">
                      <div className="rounded-xl border border-gold-400/20 bg-night-900/40 p-4 text-center">
                        <div className="mb-2 flex justify-center">
                          <span className="h-5 w-5 animate-spin rounded-full border-2 border-gold-200/30 border-t-gold-200" />
                        </div>
                        <p className="font-serif text-sm italic text-gold-200">
                          Falınız yükleniyor...
                        </p>
                        <p className="mt-1 text-xs text-mystic-400">
                          Yıldızlarda yorumlanıyor, lütfen bekleyin.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Rejected state */}
                  {isRejected && reading.result && (
                    <div className="relative px-4 pb-4">
                      <div className="rounded-xl border border-rose-500/20 bg-rose-900/10 p-4">
                        <p className="text-sm leading-relaxed text-rose-100">{reading.result}</p>
                      </div>
                    </div>
                  )}

                  {/* Completed state */}
                  {isCompleted && reading.fortune_type === 'star' && !reading.result && (
                    <div className="relative px-4 pb-4">
                      <div className="rounded-xl border border-rose-400/20 bg-rose-950/20 p-4 text-center">
                        <p className="text-sm text-rose-100">Yıldız yorumunun metni bu kayıtta bulunamadı.</p>
                        <p className="mt-1 text-xs text-mystic-400">Yeni Yıldız Falı başlatarak yeniden oluşturabilirsin.</p>
                      </div>
                    </div>
                  )}

                  {isCompleted && reading.result && (
                    <div className="relative px-4 pb-4">
                      <div
                        className={`overflow-hidden rounded-xl border border-mystic-700/30 bg-night-900/40 p-4 transition-all ${
                          isExpanded ? 'max-h-[2000px]' : 'max-h-24'
                        }`}
                      >
                        <p className="whitespace-pre-wrap text-sm leading-relaxed text-mystic-100">
                          {reading.result}
                        </p>
                      </div>
                      {!isExpanded && reading.result.length > 200 && (
                        <button
                          onClick={() => setAdForReading(reading.id)}
                          className="mt-2 text-xs font-medium text-gold-300 hover:text-gold-200"
                        >
                          Devamını Gör (Reklam İzle)
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Banner Ad */}
        <div className="mt-6">
          <BannerAd inline />
        </div>
      </div>
      <RewardedAdModal
        open={adForReading !== null}
        onComplete={() => {
          if (adForReading) setExpandedId(adForReading);
          setAdForReading(null);
        }}
        onClose={() => setAdForReading(null)}
        rewardLabel="Falın Tamamı"
      />
    </div>
  );
}

export default HistoryPage;
