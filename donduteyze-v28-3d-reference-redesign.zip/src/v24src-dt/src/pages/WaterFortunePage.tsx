import { useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { ArrowLeft, Droplets, RotateCw, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import { submitFortune } from '@/lib/fortuneApi';
import { getCredits, FORTUNE_COST } from '@/lib/credits';
import type { NavTabId } from '@/lib/navTabs';

interface Props { onNavigate: (tab: NavTabId) => void; }

function WaterFortunePage({ onNavigate }: Props) {
  const [mix, setMix] = useState(0);
  const [strokes, setStrokes] = useState(0);
  const [showAd, setShowAd] = useState(false);
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const lastPoint = useRef<{ x: number; y: number } | null>(null);
  const ready = strokes >= 8;
  const swirl = useMemo(() => mix % 360, [mix]);

  const stirStart = (e: ReactPointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    lastPoint.current = { x: e.clientX, y: e.clientY };
  };
  const stirMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!lastPoint.current) return;
    const dx = e.clientX - lastPoint.current.x;
    const dy = e.clientY - lastPoint.current.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    if (distance < 4) return;
    lastPoint.current = { x: e.clientX, y: e.clientY };
    setMix(v => v + distance * 2.8);
    setStrokes(v => Math.min(20, v + 1));
  };
  const stirEnd = () => { lastPoint.current = null; };

  const handleSubmit = () => {
    if (!ready || busy) return;
    if (getCredits() < FORTUNE_COST) { setError(`Su Falı için ${FORTUNE_COST} kredi gerekiyor.`); return; }
    setError('');
    setShowAd(true);
  };

  const handleAdComplete = async () => {
    setShowAd(false);
    setBusy(true);
    setError('');
    const result = await submitFortune({
      fortuneType: 'water',
      userInput: `Kullanıcı suyu parmağıyla ${strokes} hareketle karıştırdı. Su girdabı açısı ${Math.round(swirl)} derece. Su Falı yorumunu bu görsel ritüelin sembolik izlerine göre yap.`,
    });
    setBusy(false);
    if (!result.success) { setError(result.error || 'Su falın gönderilemedi.'); return; }
    setSuccess(true);
    setTimeout(() => onNavigate('history'), 2600);
  };

  return <div className="relative min-h-screen overflow-hidden bg-[#08021a] pb-28">
    <StarField count={80}/>
    <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,rgba(59,130,246,.24),transparent_32%),radial-gradient(circle_at_10%_70%,rgba(124,58,237,.18),transparent_35%)]"/>
    <div className="relative z-10 mx-auto max-w-2xl px-4 py-5">
      <button onClick={()=>onNavigate('home')} className="mb-5 flex items-center gap-2 rounded-full border border-gold-400/30 bg-night-800/70 px-4 py-2 text-sm text-gold-100"><ArrowLeft className="h-4 w-4"/> Geri</button>
      <section className="water-luxury-panel relative overflow-hidden rounded-[30px] border border-gold-300/35 p-4 shadow-[0_0_55px_rgba(124,58,237,.24)] sm:p-5">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_22%,rgba(59,130,246,.18),transparent_34%),radial-gradient(circle_at_12%_76%,rgba(168,85,247,.18),transparent_28%),radial-gradient(circle_at_88%_72%,rgba(251,191,36,.10),transparent_24%)]"/>
        <div className="relative text-center">
          <p className="text-[10px] uppercase tracking-[.35em] text-gold-200/70">Döndü Teyze'nin mistik ritüeli</p>
          <h1 className="mt-1 font-display text-3xl font-bold text-shimmer">SU FALI</h1>
          <p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-mystic-200">Lütfen suyu karıştırın. Parmağınızla suyu nazikçe hareket ettirin, falınızın enerjisini uyandıralım.</p>
        </div>
        <div className="relative mx-auto mt-5 max-w-sm overflow-hidden rounded-[28px] border border-gold-300/35 bg-[#11052a] p-2 shadow-[0_18px_50px_rgba(0,0,0,.55)]">
          <div className="pointer-events-none absolute inset-2 rounded-[24px] border border-white/10"/>
          <div className="relative aspect-[1.02] overflow-hidden rounded-[24px]">
            <img src="/water-bowl-reference.png" alt="Mistik su falı kasesi" className="absolute inset-0 h-full w-full object-cover transition-transform duration-200" style={{transform:`scale(${1.01 + Math.min(strokes,8)*.004}) rotate(${swirl*.015}deg)`}} draggable={false}/>
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_46%,transparent_20%,rgba(9,2,25,.12)_55%,rgba(9,2,25,.48)_100%)]"/>
            <div className="absolute left-1/2 top-1/2 h-[78%] w-[82%] -translate-x-1/2 -translate-y-1/2 rounded-[48%] border border-cyan-200/20 shadow-[inset_0_0_35px_rgba(34,211,238,.10),0_0_30px_rgba(59,130,246,.12)]" style={{transform:`translate(-50%,-50%) rotate(${swirl}deg)`}}/>
            <div className="absolute inset-0 touch-none select-none cursor-grab active:cursor-grabbing" onPointerDown={stirStart} onPointerMove={stirMove} onPointerUp={stirEnd} onPointerCancel={stirEnd}/>
            {!ready && <div className="pointer-events-none absolute inset-x-5 bottom-5 rounded-2xl border border-gold-300/35 bg-[#120629]/78 px-4 py-3 text-center backdrop-blur-md"><RotateCw className="mx-auto mb-1 h-5 w-5 animate-pulse text-gold-200"/><p className="font-display text-sm text-gold-100">Lütfen suyu karıştırın</p><p className="mt-1 text-[9px] text-mystic-300">Parmağınızla dairesel hareketler yapın</p></div>}
          </div>
        </div>
        <div className="relative mt-4 rounded-2xl border border-cyan-300/20 bg-[#07173a]/65 px-4 py-3 backdrop-blur"><div className="flex items-center justify-between text-[10px] text-mystic-300"><span>Su enerjisi</span><span className="font-bold text-cyan-100">{Math.min(strokes,8)}/8</span></div><div className="mt-2 h-2 overflow-hidden rounded-full border border-cyan-200/20 bg-black/35"><div className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-blue-500 to-violet-500 transition-all" style={{width:`${Math.min(100,strokes/8*100)}%`}}/></div></div>
        <button onClick={handleSubmit} disabled={!ready || busy} className="relative mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-gold-300/55 bg-gradient-to-r from-violet-700 via-purple-600 to-fuchsia-600 px-5 py-4 font-display text-lg font-semibold text-gold-50 shadow-[0_0_30px_rgba(168,85,247,.35)] disabled:cursor-not-allowed disabled:opacity-45"><Sparkles className="h-5 w-5"/>{busy?'Yapay zekâ yorumluyor...':`SU FALINA BAK · ${FORTUNE_COST} KREDİ`}</button>
        {error && <div className="mt-3 flex items-center gap-2 rounded-xl border border-rose-400/30 bg-rose-950/30 px-3 py-2 text-xs text-rose-200"><AlertCircle className="h-4 w-4"/>{error}</div>}
      </section>
      <p className="mx-auto mt-4 max-w-md text-center text-[9px] text-mystic-600">Su Falı yalnızca eğlence amaçlıdır.</p>
    </div>
    <RewardedAdModal open={showAd} onComplete={handleAdComplete} onClose={()=>setShowAd(false)} rewardLabel="Su Falı Yorumu"/>
    {success && <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/75 px-6 backdrop-blur-sm"><div className="w-full max-w-sm rounded-[28px] border border-cyan-300/30 bg-[#12082a] p-7 text-center"><CheckCircle2 className="mx-auto h-14 w-14 text-cyan-200"/><h2 className="mt-4 font-display text-xl text-gold-100">Su Falın Hazır ✨</h2><p className="mt-2 text-sm text-mystic-300">Yapay zekâ yorumun Fallarım'a kaydedildi.</p></div></div>}
  </div>;
}
export default WaterFortunePage;
