import { StrictMode } from 'react';
import { ensureAdMobInitialized } from './lib/ads';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

void ensureAdMobInitialized().catch((error) => console.warn('AdMob başlangıç uyarısı:', error));

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
