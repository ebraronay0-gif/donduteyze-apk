import type { LucideIcon } from 'lucide-react';
import { Home, Gift, History, Stars, Headphones } from 'lucide-react';
export type NavTabId = 'home' | 'earn' | 'history' | 'zodiac' | 'support' | 'premium';
export interface NavTab { id: NavTabId; label: string; icon: LucideIcon; }
export const NAV_TABS: NavTab[] = [
 {id:'home',label:'DÖNDÜ TEYZE',icon:Home},
 {id:'history',label:'FALLARIM',icon:History},
 {id:'earn',label:'Kredi Kazan',icon:Gift},
 {id:'zodiac',label:'Burçlar',icon:Stars},
 {id:'support',label:'Canlı Destek',icon:Headphones},
];
