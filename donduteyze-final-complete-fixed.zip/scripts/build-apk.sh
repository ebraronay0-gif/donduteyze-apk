#!/bin/bash
set -e

echo "Building web app..."
npm run build

echo "Syncing to Android..."
npx cap sync android
if command -v npx >/dev/null 2>&1; then
  npx capacitor-assets generate --android 2>/dev/null || true
fi
./scripts/configure-oauth-android.sh

echo "Done. APK can be built with:"
echo "  cd android && ./gradlew assembleDebug"
