
## Gemini Edge Function

Görsel ve rüya yorumlarının Gemini ile çalışması için `supabase/functions/gemini-fortune` fonksiyonu Supabase projesine dağıtılmalıdır. GitHub Actions bunu otomatik yapabilir: depo Secrets bölümüne `SUPABASE_ACCESS_TOKEN` ve `SUPABASE_PROJECT_REF` eklenirse her build sırasında fonksiyon da dağıtılır. `GEMINI_API_KEY` ise Supabase Edge Function secret olarak tanımlanmalıdır.

Edge Function erişilemiyorsa uygulama artık hata ekranında kalmaz; yerel yedek yorumla akışı tamamlar.
