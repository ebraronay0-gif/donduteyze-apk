/*
# Add increment_app_user_credits function

1. New Functions
- `increment_app_user_credits(p_email text, p_amount int)` — SECURITY DEFINER
  Safely increments the credits column of app_users for a given email.
  Used by the daily-credits edge function (service role).
2. Security
  - SECURITY DEFINER so the edge function can update credits.
  - EXECUTE granted to authenticated only (edge function uses service role key which bypasses).
*/

CREATE OR REPLACE FUNCTION increment_app_user_credits(p_email text, p_amount integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE app_users SET credits = credits + p_amount WHERE email = p_email;
END;
$$;

REVOKE ALL ON FUNCTION increment_app_user_credits(text, integer) FROM anon, authenticated;
