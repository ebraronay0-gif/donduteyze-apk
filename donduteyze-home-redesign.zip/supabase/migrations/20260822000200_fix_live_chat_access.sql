-- Live chat fix: the admin panel uses the app's client-side admin session,
-- so live chat rows must be readable/writable through the configured anon client.
-- User messages are allowed while a purchased session is pending so the user
-- can leave a message before the admin connects.

DROP POLICY IF EXISTS "select_live_chat_sessions_client" ON live_chat_sessions;
CREATE POLICY "select_live_chat_sessions_client" ON live_chat_sessions
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_live_chat_sessions_client" ON live_chat_sessions;
CREATE POLICY "insert_live_chat_sessions_client" ON live_chat_sessions
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_live_chat_sessions_client" ON live_chat_sessions;
CREATE POLICY "update_live_chat_sessions_client" ON live_chat_sessions
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "select_live_chat_messages_client" ON live_chat_messages;
CREATE POLICY "select_live_chat_messages_client" ON live_chat_messages
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_live_chat_messages_client" ON live_chat_messages;
CREATE POLICY "insert_live_chat_messages_client" ON live_chat_messages
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_live_chat_messages_client" ON live_chat_messages;
CREATE POLICY "update_live_chat_messages_client" ON live_chat_messages
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
