CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_email text NOT NULL,
  plan text NOT NULL CHECK (plan IN ('weekly', 'monthly', 'yearly')),
  ad_free boolean NOT NULL DEFAULT true,
  daily_credits integer NOT NULL DEFAULT 20,
  starts_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  last_credit_grant timestamptz,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_user_email ON subscriptions(user_email);
CREATE INDEX IF NOT EXISTS idx_subscriptions_active ON subscriptions(active) WHERE active = true;

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_subscriptions" ON subscriptions;
CREATE POLICY "select_own_subscriptions"
ON subscriptions FOR SELECT
TO authenticated
USING (user_email = (auth.jwt() ->> 'email'));

DROP POLICY IF EXISTS "insert_own_subscriptions" ON subscriptions;
CREATE POLICY "insert_own_subscriptions"
ON subscriptions FOR INSERT
TO authenticated
WITH CHECK (user_email = (auth.jwt() ->> 'email'));

DROP POLICY IF EXISTS "update_own_subscriptions" ON subscriptions;
CREATE POLICY "update_own_subscriptions"
ON subscriptions FOR UPDATE
TO authenticated
USING (user_email = (auth.jwt() ->> 'email'))
WITH CHECK (user_email = (auth.jwt() ->> 'email'));

CREATE OR REPLACE FUNCTION increment_app_user_credits(p_email text, p_amount integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE app_users SET credits = credits + p_amount WHERE email = p_email;
END;
$$;

REVOKE ALL ON FUNCTION increment_app_user_credits(text, integer) FROM anon, authenticated;
