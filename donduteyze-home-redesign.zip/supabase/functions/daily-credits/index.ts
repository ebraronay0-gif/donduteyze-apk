import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const now = new Date().toISOString();
    const oneDayAgo = new Date(now);
    oneDayAgo.setUTCDate(oneDayAgo.getUTCDate() - 1);

    const { data: subs, error } = await supabase
      .from("subscriptions")
      .select("id, user_email, daily_credits, last_credit_grant, expires_at")
      .eq("active", true)
      .gt("expires_at", now)
      .or(`last_credit_grant.is.null,last_credit_grant.lt.${oneDayAgo.toISOString()}`);

    if (error) {
      return new Response(
        JSON.stringify({ error: error.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    let granted = 0;
    for (const sub of subs ?? []) {
      const { error: grantError } = await supabase.rpc("increment_app_user_credits", {
        p_email: sub.user_email,
        p_amount: sub.daily_credits,
      });
      if (grantError) continue;

      await supabase
        .from("subscriptions")
        .update({ last_credit_grant: now })
        .eq("id", sub.id);

      granted++;
    }

    await supabase
      .from("subscriptions")
      .update({ active: false })
      .lt("expires_at", now)
      .eq("active", true);

    return new Response(
      JSON.stringify({ granted, total: subs?.length ?? 0 }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
