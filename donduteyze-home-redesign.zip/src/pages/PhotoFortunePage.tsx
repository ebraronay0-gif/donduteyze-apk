import { useRef, useState, useCallback } from 'react';
import { ArrowLeft, Camera, RefreshCw, Sparkles, CheckCircle2, AlertCircle, Image as ImageIcon } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { NavTabId } from '@/lib/navTabs';
import { submitFortune } from '@/lib/fortuneApi';

type Slot = { id: number; label: string; hint: string };
interface PhotoFortunePageProps {
  title: string;
  introTitle: string;
  introText: string;
  icon: React.ComponentType<{ className?: string }>;
  slots: Slot[];
  accentColor?: string;
  fortuneType: string;
  onNavigate: (tab: NavTabId) => void;
}

function PhotoFortunePage({ title, introTitle, introText, icon: Icon, slots, fortuneType, onNavigate }: PhotoFortunePageProps) {
  const [images, setImages] = useState<(string | null)[]>(() => slots.map(() => null));
  const [activeSlot, setActiveSlot] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAd, setShowAd] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const openCamera = (slot: number) => {
    setActiveSlot(slot);
    inputRef.current?.click();
  };

  const handleFile = (file?: File) => {
    if (!file || activeSlot === null) return;
    if (!file.type.startsWith('image/')) {
      setError('Lütfen bir fotoğraf seçin.');
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      setError('Fotoğraf 12 MB\'dan küçük olmalı.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setImages((prev) => {
        const next = [...prev];
        next[activeSlot] = String(reader.result);
        return next;
      });
      setError(null);
      setActiveSlot(null);
    };
    reader.onerror = () => setError('Fotoğraf okunamadı. Lütfen tekrar deneyin.');
    reader.readAsDataURL(file);
  };

  const ready = images.every(Boolean);

  const handleSubmit = useCallback(() => {
    if (!ready) {
      setError('Lütfen gerekli fotoğrafların tamamını çekin veya seçin.');
      return;
    }
    setShowAd(true);
  }, [ready]);

  const handleAdComplete = useCallback(async () => {
    setShowAd(false);
    setSubmitting(true);
    setError(null);
    try {
      const result = await submitFortune({
        fortuneType,
        userInput: `${title} fotoğraf analizi`,
        imageData: images.filter((x): x is string => Boolean(x)),
      });
      if (!result.success) throw new Error(result.error || 'Fal gönderilemedi.');
      setSubmitting(false);
      setSuccess(true);
      setTimeout(() => onNavigate('history'), 1200);
    } catch (err) {
      setSubmitting(false);
      setError(err instanceof Error ? err.message : 'Bir hata oluştu.');
    }
  }, [fortuneType, images, onNavigate, title]);

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={60} />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-indigo-950/60 via-night-900/70 to-night-900/95" />
      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="flex h-10 w-10 items-center justify-center rounded-full border border-indigo-400/30 bg-indigo-900/20 text-indigo-200">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <Icon className="h-6 w-6 text-indigo-300" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">{title}</h1>
          </div>
        </div>

        <div className="mb-5 rounded-2xl border border-indigo-500/20 bg-night-800/80 p-4">
          <h2 className="font-display text-lg font-semibold text-indigo-100">{introTitle}</h2>
          <p className="mt-1 text-sm text-indigo-200/70">{introText}</p>
        </div>

        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => {
            handleFile(e.target.files?.[0]);
            e.currentTarget.value = '';
          }}
        />

        <div className="space-y-4">
          {slots.map((slot, index) => {
            const image = images[index];
            return (
              <div key={slot.id} className="overflow-hidden rounded-3xl border border-indigo-500/30 bg-night-800 shadow-2xl">
                <div className="relative aspect-[4/3] flex items-center justify-center bg-night-900">
                  {image ? (
                    <img src={image} alt={slot.label} className="absolute inset-0 h-full w-full object-cover" />
                  ) : (
                    <div className="px-6 text-center">
                      <Camera className="mx-auto mb-3 h-10 w-10 text-indigo-300/70" />
                      <p className="font-semibold text-indigo-100">{slot.label}</p>
                      <p className="mt-1 text-sm text-indigo-200/60">{slot.hint}</p>
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <button onClick={() => openCamera(index)} disabled={submitting} className="flex w-full items-center justify-center gap-2 rounded-2xl border border-indigo-400/50 bg-gradient-to-r from-indigo-700 to-indigo-800 px-5 py-3 font-display font-semibold text-indigo-100">
                    {image ? <RefreshCw className="h-5 w-5" /> : <Camera className="h-5 w-5" />}
                    {image ? 'Yeniden Çek / Seç' : 'Fotoğraf Çek'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {error && <div className="mt-4 flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-900/20 px-4 py-3 text-sm text-rose-200"><AlertCircle className="h-4 w-4 shrink-0" />{error}</div>}

        <button onClick={handleSubmit} disabled={!ready || submitting || success} className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl border border-indigo-400/50 bg-gradient-to-r from-indigo-700 to-indigo-800 px-6 py-4 font-display text-lg font-semibold text-indigo-100 disabled:cursor-not-allowed disabled:opacity-40">
          {submitting ? <><span className="h-5 w-5 animate-spin rounded-full border-2 border-indigo-200/30 border-t-indigo-200" /> İletiliyor...</> : success ? <><CheckCircle2 className="h-5 w-5 text-emerald-300" /> Gönderildi</> : <><Sparkles className="h-5 w-5 text-indigo-300" /> Falımı Yorumla</>}
        </button>
        <div className="mt-3 flex items-center justify-center gap-2 text-xs text-indigo-200/50"><ImageIcon className="h-3.5 w-3.5" /> Kamera açılmazsa telefonun kendi kamera ekranı açılır.</div>
      </div>

      <RewardedAdModal open={showAd} onComplete={handleAdComplete} onClose={() => setShowAd(false)} rewardLabel={title} />
    </div>
  );
}

export default PhotoFortunePage;
