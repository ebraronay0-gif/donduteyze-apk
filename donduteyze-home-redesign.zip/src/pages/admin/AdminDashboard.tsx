import { useState, useEffect } from 'react';
import { Users, Coins, TrendingUp, MessageCircle, Bell, Activity, Globe2, Eye, UserMinus, MousePointerClick, RefreshCw } from 'lucide-react';
import { supabase, hasSupabaseConfig } from '@/lib/supabase';

type AnalyticsRow = { event_name: string; session_id: string; country: string | null; created_at: string; properties: Record<string, unknown> | null };

function StatCard({ icon: Icon, label, value, color, glow }: { icon: typeof Users; label: string; value: string; color: string; glow: string }) {
  return (
    <div className="rounded-2xl border border-mystic-700/40 bg-night-800/60 p-5" style={{ boxShadow: `0 4px 16px ${glow}` }}>
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-mystic-600/40 bg-night-700/60">
          <Icon className={`h-5 w-5 ${color}`} />
        </div>
        <div>
          <p className="text-xs text-mystic-400">{label}</p>
          <p className="font-display text-xl font-bold text-mystic-100">{value}</p>
        </div>
      </div>
    </div>
  );
}

function AdminDashboard() {
  const [stats, setStats] = useState({
    users: 0, newUsers: 0, credits: 0, messages: 0, notifications: 0,
    sessionsToday: 0, sessions7d: 0, exitsToday: 0, readings7d: 0,
    ads7d: 0, rewarded7d: 0, revenue: 0
  });
  const [countries, setCountries] = useState<[string, number][]>([]);
  const [plans, setPlans] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!hasSupabaseConfig) { setLoading(false); return; }
    setLoading(true);
    try {
      const now = new Date();
      const dayAgo = new Date(now.getTime() - 86400000).toISOString();
      const weekAgo = new Date(now.getTime() - 7 * 86400000).toISOString();

      const [usersRes, msgRes, notifRes, eventsRes, subsRes, pricesRes] = await Promise.all([
        supabase.from('app_users').select('id, credits, created_at'),
        supabase.from('support_messages').select('id', { count: 'exact', head: true }),
        supabase.from('notifications').select('id', { count: 'exact', head: true }),
        supabase.from('analytics_events').select('event_name, session_id, country, created_at, properties').gte('created_at', weekAgo).limit(10000),
        supabase.from('subscriptions').select('plan, created_at, active').gte('created_at', weekAgo),
        supabase.from('app_config').select('key, value').in('key', ['price_weekly','price_monthly','price_yearly','price_credits500']),
      ]);

      const users = usersRes.data || [];
      const events = (eventsRes.data || []) as AnalyticsRow[];
      const subs = subsRes.data || [];
      const priceMap: Record<string, number> = {};
      (pricesRes.data || []).forEach((r: { key: string; value: string | null }) => {
        priceMap[r.key] = Number(r.value || 0);
      });

      const sessionsToday = new Set(events.filter(e => e.created_at >= dayAgo && e.event_name === 'app_session').map(e => e.session_id)).size;
      const sessions7d = new Set(events.filter(e => e.event_name === 'app_session').map(e => e.session_id)).size;
      const exitsToday = new Set(events.filter(e => e.created_at >= dayAgo && e.event_name === 'app_close').map(e => e.session_id)).size;
      const readings7d = events.filter(e => e.event_name === 'fortune_open').length;
      const ads7d = events.filter(e => e.event_name === 'ad_rewarded' || e.event_name === 'ad_closed').length;
      const rewarded7d = events.filter(e => e.event_name === 'ad_rewarded').length;

      const countryCounts: Record<string, number> = {};
      events.filter(e => e.event_name === 'app_session').forEach(e => {
        const c = e.country || 'UNKNOWN';
        countryCounts[c] = (countryCounts[c] || 0) + 1;
      });
      setCountries(Object.entries(countryCounts).sort((a,b) => b[1]-a[1]).slice(0, 15));

      const planCounts: Record<string, number> = {};
      subs.forEach((s: { plan: string }) => { planCounts[s.plan] = (planCounts[s.plan] || 0) + 1; });
      setPlans(planCounts);

      const revenue = subs.reduce((sum: number, s: { plan: string }) => {
        const key = `price_${s.plan}`;
        return sum + (priceMap[key] || 0);
      }, 0);

      setStats({
        users: users.length,
        newUsers: users.filter((u: { created_at?: string }) => u.created_at && u.created_at >= dayAgo).length,
        credits: users.reduce((sum: number, u: { credits?: number }) => sum + (u.credits || 0), 0),
        messages: msgRes.count || 0,
        notifications: notifRes.count || 0,
        sessionsToday,
        sessions7d,
        exitsToday,
        readings7d,
        ads7d,
        rewarded7d,
        revenue,
      });
    } catch (e) {
      console.error('Admin analytics error', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  if (loading) return <div className="flex h-64 items-center justify-center"><span className="h-8 w-8 animate-spin rounded-full border-2 border-gold-400/30 border-t-gold-400" /></div>;

  return (
    <div>
      <div className="mb-6 flex items-start justify-between gap-3">
        <div>
          <h1 className="mb-1 font-display text-2xl font-bold text-mystic-100">Genel Bakış</h1>
          <p className="text-sm text-mystic-400">Kullanıcı, trafik, reklam ve gelir istatistikleri</p>
        </div>
        <button onClick={() => void load()} className="flex items-center gap-2 rounded-xl border border-mystic-700/40 px-3 py-2 text-xs text-mystic-300">
          <RefreshCw className="h-4 w-4" /> Yenile
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard icon={Users} label="Toplam Kullanıcı" value={String(stats.users)} color="text-sky-300" glow="rgba(56,189,248,0.15)" />
        <StatCard icon={UserMinus} label="Son 24 Saat Yeni" value={String(stats.newUsers)} color="text-emerald-300" glow="rgba(16,185,129,0.15)" />
        <StatCard icon={Eye} label="Son 24 Saat Ziyaret" value={String(stats.sessionsToday)} color="text-violet-300" glow="rgba(139,92,246,0.15)" />
        <StatCard icon={Activity} label="Son 7 Gün Ziyaret" value={String(stats.sessions7d)} color="text-amber-300" glow="rgba(245,158,11,0.15)" />
        <StatCard icon={MousePointerClick} label="Son 7 Gün Fal Açılışı" value={String(stats.readings7d)} color="text-indigo-300" glow="rgba(99,102,241,0.15)" />
        <StatCard icon={TrendingUp} label="Son 7 Gün Tahmini Gelir" value={`${stats.revenue.toFixed(2)} TL`} color="text-emerald-300" glow="rgba(16,185,129,0.15)" />
        <StatCard icon={Coins} label="Toplam Kredi" value={String(stats.credits)} color="text-gold-300" glow="rgba(251,191,36,0.15)" />
        <StatCard icon={MessageCircle} label="Destek Mesajı" value={String(stats.messages)} color="text-rose-300" glow="rgba(244,63,94,0.15)" />
        <StatCard icon={Bell} label="Gönderilen Bildirim" value={String(stats.notifications)} color="text-indigo-300" glow="rgba(99,102,241,0.15)" />
        <StatCard icon={Activity} label="Son 24 Saat Çıkış" value={String(stats.exitsToday)} color="text-orange-300" glow="rgba(249,115,22,0.15)" />
        <StatCard icon={Eye} label="Son 7 Gün Reklam Olayı" value={String(stats.ads7d)} color="text-cyan-300" glow="rgba(34,211,238,0.15)" />
        <StatCard icon={TrendingUp} label="Ödüllü Reklam" value={String(stats.rewarded7d)} color="text-lime-300" glow="rgba(132,204,22,0.15)" />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-mystic-700/40 bg-night-800/60 p-5">
          <div className="mb-4 flex items-center gap-2">
            <Globe2 className="h-5 w-5 text-sky-300" />
            <h2 className="font-display text-lg font-semibold text-mystic-100">Ziyaretçi Ülkeleri</h2>
          </div>
          <p className="mb-3 text-xs text-mystic-500">Tarayıcı dil/bölge bilgisinden tahmini olarak ölçülür.</p>
          {countries.length ? countries.map(([country, count]) => (
            <div key={country} className="mb-2 flex items-center justify-between rounded-lg bg-night-700/40 px-3 py-2 text-sm">
              <span className="text-mystic-200">{country}</span><span className="text-gold-300">{count}</span>
            </div>
          )) : <p className="text-sm text-mystic-500">Henüz veri yok.</p>}
        </div>

        <div className="rounded-2xl border border-mystic-700/40 bg-night-800/60 p-5">
          <h2 className="mb-4 font-display text-lg font-semibold text-mystic-100">Son 7 Gün Satışları</h2>
          {Object.keys(plans).length ? Object.entries(plans).map(([plan, count]) => (
            <div key={plan} className="mb-2 flex items-center justify-between rounded-lg bg-night-700/40 px-3 py-2 text-sm">
              <span className="text-mystic-200">{plan}</span><span className="text-emerald-300">{count} adet</span>
            </div>
          )) : <p className="text-sm text-mystic-500">Henüz satış verisi yok.</p>}
          <p className="mt-3 text-xs text-mystic-500">Gelir, Admin → İçerik & Fiyat bölümündeki fiyatlara göre hesaplanan tahmini tutardır.</p>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;
