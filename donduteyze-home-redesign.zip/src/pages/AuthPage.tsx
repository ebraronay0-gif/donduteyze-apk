import { useState } from 'react';
import { Sparkles, Mail, Lock, Eye, EyeOff, ArrowRight, User, LogIn, Shield, FileText, UserCheck } from 'lucide-react';
import StarField from '@/components/StarField';
import { signUpWithEmail, signInWithEmail, signInWithGoogle, signInWithApple } from '@/lib/auth';
import LegalModal, { type LegalType } from '@/components/LegalModal';
import type { AuthUser } from '@/lib/auth';

interface AuthPageProps {
  mode: 'login' | 'signup';
  onSuccess: (user: AuthUser) => void;
  onSwitchMode: (mode: 'login' | 'signup') => void;
  onBack: () => void;
  reasonText?: string;
  compact?: boolean;
  topAligned?: boolean;
  showLegal?: boolean;
}

function AuthPage({ mode, onSuccess, onSwitchMode, onBack, reasonText, compact, topAligned, showLegal }: AuthPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [agreed, setAgreed] = useState(false);
  const [legalType, setLegalType] = useState<LegalType | null>(null);

  const isSignup = mode === 'signup';
  const canSubmit = agreed && !loading && email && password;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || loading || !agreed) return;
    setLoading(true);
    setError(null);
    const result = isSignup
      ? await signUpWithEmail(email, password)
      : await signInWithEmail(email, password);
    if (result.error) {
      setError(result.error);
      setLoading(false);
    } else if (result.user) {
      onSuccess(result.user);
    } else {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    if (!agreed) return;
    setLoading(true);
    setError(null);
    const result = await signInWithGoogle();
    if (result.error) {
      setError(result.error);
      setLoading(false);
    }
  };

  const handleApple = async () => {
    if (!agreed) return;
    setLoading(true);
    setError(null);
    const result = await signInWithApple();
    if (result.error) {
      setError(result.error);
      setLoading(false);
    }
  };

  return (
    <>
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900">
      <StarField count={60} />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-gold-700/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/3 -right-40 h-72 w-72 rounded-full bg-mystic-700/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className={`relative z-10 flex min-h-screen px-4 py-8 ${topAligned ? 'items-start justify-center pt-10' : 'items-center justify-center'}`}>
        <div className={`w-full ${compact ? 'max-w-xs' : 'max-w-sm'}`}>
          {/* Back button */}
          <button
            onClick={onBack}
            className="mb-4 flex items-center gap-1 text-sm text-mystic-400 transition hover:text-mystic-200"
          >
            <span className="text-lg leading-none">‹</span> Geri
          </button>

          {/* Logo */}
          <div className={`mb-${compact ? '4' : '6'} text-center`}>
            <div className={`mx-auto mb-${compact ? '2' : '4'} flex ${compact ? 'h-12 w-12' : 'h-16 w-16'} items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/30 glow-border-gold`}>
              <Sparkles className={`${compact ? 'h-6 w-6' : 'h-8 w-8'} text-gold-300`} />
            </div>
            <h1 className={`font-display ${compact ? 'text-xl' : 'text-2xl'} font-bold tracking-widest text-shimmer`}>
              {isSignup ? 'ÜYE OL' : 'GİRİŞ YAP'}
            </h1>
            <p className="mt-1 text-xs text-mystic-400">Döndü Teyze dünyasına katıl</p>
          </div>

          {/* Reason text */}
          {reasonText && (
            <div className="mb-5 rounded-xl border border-gold-400/30 bg-gold-900/20 px-4 py-3 text-center text-sm leading-relaxed text-gold-200">
              {reasonText}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="rounded-2xl border border-mystic-700/40 bg-night-800/80 p-6 backdrop-blur-sm">
            <div className={`space-y-${compact ? '3' : '4'}`}>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-mystic-300">E-posta</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-mystic-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ornek@email.com"
                    className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 py-3 pl-10 pr-4 text-sm text-mystic-100 outline-none transition focus:border-gold-400/50"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-medium text-mystic-300">Şifre</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-mystic-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    minLength={6}
                    className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 py-3 pl-10 pr-10 text-sm text-mystic-100 outline-none transition focus:border-gold-400/50"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-mystic-400 hover:text-mystic-200"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <p className="rounded-lg border border-rose-500/30 bg-rose-900/20 px-3 py-2 text-xs text-rose-200">{error}</p>
              )}

              {/* Agreement checkbox */}
              {showLegal && (
                <label className="flex cursor-pointer items-start gap-2 text-xs leading-relaxed text-mystic-300">
                  <input
                    type="checkbox"
                    checked={agreed}
                    onChange={(e) => setAgreed(e.target.checked)}
                    className="mt-0.5 h-4 w-4 shrink-0 rounded border-mystic-600 bg-night-900 accent-gold-500"
                  />
                  <span>
                    <button type="button" className="text-gold-200 underline-offset-2 hover:underline" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setLegalType('user-agreement'); }}>Kullanıcı Sözleşmesi</button>, <button type="button" className="text-gold-200 underline-offset-2 hover:underline" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setLegalType('privacy'); }}>Gizlilik Anlaşması</button> ve <button type="button" className="text-gold-200 underline-offset-2 hover:underline" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setLegalType('terms'); }}>Kullanım Şartları</button>'nı okudum, kabul ediyorum.
                  </span>
                </label>
              )}

              <button
                type="submit"
                disabled={!canSubmit}
                className="flex w-full items-center justify-center gap-2 rounded-xl border border-gold-400/50 bg-gradient-to-r from-gold-700 to-gold-800 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100"
              >
                {loading ? (
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-gold-200/30 border-t-gold-200" />
                ) : (
                  <>
                    {isSignup ? <><User className="h-4 w-4" /> Üye Ol</> : <><LogIn className="h-4 w-4" /> Giriş Yap</>}
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>
            </div>

            {/* Divider */}
            <div className="my-5 flex items-center gap-3">
              <div className="h-px flex-1 bg-mystic-700/40" />
              <span className="text-xs text-mystic-500">veya</span>
              <div className="h-px flex-1 bg-mystic-700/40" />
            </div>

            {/* Social buttons */}
            <div className="space-y-2.5">
              <button
                type="button"
                onClick={handleGoogle}
                disabled={loading || !agreed}
                className="flex w-full items-center justify-center gap-2.5 rounded-xl border border-mystic-700/50 bg-night-900/60 px-4 py-3 text-sm font-medium text-mystic-100 transition hover:bg-night-700/60 disabled:opacity-50"
              >
                <svg className="h-5 w-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"/>
                </svg>
                Google ile {isSignup ? 'Üye Ol' : 'Giriş Yap'}
              </button>

              <button
                type="button"
                onClick={handleApple}
                disabled={loading || !agreed}
                className="flex w-full items-center justify-center gap-2.5 rounded-xl border border-mystic-700/50 bg-night-900/60 px-4 py-3 text-sm font-medium text-mystic-100 transition hover:bg-night-700/60 disabled:opacity-50"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
                </svg>
                Apple ile {isSignup ? 'Üye Ol' : 'Giriş Yap'}
              </button>
            </div>
          </form>

          {/* Switch mode */}
          <p className="mt-5 text-center text-sm text-mystic-400">
            {isSignup ? 'Zaten hesabın var?' : 'Hesabın yok mu?'}{' '}
            <button
              onClick={() => onSwitchMode(isSignup ? 'login' : 'signup')}
              className="font-medium text-gold-200 underline-offset-2 hover:underline"
            >
              {isSignup ? 'Giriş Yap' : 'Üye Ol'}
            </button>
          </p>

          {/* Legal links */}
          {showLegal && (
            <div className="mt-6 flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[10px] text-mystic-500">
              <button type="button" className="flex items-center gap-1 transition hover:text-mystic-300" onClick={() => setLegalType('user-agreement')}>
                <UserCheck className="h-3 w-3" />
                Kullanıcı Sözleşmesi
              </button>
              <span className="text-mystic-700">•</span>
              <button type="button" className="flex items-center gap-1 transition hover:text-mystic-300" onClick={() => setLegalType('privacy')}>
                <Shield className="h-3 w-3" />
                Gizlilik Anlaşması
              </button>
              <span className="text-mystic-700">•</span>
              <button type="button" className="flex items-center gap-1 transition hover:text-mystic-300" onClick={() => setLegalType('terms')}>
                <FileText className="h-3 w-3" />
                Kullanım Şartları
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
      <LegalModal type={legalType} onClose={() => setLegalType(null)} />
    </>
  );
}

export default AuthPage;
