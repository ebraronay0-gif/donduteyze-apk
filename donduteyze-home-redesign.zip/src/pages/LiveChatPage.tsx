import { useState, useCallback, useEffect, useRef } from 'react';
import { ArrowLeft, Send, MessageSquare, Sparkles, ShieldCheck } from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import type { AuthUser } from '@/lib/auth';
import { getActiveSession, fetchMessages, sendMessage, subscribeToMessages, subscribeToSession, type ChatMessage, type ChatSession } from '@/lib/liveChat';

interface LiveChatPageProps {
  onNavigate: (tab: NavTabId) => void;
  authUser: AuthUser;
}

function LiveChatPage({ onNavigate, authUser }: LiveChatPageProps) {
  const [session, setSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    const current = await getActiveSession(authUser);
    setSession(current);
    if (current) setMessages(await fetchMessages(current.id));
    setLoading(false);
  }, [authUser]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!session) return;
    const unsubscribeMessages = subscribeToMessages(session.id, setMessages);
    const unsubscribeSession = subscribeToSession(session.id, (updated) => setSession(updated));
    return () => {
      unsubscribeMessages();
      unsubscribeSession();
    };
  }, [session?.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = useCallback(async () => {
    const text = inputText.trim();
    if (!text || !session || sending) return;

    setInputText('');
    setSending(true);
    const sent = await sendMessage(session.id, 'user', text);
    if (sent) {
      setMessages((prev) => prev.some((m) => m.id === sent.id) ? prev : [...prev, sent]);
    } else {
      setInputText(text);
    }
    setSending(false);
  }, [inputText, session, sending]);

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-night-900 pb-24">
      <StarField count={30} />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-indigo-950/50 via-night-900/80 to-night-900" />

      <div className="relative z-10 border-b border-indigo-500/20 bg-night-900/80 px-4 py-4 backdrop-blur-md">
        <div className="mx-auto flex max-w-2xl items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => onNavigate('home')} className="flex h-10 w-10 items-center justify-center rounded-full border border-indigo-400/30 bg-indigo-900/20 text-indigo-200">
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-indigo-300" />
              <div>
                <h1 className="font-display text-base font-semibold text-indigo-100">Canlı Destek</h1>
                <p className="text-xs text-emerald-400 font-medium">Mesajlarınız güvenli şekilde kaydedilir</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1 rounded-full border border-indigo-500/30 bg-indigo-950/40 px-3 py-1 text-[11px] text-indigo-300">
            <ShieldCheck className="h-3.5 w-3.5 text-indigo-400" />
            <span>Güvenli Hat</span>
          </div>
        </div>
      </div>

      <div className="relative z-10 mx-auto w-full max-w-2xl flex-1 overflow-y-auto px-4 py-6 space-y-4">
        {loading ? (
          <div className="flex h-full items-center justify-center text-sm text-mystic-400">Sohbet yükleniyor...</div>
        ) : !session ? (
          <div className="flex h-full items-center justify-center text-center">
            <div className="max-w-sm rounded-2xl border border-gold-400/20 bg-night-800/70 p-6">
              <Sparkles className="mx-auto mb-3 h-8 w-8 text-gold-300" />
              <h2 className="font-display text-lg font-semibold text-gold-100">Aktif sohbet bulunamadı</h2>
              <p className="mt-2 text-sm leading-relaxed text-mystic-400">Canlı sohbet satın alındığında burada mesajlaşabilirsiniz.</p>
            </div>
          </div>
        ) : (
          <>
            {session.status === 'pending' && (
              <div className="rounded-xl border border-gold-400/20 bg-gold-900/15 px-4 py-3 text-center text-xs text-gold-200">
                Sohbet talebiniz alındı. Falcı bağlandığında konuşma başlayacak. Mesajlarınız kaydedilir.
              </div>
            )}
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${msg.sender === 'user' ? 'bg-gradient-to-r from-indigo-700 to-indigo-800 text-indigo-50 rounded-br-none' : 'bg-night-800/90 text-indigo-100 rounded-bl-none border border-indigo-500/20'}`}>
                  {msg.sender === 'admin' && <div className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold text-indigo-300"><Sparkles className="h-3 w-3" /><span>Döndü Teyze Destek Ekibi</span></div>}
                  <p>{msg.message}</p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {session && (
        <div className="fixed bottom-0 left-0 right-0 z-20 border-t border-indigo-500/20 bg-night-900/95 p-4 backdrop-blur-md">
          <div className="mx-auto flex max-w-2xl items-center gap-2">
            <input type="text" value={inputText} onChange={(e) => setInputText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()} placeholder="Mesajınızı yazın..." className="flex-1 rounded-2xl border border-indigo-500/30 bg-night-800/90 px-4 py-3 text-sm text-indigo-100 placeholder:text-indigo-300/40 focus:border-indigo-400 focus:outline-none" />
            <button onClick={handleSendMessage} disabled={!inputText.trim() || sending} className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-r from-indigo-600 to-indigo-800 text-indigo-100 disabled:opacity-50">
              {sending ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-indigo-200/30 border-t-indigo-200" /> : <Send className="h-5 w-5" />}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default LiveChatPage;
