import { useState, useRef } from 'react';
import { Crown, Check, Shield, FileText, UserCheck, Sparkles, Coins, MessageCircle, Zap, X, Loader2 } from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import { purchasePlan, type PlanId } from '@/lib/subscriptions';
import type { AuthUser } from '@/lib/auth';

interface PremiumPageProps {
  onNavigate: (tab: NavTabId) => void;
  onRequireAuth?: () => void;
  isLoggedIn?: boolean;
  onOpenLiveChat?: () => void;
  authUser?: AuthUser | null;
}

interface Plan {
  id: string;
  name: string;
  price: string;
  period: string;
  features: string[];
  highlight?: boolean;
  badge?: string;
}

const SUBSCRIPTION_PLANS: Plan[] = [
  {
    id: 'weekly',
    name: 'Haftalık',
    price: '59,99',
    period: 'TL / hafta',
    features: ['Reklamsız deneyim', 'Her gün 20 kredi', 'Öncelikli fal'],
  },
  {
    id: 'monthly',
    name: 'Aylık',
    price: '99,99',
    period: 'TL / ay',
    features: ['Reklamsız deneyim', 'Her gün 20 kredi', 'Öncelikli fal'],
    badge: 'En Popüler',
  },
  {
    id: 'yearly',
    name: 'Yıllık',
    price: '499,99',
    period: 'TL / yıl',
    features: ['Reklamsız deneyim', 'Her gün 20 kredi', 'Öncelikli fal', 'Falcılarla sohbet (1 defa)'],
    badge: 'En Avantajlı',
  },
];

const CREDIT_PACK: Plan = {
  id: 'credits500',
  name: '500 Kredi',
  price: '699,99',
  period: 'TL tek seferlik',
  features: ['Reklamsız deneyim', '500 kredi anında yüklenir', 'Süresiz kullanım'],
  highlight: true,
};

const FEATURE_ICONS = [Zap, Coins, Crown, MessageCircle];

function PremiumPage({ onNavigate, onRequireAuth, isLoggedIn, onOpenLiveChat, authUser }: PremiumPageProps) {
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [purchasing, setPurchasing] = useState(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);
  const carouselRef = useRef<HTMLDivElement>(null);

  const scrollCarousel = (dir: 'left' | 'right') => {
    const el = carouselRef.current;
    if (!el) return;
    const amount = 280;
    el.scrollBy({ left: dir === 'left' ? -amount : amount, behavior: 'smooth' });
  };

  const handleBuy = async (plan: Plan) => {
    if (!isLoggedIn && onRequireAuth) {
      onRequireAuth();
      return;
    }
    if (!authUser) {
      onRequireAuth?.();
      return;
    }
    setPurchasing(true);
    setPurchaseError(null);
    const result = await purchasePlan(plan.id as PlanId, authUser);
    setPurchasing(false);
    if (result.success) {
      setSelectedPlan(plan);
    } else {
      setPurchaseError(result.error || 'Satın alma başarısız oldu.');
    }
  };

  const handleCloseSuccess = () => {
    setSelectedPlan(null);
    onNavigate('home');
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={50} />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-gold-700/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/3 -right-40 h-72 w-72 rounded-full bg-mystic-700/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Account warning banner */}
        {!isLoggedIn && (
          <div className="mb-6 flex items-start gap-3 rounded-2xl border border-gold-400/30 bg-gold-900/20 p-4 backdrop-blur-sm">
            <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/40">
              <Shield className="h-4 w-4 text-gold-300" />
            </div>
            <div>
              <p className="text-sm font-medium text-gold-100">Kredilerini güvende sakla</p>
              <p className="mt-1 text-xs leading-relaxed text-mystic-300">
                Aldığın krediyi saklayabilmek ve cihaz değiştirdiğinde kaybetmemek için hesap oluşturman gerekiyor. Üye olmadan satın alma yaparsan kredilerin cihazında kalır ama yedeklenmez.
              </p>
              <button
                onClick={() => onRequireAuth?.()}
                className="mt-2.5 inline-flex items-center gap-1.5 rounded-lg border border-gold-400/50 bg-gradient-to-r from-gold-700 to-gold-800 px-3 py-1.5 text-xs font-semibold text-gold-100 transition hover:scale-[1.02]"
              >
                Hesap Oluştur
              </button>
            </div>
          </div>
        )}
        {/* Header */}
        <div className="mb-6 text-center">
          <div className="inline-flex items-center gap-2">
            <Crown className="h-7 w-7 text-gold-300" />
            <h1 className="font-display text-3xl font-bold tracking-widest text-shimmer">PREMIUM</h1>
            <Crown className="h-7 w-7 text-gold-300" />
          </div>
          <div className="mx-auto mt-2 h-px w-32 bg-gradient-to-r from-transparent via-gold-400/50 to-transparent" />
          <p className="mt-3 font-serif text-sm italic text-mystic-300">Döndü Teyze'nın tüm ayrıcalıklarının kilidini aç</p>
        </div>

        {/* Carousel section */}
        <div className="mb-6">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold text-gold-100">Abonelik Paketleri</h2>
            <div className="flex gap-2">
              <button
                onClick={() => scrollCarousel('left')}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-gold-400/30 bg-night-700/60 text-gold-200 transition hover:border-gold-400/60 hover:text-gold-100"
                aria-label="Sola kaydır"
              >
                <span className="text-lg leading-none">‹</span>
              </button>
              <button
                onClick={() => scrollCarousel('right')}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-gold-400/30 bg-night-700/60 text-gold-200 transition hover:border-gold-400/60 hover:text-gold-100"
                aria-label="Sağa kaydır"
              >
                <span className="text-lg leading-none">›</span>
              </button>
            </div>
          </div>

          <div
            ref={carouselRef}
            className="flex snap-x snap-mandatory gap-4 overflow-x-auto pb-4 scrollbar-hide"
            style={{ scrollSnapType: 'x mandatory' }}
          >
            {SUBSCRIPTION_PLANS.map((plan) => {
              const isPopular = plan.badge === 'En Popüler';
              return (
                <div
                  key={plan.id}
                  className="relative w-[260px] shrink-0 snap-center overflow-hidden rounded-2xl border border-gold-400/30 bg-gradient-to-br from-night-700/80 to-night-800/90 p-5 backdrop-blur-sm transition hover:border-gold-400/50"
                  style={{ boxShadow: isPopular ? '0 0 16px rgba(251, 191, 36, 0.25), 0 0 32px rgba(251, 191, 36, 0.15)' : '0 4px 16px rgba(0,0,0,0.3)' }}
                >
                  {plan.badge && (
                    <div className="absolute top-0 right-0 rounded-bl-xl bg-gradient-to-r from-gold-600 to-gold-500 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-night-900">
                      {plan.badge}
                    </div>
                  )}
                  <div className="pointer-events-none absolute -top-8 -right-8 h-24 w-24 rounded-full bg-gold-500/15 blur-2xl" />

                  <div className="relative mb-4 mt-2">
                    <h3 className="font-display text-xl font-semibold text-gold-100">{plan.name}</h3>
                    <div className="mt-2 flex items-baseline gap-1">
                      <span className="font-display text-3xl font-bold text-shimmer">{plan.price}</span>
                      <span className="text-xs text-mystic-400">{plan.period}</span>
                    </div>
                  </div>

                  <ul className="relative mb-5 space-y-2.5">
                    {plan.features.map((feature, i) => {
                      const Icon = FEATURE_ICONS[i] || Check;
                      return (
                        <li key={i} className="flex items-center gap-2 text-sm text-mystic-200">
                          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-gold-400/30 bg-gold-900/20">
                            <Icon className="h-3 w-3 text-gold-300" />
                          </span>
                          {feature}
                        </li>
                      );
                    })}
                  </ul>

                  <button
                    onClick={() => handleBuy(plan)}
                    disabled={purchasing}
                    className="group relative w-full overflow-hidden rounded-xl border border-gold-400/50 bg-gradient-to-r from-gold-700 via-gold-800 to-night-800 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:scale-[1.02] disabled:opacity-60"
                    style={{ boxShadow: '0 0 12px rgba(251, 191, 36, 0.25)' }}
                  >
                    <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-gold-300/25 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />
                    {purchasing ? <Loader2 className="mx-auto h-4 w-4 animate-spin" /> : 'Satın Al'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Live Chat CTA */}
        {onOpenLiveChat && (
          <button
            onClick={onOpenLiveChat}
            className="group relative mb-6 flex w-full items-center gap-3 overflow-hidden rounded-2xl border border-gold-400/50 bg-gradient-to-r from-amber-700/40 via-gold-800/30 to-night-800/80 px-5 py-4 backdrop-blur-sm transition hover:from-amber-600/50 hover:to-night-700/80 glow-border-gold"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 16px rgba(251, 191, 36, 0.3)' }}>
              <MessageCircle className="h-6 w-6 text-gold-300" />
            </div>
            <div className="flex-1 text-left">
              <p className="font-display text-base font-semibold text-gold-100">Yorumcularımıza Fal Baktır</p>
              <p className="text-xs text-gold-200/70">Falcılarımızla canlı sohbet — 99,99 TL</p>
            </div>
            <div className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-gold-300/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          </button>
        )}

        {/* Credit pack - larger */}
        <div className="mb-6">
          <div
            className="relative overflow-hidden rounded-2xl border-2 border-gold-400/50 bg-gradient-to-br from-gold-900/30 via-night-700/80 to-night-800/90 p-6 backdrop-blur-sm"
            style={{ boxShadow: '0 0 20px rgba(251, 191, 36, 0.3), 0 0 40px rgba(251, 191, 36, 0.2)' }}
          >
            <div className="pointer-events-none absolute -top-16 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full bg-gold-500/25 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-12 -right-12 h-32 w-32 rounded-full bg-gold-600/15 blur-2xl" />

            <div className="relative mb-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-14 w-14 items-center justify-center rounded-xl border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 24px rgba(251, 191, 36, 0.4)' }}>
                  <Coins className="h-7 w-7 text-gold-300" />
                </div>
                <div>
                  <h3 className="font-display text-2xl font-bold text-gold-100">{CREDIT_PACK.name}</h3>
                  <p className="text-xs text-gold-300/60">Tek seferlik paket</p>
                </div>
              </div>
              <div className="text-right">
                <span className="font-display text-3xl font-bold text-shimmer">{CREDIT_PACK.price}</span>
                <span className="ml-1 text-xs text-mystic-400">TL</span>
              </div>
            </div>

            <div className="relative mb-5 grid grid-cols-2 gap-3">
              {CREDIT_PACK.features.map((feature, i) => {
                const Icon = FEATURE_ICONS[i] || Check;
                return (
                  <div key={i} className="flex items-center gap-2 rounded-lg border border-gold-400/20 bg-night-900/40 px-3 py-2.5 text-sm text-mystic-200">
                    <Icon className="h-4 w-4 shrink-0 text-gold-300" />
                    <span className="text-xs">{feature}</span>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => handleBuy(CREDIT_PACK)}
              disabled={purchasing}
              className="group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl border border-gold-400/60 bg-gradient-to-r from-gold-600 via-gold-700 to-gold-800 px-6 py-4 font-display text-lg font-semibold text-night-900 transition hover:scale-[1.02] disabled:opacity-60"
              style={{ boxShadow: '0 0 16px rgba(251, 191, 36, 0.4), 0 0 32px rgba(251, 191, 36, 0.25)' }}
            >
              <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />
              {purchasing ? <Loader2 className="h-5 w-5 animate-spin" /> : <Sparkles className="h-5 w-5" />}
              {purchasing ? 'İşleniyor...' : 'Satın Al'}
            </button>
          </div>
        </div>

        {/* No commitment text */}
        <p className="mb-4 text-center text-sm text-mystic-300">
          Taahhüt yok - istediğin zaman iptal et
        </p>

        {purchaseError && (
          <div className="mb-4 rounded-xl border border-rose-500/30 bg-rose-900/20 px-4 py-3 text-center text-sm text-rose-300">
            {purchaseError}
          </div>
        )}

        {/* Legal links */}
        <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-xs text-mystic-500">
          <a className="flex items-center gap-1 transition hover:text-mystic-300" href="#" onClick={(e) => e.preventDefault()}>
            <Shield className="h-3.5 w-3.5" />
            Gizlilik Sözleşmesi
          </a>
          <span className="text-mystic-700">•</span>
          <a className="flex items-center gap-1 transition hover:text-mystic-300" href="#" onClick={(e) => e.preventDefault()}>
            <FileText className="h-3.5 w-3.5" />
            Kullanım Şartları
          </a>
          <span className="text-mystic-700">•</span>
          <a className="flex items-center gap-1 transition hover:text-mystic-300" href="#" onClick={(e) => e.preventDefault()}>
            <UserCheck className="h-3.5 w-3.5" />
            Kullanıcı Anlaşması
          </a>
        </div>
      </div>

      {/* Purchase confirmation modal */}
      {selectedPlan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in" onClick={handleCloseSuccess}>
          <div className="relative max-w-sm rounded-2xl border border-gold-400/40 bg-gradient-to-br from-gold-900/40 via-night-700/90 to-night-800/95 p-8 text-center animate-fade-in-up" style={{ boxShadow: '0 0 16px rgba(251, 191, 36, 0.3), 0 0 32px rgba(251, 191, 36, 0.2)' }} onClick={(e) => e.stopPropagation()}>
            <button
              onClick={handleCloseSuccess}
              className="absolute right-4 top-4 flex h-7 w-7 items-center justify-center rounded-full border border-mystic-700/40 bg-night-900/60 text-mystic-300 transition hover:text-mystic-100"
              aria-label="Kapat"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-gold-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 36px rgba(251, 191, 36, 0.5)' }}>
                <Check className="h-10 w-10 text-gold-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-gold-100">Satın Alma Başarılı</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              <span className="font-semibold text-gold-200">{selectedPlan.name}</span> paketiniz aktifleştirildi.
              Döndü Teyze Premium'un tadını çıkarın!
            </p>
            <button
              onClick={handleCloseSuccess}
              className="mt-6 w-full rounded-xl border border-gold-400/40 bg-gold-900/30 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:bg-gold-800/40"
            >
              Ana Sayfaya Dön
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default PremiumPage;
