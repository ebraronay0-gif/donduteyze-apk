import { supabase, hasSupabaseConfig } from './supabase';

const NATIVE_REDIRECT_URL = 'com.donduteyze.app://auth/callback';

function getOAuthRedirectUrl(): string {
  const isNative = typeof window !== 'undefined' &&
    (window.location.protocol === 'capacitor:' || window.location.protocol === 'ionic:' || window.location.protocol === 'file:');
  return isNative ? NATIVE_REDIRECT_URL : `${window.location.origin}/auth/callback`;
}

export async function handleOAuthCallback(url: string): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    if (!hasSupabaseConfig) return { user: null, error: 'Sunucu bağlantısı yapılandırılmamış.' };
    const parsed = new URL(url);
    const hash = new URLSearchParams(parsed.hash.replace(/^#/, ''));
    const query = parsed.searchParams;
    const accessToken = hash.get('access_token') || query.get('access_token');
    const refreshToken = hash.get('refresh_token') || query.get('refresh_token');
    if (accessToken && refreshToken) {
      const { data, error } = await supabase.auth.setSession({ access_token: accessToken, refresh_token: refreshToken });
      if (error) return { user: null, error: error.message };
      if (data.user) {
        const authUser: AuthUser = { id: data.user.id, email: data.user.email || '' };
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(authUser));
        await ensureAppUser(authUser);
        await syncCreditsFromDB(authUser);
        return { user: authUser, error: null };
      }
    }
    const code = query.get('code');
    if (code) {
      const { data, error } = await supabase.auth.exchangeCodeForSession(code);
      if (error) return { user: null, error: error.message };
      if (data.user) {
        const authUser: AuthUser = { id: data.user.id, email: data.user.email || '' };
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(authUser));
        await ensureAppUser(authUser);
        await syncCreditsFromDB(authUser);
        return { user: authUser, error: null };
      }
    }
    return { user: null, error: null };
  } catch {
    return { user: null, error: 'OAuth dönüşü işlenemedi.' };
  }
}
import { getCredits, setCredits } from './credits';

export interface AuthUser {
  id: string;
  email: string;
}

const AUTH_STORAGE_KEY = 'donduteyze_auth_user';

export function getStoredAuth(): AuthUser | null {
  try {
    const raw = localStorage.getItem(AUTH_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as AuthUser;
  } catch {
    return null;
  }
}

export function clearStoredAuth(): void {
  try {
    localStorage.removeItem(AUTH_STORAGE_KEY);
  } catch {
    // ignore
  }
}

export async function signUpWithEmail(email: string, password: string): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    if (!hasSupabaseConfig) return { user: null, error: 'Sunucu bağlantısı yapılandırılmamış.' };
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return { user: null, error: error.message };
    if (data.user) {
      const authUser: AuthUser = { id: data.user.id, email: data.user.email || email };
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(authUser));
      await ensureAppUser(authUser);
      return { user: authUser, error: null };
    }
    return { user: null, error: 'Kayıt başarısız oldu.' };
  } catch {
    return { user: null, error: 'Bağlantı hatası. Tekrar deneyin.' };
  }
}

export async function signInWithEmail(email: string, password: string): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    if (!hasSupabaseConfig) return { user: null, error: 'Sunucu bağlantısı yapılandırılmamış.' };
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { user: null, error: error.message };
    if (data.user) {
      const authUser: AuthUser = { id: data.user.id, email: data.user.email || email };
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(authUser));
      await syncCreditsFromDB(authUser);
      return { user: authUser, error: null };
    }
    return { user: null, error: 'Giriş başarısız oldu.' };
  } catch {
    return { user: null, error: 'Bağlantı hatası. Tekrar deneyin.' };
  }
}

export async function signInWithGoogle(): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    if (!hasSupabaseConfig) return { user: null, error: 'Sunucu bağlantısı yapılandırılmamış.' };
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: getOAuthRedirectUrl(), skipBrowserRedirect: false },
    });
    if (error) return { user: null, error: error.message };
    return { user: null, error: null };
  } catch {
    return { user: null, error: 'Google ile giriş başarısız.' };
  }
}

export async function signInWithApple(): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    if (!hasSupabaseConfig) return { user: null, error: 'Sunucu bağlantısı yapılandırılmamış.' };
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'apple',
      options: { redirectTo: getOAuthRedirectUrl(), skipBrowserRedirect: false },
    });
    if (error) return { user: null, error: error.message };
    return { user: null, error: null };
  } catch {
    return { user: null, error: 'Apple ile giriş başarısız.' };
  }
}

export async function signOut(): Promise<void> {
  try {
    await supabase.auth.signOut();
  } catch {
    // ignore
  }
  clearStoredAuth();
}

async function ensureAppUser(user: AuthUser): Promise<void> {
  try {
    const { data } = await supabase
      .from('app_users')
      .select('id')
      .eq('email', user.email)
      .maybeSingle();
    if (!data) {
      const localCredits = getCredits();
      await supabase.from('app_users').insert({
        email: user.email,
        credits: localCredits,
      });
    }
  } catch {
    // ignore
  }
}

async function syncCreditsFromDB(user: AuthUser): Promise<void> {
  try {
    const { data } = await supabase
      .from('app_users')
      .select('credits')
      .eq('email', user.email)
      .maybeSingle();
    if (data && typeof data.credits === 'number') {
      setCredits(data.credits);
    }
  } catch {
    // ignore
  }
}
