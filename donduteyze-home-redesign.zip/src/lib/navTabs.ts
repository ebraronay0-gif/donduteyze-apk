import type { LucideIcon } from 'lucide-react';
import { Home, Gift, History, Stars, Crown } from 'lucide-react';

export type NavTabId = 'home' | 'earn' | 'history' | 'zodiac' | 'premium';

export interface NavTab {
  id: NavTabId;
  label: string;
  icon: LucideIcon;
}

export const NAV_TABS: NavTab[] = [
  { id: 'home', label: 'DÖNDÜ TEYZE', icon: Home },
  { id: 'earn', label: 'Kredi Kazan', icon: Gift },
  { id: 'history', label: 'FALLARIM', icon: History },
  { id: 'zodiac', label: 'Burçlar', icon: Stars },
  { id: 'premium', label: 'Premium', icon: Crown },
];
