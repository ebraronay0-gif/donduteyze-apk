const CREDITS_KEY = 'fal_credits';
const INITIAL_CREDITS = 30;

export function getCredits(): number {
  try {
    const raw = localStorage.getItem(CREDITS_KEY);
    if (raw === null) {
      localStorage.setItem(CREDITS_KEY, String(INITIAL_CREDITS));
      return INITIAL_CREDITS;
    }
    const n = Number(raw);
    return isNaN(n) ? 0 : n;
  } catch {
    return 0;
  }
}

export function setCredits(amount: number): void {
  localStorage.setItem(CREDITS_KEY, String(Math.max(0, Math.floor(amount))));
}

export function addCredits(amount: number): number {
  const next = getCredits() + amount;
  setCredits(next);
  return next;
}

export function spendCredits(amount: number): { success: boolean; remaining: number } {
  const current = getCredits();
  if (current < amount) {
    return { success: false, remaining: current };
  }
  const next = current - amount;
  setCredits(next);
  return { success: true, remaining: next };
}

export const FORTUNE_COST = 15;
export const AD_REWARD = 5;
export const INITIAL_CREDIT_AMOUNT = INITIAL_CREDITS;
