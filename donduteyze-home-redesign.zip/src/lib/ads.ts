// Google AdMob configuration
// Test ad unit IDs are used by default. When ready for production,
// replace the IDs in PROD_AD_UNIT_IDS with your real AdMob ad unit IDs
// and set USE_TEST_ADS to false.

export const USE_TEST_ADS = false;

// Google official test ad unit IDs (safe for development)
export const TEST_AD_UNIT_IDS = {
  // Android test IDs
  android: {
    banner: 'ca-app-pub-3940256099942544/6300978111',
    interstitial: 'ca-app-pub-3940256099942544/1033173712',
    rewarded: 'ca-app-pub-3940256099942544/5224354917',
  },
  // iOS test IDs
  ios: {
    banner: 'ca-app-pub-3940256099942544/2934735716',
    interstitial: 'ca-app-pub-3940256099942544/4411468910',
    rewarded: 'ca-app-pub-3940256099942544/1716050653',
  },
} as const;

// Production ad unit IDs
export const PROD_AD_UNIT_IDS = {
  android: {
    banner: 'ca-app-pub-3256954236969541/5897498939',
    interstitial: 'ca-app-pub-3256954236969541/1355618695',
    rewarded: 'ca-app-pub-3256954236969541/3652122315',
  },
  ios: {
    banner: 'ca-app-pub-3256954236969541/5897498939',
    interstitial: 'ca-app-pub-3256954236969541/1355618695',
    rewarded: 'ca-app-pub-3256954236969541/3652122315',
  },
} as const;

export type AdFormat = 'banner' | 'interstitial' | 'rewarded';
export type AdPlatform = 'android' | 'ios';

function detectPlatform(): AdPlatform {
  if (typeof navigator === 'undefined') return 'android';
  const ua = navigator.userAgent.toLowerCase();
  if (/iphone|ipad|ipod/.test(ua)) return 'ios';
  return 'android';
}

export function getAdUnitId(format: AdFormat): string {
  const platform = detectPlatform();
  const ids = USE_TEST_ADS ? TEST_AD_UNIT_IDS : PROD_AD_UNIT_IDS;
  return ids[platform][format];
}

export function getAdmobAppId(): string {
  if (USE_TEST_ADS) {
    return 'ca-app-pub-3940256099942544~3347511713';
  }
  return 'ca-app-pub-3256954236969541~2502692179';
}

// --- Ad reward configuration ---

export const AD_REWARD_CREDITS = 2;
export const MAX_EARN_ADS_PER_DAY = 4;

// --- Interstitial ad frequency control ---

const INTERSTITIAL_KEY = 'donduteyze_interstitial_count';
const INTERSTITIAL_EVERY_N = 3; // Show interstitial every N fortune navigations

export function shouldShowInterstitial(): boolean {
  try {
    const count = Number(localStorage.getItem(INTERSTITIAL_KEY) || '0') + 1;
    localStorage.setItem(INTERSTITIAL_KEY, String(count));
    return count % INTERSTITIAL_EVERY_N === 0;
  } catch {
    return false;
  }
}

export function resetInterstitialCount(): void {
  try {
    localStorage.setItem(INTERSTITIAL_KEY, '0');
  } catch {
    // ignore
  }
}

// --- Earn ad tracking (daily limit) ---

const EARN_AD_KEY = 'donduteyze_earn_ads';

function todayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

interface EarnAdState {
  date: string;
  watched: boolean[];
}

function getEarnAdState(): EarnAdState {
  try {
    const raw = localStorage.getItem(EARN_AD_KEY);
    if (raw) {
      const state = JSON.parse(raw) as EarnAdState;
      if (state.date === todayKey()) return state;
    }
  } catch {
    // ignore
  }
  return { date: todayKey(), watched: [false, false, false, false] };
}

function saveEarnAdState(state: EarnAdState): void {
  try {
    localStorage.setItem(EARN_AD_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
}

export function hasWatchedEarnAdToday(slot: number): boolean {
  return getEarnAdState().watched[slot] ?? false;
}

export function markEarnAdWatched(slot: number): void {
  const state = getEarnAdState();
  if (slot >= 0 && slot < MAX_EARN_ADS_PER_DAY) {
    state.watched[slot] = true;
    saveEarnAdState(state);
  }
}

export function getEarnAdWatchedSlots(): boolean[] {
  return getEarnAdState().watched;
}

export function getEarnAdWatchedCount(): number {
  return getEarnAdState().watched.filter(Boolean).length;
}
