import { X, FileText, Shield, UserCheck } from 'lucide-react';

export type LegalType = 'user-agreement' | 'privacy' | 'terms';

interface LegalModalProps { type: LegalType | null; onClose: () => void; }

const CONTENT: Record<LegalType, { title: string; icon: typeof FileText; body: string[] }> = {
  'user-agreement': { title: 'Kullanıcı Sözleşmesi', icon: UserCheck, body: [
    'Döndü Teyze, fal ve benzeri içerikleri eğlence amacıyla sunan bir uygulamadır.',
    'Uygulamayı kullanarak hesap bilgilerinizin doğru ve size ait olduğunu kabul edersiniz.',
    'Uygulamadaki yorumlar kesin gelecek bilgisi veya profesyonel tavsiye değildir. Sağlık, hukuk ve finans gibi önemli konularda uzman görüşünün yerine geçmez.',
    'Hesabınızın güvenliğinden ve hesabınız üzerinden yapılan işlemlerden siz sorumlusunuz.',
    'Kötüye kullanım, dolandırıcılık, otomatik saldırı veya hizmeti bozacak işlemler yasaktır.'
  ]},
  privacy: { title: 'Gizlilik Anlaşması', icon: Shield, body: [
    'Hesap oluştururken verdiğiniz e-posta gibi bilgiler hesabınızı yönetmek ve hizmeti sunmak amacıyla işlenir.',
    'Fal geçmişi, destek mesajları ve uygulama kullanımına ilişkin teknik olaylar hizmetin çalışması ve iyileştirilmesi amacıyla saklanabilir.',
    'Reklam ve kullanım istatistikleri, uygulamanın performansını ve gelirlerini ölçmek için kullanılabilir.',
    'Kişisel verilerinizi üçüncü taraflara satmayız. Yasal yükümlülükler veya hizmetin çalışması için gerekli sağlayıcılar dışında paylaşım yapılmaz.',
    'Verilerinizle ilgili talep veya silme isteği için uygulamadaki destek kanalından bizimle iletişime geçebilirsiniz.'
  ]},
  terms: { title: 'Kullanım Şartları', icon: FileText, body: [
    'Döndü Teyze içerikleri yalnızca eğlence amaçlıdır ve sonuçların gerçek hayatta gerçekleşeceği garanti edilmez.',
    'Ücretli özellikler, satın alma ekranında belirtilen kapsam ve koşullara tabidir.',
    'Reklam izleme karşılığında verilen ödüller sistem kurallarına göre sınırlandırılabilir.',
    'Uygulamanın güvenliği ve sürekliliği için gerekli teknik güncellemeler yapılabilir.',
    'Hizmeti kötüye kullanan veya sistemin çalışmasını engelleyen hesapların erişimi sınırlandırılabilir.'
  ]}
};

export default function LegalModal({ type, onClose }: LegalModalProps) {
  if (!type) return null;
  const item = CONTENT[type];
  const Icon = item.icon;
  return <div className="fixed inset-0 z-[120] flex items-center justify-center bg-night-950/85 p-4 backdrop-blur-sm" onClick={onClose}>
    <div className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-gold-400/30 bg-night-800 p-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
      <div className="mb-5 flex items-center justify-between"><div className="flex items-center gap-2"><Icon className="h-5 w-5 text-gold-300" /><h2 className="font-display text-xl font-semibold text-gold-100">{item.title}</h2></div><button onClick={onClose} className="rounded-lg p-2 text-mystic-400 hover:text-mystic-100"><X className="h-5 w-5" /></button></div>
      <div className="space-y-4 text-sm leading-7 text-mystic-200">{item.body.map((p, i) => <p key={i}>{p}</p>)}</div>
      <button onClick={onClose} className="mt-6 w-full rounded-xl border border-gold-400/40 bg-gold-900/20 px-4 py-3 text-sm font-semibold text-gold-200">Kapat</button>
    </div>
  </div>;
}
