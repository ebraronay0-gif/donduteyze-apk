import { useState, useEffect, useCallback } from 'react';
import { X, Headphones, Send, MessageCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getStoredAuth } from '@/lib/auth';

interface SupportModalProps { open: boolean; onClose: () => void; }
interface ChatMessage { id: string; sender: 'user' | 'admin'; message: string; created_at: string; }

function SupportModal({ open, onClose }: SupportModalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const user = getStoredAuth();

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('support_messages').select('id,sender,message,created_at').eq('user_id', user.id).order('created_at', { ascending: true });
    if (data) setMessages(data as ChatMessage[]);
  }, [user?.id]);

  useEffect(() => {
    if (!open || !user) return;
    load();
    const channel = supabase.channel(`support:${user.id}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'support_messages', filter: `user_id=eq.${user.id}` }, load).subscribe();
    const interval = setInterval(load, 4000);
    return () => { clearInterval(interval); supabase.removeChannel(channel); };
  }, [open, user?.id, load]);

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || !user || sending) return;
    setSending(true);
    const { data, error } = await supabase.from('support_messages').insert({ user_id: user.id, user_email: user.email, sender: 'user', message: text, read: false }).select('id,sender,message,created_at').maybeSingle();
    if (!error && data) {
      setMessages((prev) => [...prev, data as ChatMessage]);
      setInput('');
    }
    setSending(false);
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-night-900/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 flex h-[70vh] w-full max-w-md flex-col overflow-hidden rounded-t-3xl border border-mystic-700/50 bg-night-800/95 shadow-2xl sm:rounded-3xl">
        <div className="flex items-center justify-between border-b border-mystic-800/50 px-4 py-3">
          <div className="flex items-center gap-2"><div className="flex h-9 w-9 items-center justify-center rounded-full border border-emerald-400/30 bg-emerald-900/20"><Headphones className="h-5 w-5 text-emerald-300" /></div><div><h3 className="font-display text-base font-semibold text-mystic-100">Canlı Destek</h3><div className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" /><span className="text-xs text-emerald-300">Çevrimiçi</span></div></div></div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-lg text-mystic-400"><X className="h-5 w-5" /></button>
        </div>
        <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
          {!user && <p className="rounded-xl border border-gold-400/20 bg-gold-900/10 p-4 text-center text-sm text-gold-200">Destek mesajı göndermek için giriş yapmalısınız.</p>}
          {user && messages.length === 0 && <div className="rounded-xl border border-mystic-700/40 bg-night-700/40 p-4 text-center text-sm text-mystic-400">Merhaba! Size nasıl yardımcı olabiliriz?</div>}
          {messages.map((msg) => <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm ${msg.sender === 'user' ? 'bg-gradient-to-br from-mystic-700 to-mystic-900 text-mystic-100' : 'border border-mystic-700/40 bg-night-700/60 text-mystic-200'}`}>{msg.sender === 'admin' && <div className="mb-1 flex items-center gap-1"><MessageCircle className="h-3 w-3 text-emerald-400" /><span className="text-[10px] font-medium text-emerald-300">Destek</span></div>}<p className="leading-relaxed">{msg.message}</p></div></div>)}
        </div>
        <form onSubmit={handleSend} className="flex items-center gap-2 border-t border-mystic-800/50 px-4 py-3">
          <input disabled={!user || sending} type="text" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Mesajınızı yazın..." className="flex-1 rounded-xl border border-mystic-700/50 bg-night-700/60 px-3.5 py-2.5 text-sm text-mystic-100 outline-none" />
          <button type="submit" disabled={!user || sending || !input.trim()} className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl border border-emerald-400/40 bg-emerald-600/20 text-emerald-300 disabled:opacity-40"><Send className="h-5 w-5" /></button>
        </form>
      </div>
    </div>
  );
}
export default SupportModal;
