import { useState, useEffect } from 'react';
import { isAdFree } from '@/lib/subscriptions';
import { getAdUnitId, USE_TEST_ADS } from '@/lib/ads';

interface BannerAdProps {
  inline?: boolean;
  size?: 'banner' | 'large';
}

function BannerAd({ inline = false, size = 'banner' }: BannerAdProps) {
  const [adUnitId] = useState(() => getAdUnitId('banner'));

  useEffect(() => {
    // In Capacitor/AdMob native context, this is where we would call:
    //   AdMob.showBanner({ adUnitId, position: 'bottom' })
    // For now, the placeholder renders the ad unit ID for verification.
  }, [adUnitId]);

  if (isAdFree()) return null;

  const heightClass = size === 'large' ? 'h-20' : 'h-14';
  const wrapperClass = inline
    ? `relative flex items-center justify-center border border-mystic-700/30 bg-night-800/95 px-3 py-1.5 rounded-xl backdrop-blur-sm`
    : `fixed bottom-16 left-0 right-0 z-30 flex items-center justify-center border-t border-mystic-700/30 bg-night-800/95 px-3 py-1.5 backdrop-blur-sm`;

  return (
    <div className={wrapperClass}>
      <div className="flex w-full max-w-md items-center gap-2">
        <span className="shrink-0 rounded bg-mystic-700/40 px-1.5 py-0.5 text-[9px] font-medium text-mystic-400">
          Reklam
        </span>
        <div className={`flex ${heightClass} flex-1 items-center justify-center rounded-lg border border-mystic-700/30 bg-gradient-to-r from-mystic-800/30 to-night-700/30`}>
          <div className="flex flex-col items-center gap-0.5">
            <span className="text-xs font-medium text-mystic-300">
              {USE_TEST_ADS ? 'AdMob Test Banner' : 'AdMob Banner'}
            </span>
            <span className="text-[9px] text-mystic-600">{adUnitId}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BannerAd;
