import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.donduteyze.app',
  appName: 'Döndü Teyze',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
    backgroundColor: '#0a0a14',
  },
};

export default config;
