#!/bin/sh
set -e
MANIFEST="android/app/src/main/AndroidManifest.xml"
if [ ! -f "$MANIFEST" ]; then exit 0; fi
python3 - <<'PY2'
from pathlib import Path
p=Path("android/app/src/main/AndroidManifest.xml")
s=p.read_text()
needle='</activity>'
if 'android.intent.action.VIEW' not in s or 'android:scheme="com.donduteyze.app"' not in s:
    block='''            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="com.donduteyze.app" android:host="auth" android:pathPrefix="/callback" />
            </intent-filter>
'''
    s=s.replace(needle, block+needle, 1)
    p.write_text(s)
PY2
