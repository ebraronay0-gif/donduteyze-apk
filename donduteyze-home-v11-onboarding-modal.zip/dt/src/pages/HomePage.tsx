import { useState } from 'react';
import { Sparkles, Stars, Heart, Briefcase, Hash, Palette, Gift, Crown, Gamepad2, Dices, Trophy, MessageCircle, History, X } from 'lucide-react';
import StarField from '@/components/StarField';
import FortuneCard from '@/components/FortuneCard';
import BannerAd from '@/components/BannerAd';
import { FORTUNE_CATEGORIES } from '@/lib/fortuneCategories';
import { getDailyHoroscope } from '@/lib/horoscope';
import type { UserProfile } from '@/lib/profile';
import type { NavTabId } from '@/lib/navTabs';

interface HomePageProps {
  profile: UserProfile;
  onNavigate: (tab: NavTabId) => void;
  onOpenCoffeeFortune: () => void;
  onOpenPalmFortune: () => void;
  onOpenTarotFortune: () => void;
  onOpenKatinaFortune: () => void;
  onOpenFaceFortune: () => void;
  onOpenDreamFortune: () => void;
  onOpenWheel: () => void;
  onOpenDice: () => void;
  onOpenLottery: () => void;
  onOpenStarFortune: () => void;
  onOpenLiveChat: () => void;
}

const EARN_GAMES = [
  { id: 'wheel', name: 'Çarkıfelek', icon: Gamepad2, glow: 'rgba(244, 63, 94, 0.3)', iconColor: 'text-rose-300' },
  { id: 'dice', name: 'Zar Oyunu', icon: Dices, glow: 'rgba(16, 185, 129, 0.3)', iconColor: 'text-emerald-300' },
  { id: 'lottery', name: 'Çekiliş', icon: Trophy, glow: 'rgba(217, 119, 6, 0.3)', iconColor: 'text-amber-300' },
];

function HomePage({
  profile,
  onNavigate,
  onOpenCoffeeFortune,
  onOpenPalmFortune,
  onOpenTarotFortune,
  onOpenKatinaFortune,
  onOpenFaceFortune,
  onOpenDreamFortune,
  onOpenWheel,
  onOpenDice,
  onOpenLottery,
  onOpenStarFortune,
  onOpenLiveChat,
}: HomePageProps) {
  const [infoModal, setInfoModal] = useState<'zodiac' | 'love' | null>(null);
  const horoscope = getDailyHoroscope(profile.zodiac);
  const today = new Date().toLocaleDateString('tr-TR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  const extraCategories = FORTUNE_CATEGORIES.filter((category) => !['kahve', 'tarot', 'ruya', 'yildiz'].includes(category.id));

  return (
    <>
      <div className="relative min-h-screen w-full overflow-hidden bg-[#09031a] pb-28">
      <StarField count={65} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,rgba(91,33,182,0.28),transparent_34%),radial-gradient(circle_at_0%_45%,rgba(76,29,149,0.18),transparent_30%),radial-gradient(circle_at_100%_65%,rgba(88,28,135,0.2),transparent_34%)]" />

      <div className="relative z-10 mx-auto w-full max-w-2xl">
        {/* Hero: deliberately matches the supplied reference image. */}
        <section className="relative w-full overflow-hidden">
          <img
            src="/home-hero-exact.png"
            alt="Döndü Teyze"
            className="block h-auto w-full object-cover"
            draggable={false}
          />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-10 bg-gradient-to-b from-transparent to-[#09031a]" />
        </section>

        {/* The six primary cards sit immediately under Döndü Teyze, just like the reference. */}
        <section className="px-3 pt-3">
          <div className="grid grid-cols-3 gap-2.5">
            <button className="reference-card" onClick={onOpenCoffeeFortune} aria-label="Kahve Falı">
              <img src="/card-kahve.png" alt="Kahve Falı" draggable={false} />
            </button>
            <button className="reference-card" onClick={onOpenTarotFortune} aria-label="Tarot Falı">
              <img src="/card-tarot.png" alt="Tarot Falı" draggable={false} />
            </button>
            <button className="reference-card" onClick={onOpenDreamFortune} aria-label="Rüya Yorumla">
              <img src="/card-ruya.png" alt="Rüya Yorumla" draggable={false} />
            </button>
            <button className="reference-card" onClick={onOpenPalmFortune} aria-label="El Falı">
              <div className="flex aspect-[1.05] items-center justify-center bg-gradient-to-br from-[#3a146d] via-[#1d0a3c] to-[#0b031d]">
                <div className="luxury-orb text-4xl">🖐️</div>
              </div>
            </button>
            <button className="reference-card" onClick={onOpenKatinaFortune} aria-label="Katina Falı">
              <div className="flex aspect-[1.05] items-center justify-center bg-gradient-to-br from-[#4a185d] via-[#210a3d] to-[#0b031d]">
                <div className="luxury-orb text-4xl">🃏</div>
              </div>
            </button>
            <button className="reference-card" onClick={onOpenFaceFortune} aria-label="Yüz Falı">
              <div className="flex aspect-[1.05] items-center justify-center bg-gradient-to-br from-[#35166a] via-[#19092f] to-[#080216]">
                <div className="luxury-orb text-4xl">🔮</div>
              </div>
            </button>
          </div>
        </section>

        <section className="mt-5 px-4">
          <div className="mb-3 flex items-end justify-between">
            <div>
              <p className="text-[10px] uppercase tracking-[0.24em] text-gold-300/70">Döndü Teyze'nin hazinesi</p>
              <h3 className="luxury-title text-xl font-semibold">Diğer Köşeler</h3>
            </div>
            <Sparkles className="h-5 w-5 text-gold-300" />
          </div>
          <div className="grid grid-cols-3 gap-2.5">
            <button onClick={onOpenStarFortune} className="reference-card luxury-mini-card">
              <img src="/card-yildiz.png" alt="Yıldız Falı" draggable={false} />
            </button>
            <button onClick={() => onNavigate('history')} className="reference-card luxury-mini-card">
              <img src="/card-fallarim.png" alt="Fallarım" draggable={false} />
            </button>
            <button onClick={() => onNavigate('earn')} className="reference-card luxury-mini-card">
              <img src="/card-gunluk.png" alt="Günlük Ödül" draggable={false} />
            </button>
          </div>
        </section>

        {/* Everything else remains below the reference-style first screen. */}
        <div className="px-4 pt-7 space-y-7">
          <div className="luxury-section p-5 backdrop-blur-sm glow-border">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="text-sm text-mystic-400">{today}</p>
                <h2 className="font-display text-2xl font-semibold text-gold-100">
                  Hoş geldin, {profile.fullName.split(' ')[0]}
                </h2>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full border border-gold-400/30 bg-night-700/60">
                <Stars className="h-6 w-6 text-gold-300" />
              </div>
            </div>

            <div className="mb-3 flex items-center gap-2">
              <button
                type="button"
                onClick={() => setInfoModal('zodiac')}
                className="rounded-full border border-mystic-500/40 bg-mystic-700/40 px-3 py-1 text-xs font-medium text-mystic-100 transition hover:border-gold-400/60 hover:bg-mystic-600/50"
              >
                {profile.zodiac}
              </button>
              <span className="text-xs text-mystic-500">Günlük Yorum</span>
            </div>
            <p className="font-serif text-base italic leading-relaxed text-mystic-100">"{horoscope.general}"</p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setInfoModal('love')}
                className="flex items-center gap-2 rounded-lg border border-mystic-700/30 bg-night-700/40 px-3 py-2 text-left transition hover:border-gold-400/40 hover:bg-night-700/60"
              >
                <Heart className="h-4 w-4 text-rose-400" />
                <div><p className="text-[10px] text-mystic-400">Aşk</p><p className="text-xs text-mystic-200 line-clamp-1">{horoscope.love}</p></div>
              </button>
              <div className="flex items-center gap-2 rounded-lg border border-mystic-700/30 bg-night-700/40 px-3 py-2">
                <Briefcase className="h-4 w-4 text-sky-400" />
                <div><p className="text-[10px] text-mystic-400">Kariyer</p><p className="text-xs text-mystic-200 line-clamp-1">{horoscope.career}</p></div>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-3">
              <div className="flex items-center gap-1.5 rounded-lg border border-gold-400/20 bg-gold-900/10 px-3 py-1.5">
                <Hash className="h-3.5 w-3.5 text-gold-400" /><span className="text-xs text-gold-200">Şanslı Sayı: {horoscope.luckyNumber}</span>
              </div>
              <div className="flex items-center gap-1.5 rounded-lg border border-gold-400/20 bg-gold-900/10 px-3 py-1.5">
                <Palette className="h-3.5 w-3.5 text-gold-400" /><span className="text-xs text-gold-200">Şanslı Renk: {horoscope.luckyColor}</span>
              </div>
            </div>
          </div>

          <div className="mb-3 flex items-center justify-between">
            <h3 className="luxury-title text-lg font-semibold">Diğer Fallar</h3>
            <span className="text-xs text-mystic-500">15 kredi / fal</span>
          </div>
          <div className="mb-8 grid grid-cols-3 gap-2.5 sm:gap-3">
            {extraCategories.map((category) => (
              <FortuneCard
                key={category.id}
                category={category}
                onClick={category.id === 'el' ? onOpenPalmFortune : category.id === 'katina' ? onOpenKatinaFortune : category.id === 'yuz' ? onOpenFaceFortune : undefined}
              />
            ))}
          </div>

          <button
            onClick={onOpenLiveChat}
            className="group relative mb-8 flex w-full items-center gap-3 overflow-hidden rounded-2xl border border-gold-400/50 bg-gradient-to-r from-amber-700/40 via-gold-800/30 to-night-800/80 px-5 py-4 backdrop-blur-sm transition hover:from-amber-600/50 hover:to-night-700/80 glow-border-gold"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 16px rgba(251, 191, 36, 0.3)' }}>
              <MessageCircle className="h-6 w-6 text-gold-300" />
            </div>
            <div className="flex-1 text-left">
              <p className="font-display text-base font-semibold text-gold-100">Yorumcularımıza Fal Baktır</p>
              <p className="text-xs text-gold-200/70">Falcılarımızla canlı sohbet — 99,99 TL</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('history')}
            className="group relative mb-8 flex w-full items-center justify-center gap-3 overflow-hidden rounded-2xl border border-gold-400/40 bg-gradient-to-r from-mystic-800/60 to-night-800/80 px-6 py-4 backdrop-blur-sm transition hover:from-mystic-700/60 hover:to-night-700/80 glow-border-gold"
          >
            <History className="h-5 w-5 text-gold-300" />
            <span className="font-display text-lg font-semibold text-gold-100">Fallarım</span>
            <span className="rounded-full bg-gold-400/20 px-2 py-0.5 text-xs text-gold-200">0</span>
          </button>

          <div className="mb-3 flex items-center gap-2">
            <Gift className="h-5 w-5 text-gold-300" />
            <h3 className="luxury-title text-lg font-semibold">Kredi Kazan</h3>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {EARN_GAMES.map((game) => {
              const Icon = game.icon;
              return (
                <button
                  key={game.id}
                  onClick={() => game.id === 'wheel' ? onOpenWheel() : game.id === 'dice' ? onOpenDice() : onOpenLottery()}
                  className="group relative aspect-square overflow-hidden rounded-2xl border border-mystic-700/40 bg-gradient-to-br from-mystic-800/40 to-night-900/80 p-3 transition hover:scale-[1.03] hover:border-gold-400/40"
                  style={{ boxShadow: `0 4px 16px ${game.glow}` }}
                >
                  <div className="relative flex h-full flex-col items-center justify-center gap-2">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-br from-white/10 to-transparent" style={{ boxShadow: `0 6px 16px ${game.glow}` }}>
                      <Icon className={`h-6 w-6 ${game.iconColor}`} strokeWidth={1.5} />
                    </div>
                    <span className="text-center text-xs font-medium text-mystic-200">{game.name}</span>
                  </div>
                </button>
              );
            })}
          </div>

          <button onClick={() => onNavigate('premium')} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl border border-gold-400/30 bg-gold-900/10 px-4 py-3 text-sm text-gold-200 transition hover:bg-gold-900/20">
            <Crown className="h-4 w-4 text-gold-300" /> Daha fazla kredi için Premium'a geç
          </button>

          <div className="mt-6">
            <BannerAd inline />
          </div>
        </div>
      </div>
    </div>

      {infoModal && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/55 px-5 backdrop-blur-sm"
          onClick={() => setInfoModal(null)}
        >
          <div
            className="relative w-full max-w-sm rounded-3xl border border-gold-400/35 bg-[#14072b]/90 p-5 shadow-2xl backdrop-blur-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              aria-label="Kapat"
              onClick={() => setInfoModal(null)}
              className="absolute left-3 top-3 flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-mystic-200 transition hover:bg-white/10"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="pt-5">
              <div className="mb-3 flex items-center gap-2">
                {infoModal === 'love' ? (
                  <Heart className="h-5 w-5 text-rose-300" />
                ) : (
                  <Stars className="h-5 w-5 text-gold-300" />
                )}
                <h3 className="font-display text-lg font-semibold text-gold-100">
                  {infoModal === 'love' ? 'Aşk' : profile.zodiac}
                </h3>
              </div>
              <p className="font-serif text-sm leading-7 text-mystic-100">
                {infoModal === 'love' ? horoscope.love : horoscope.general}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default HomePage;
