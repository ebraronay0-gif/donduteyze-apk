import { Headphones, Home, Gift, History, Stars, Crown } from 'lucide-react';
import { NAV_TABS, type NavTabId } from '@/lib/navTabs';

const ICONS = { home: Home, earn: Gift, history: History, zodiac: Stars, premium: Crown } as const;

interface BottomNavBarProps {
  activeTab: NavTabId;
  onTabChange: (tab: NavTabId) => void;
  onSupportClick: () => void;
}

function BottomNavBar({ activeTab, onTabChange, onSupportClick }: BottomNavBarProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 pointer-events-none">
      {/* Top fade */}
      <div className="pointer-events-none absolute -top-8 left-0 right-0 h-8 bg-gradient-to-t from-night-900/80 to-transparent" />

      <div className="mx-auto max-w-md px-3 pb-3 pointer-events-auto">
        <div className="relative flex items-stretch justify-between rounded-2xl border border-mystic-700/40 bg-night-800/90 p-1.5 backdrop-blur-xl glow-border">
          {NAV_TABS.map((tab) => {
            const Icon = ICONS[tab.id] ?? tab.icon;
            const isActive = activeTab === tab.id;
            const isCenter = tab.id === 'history';

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`group relative flex flex-1 flex-col items-center justify-center gap-1 rounded-2xl py-2.5 transition-all duration-300 ${isCenter ? 'nav-center-item' : ''}`}
              >
                {/* Active glow */}
                {isActive && (
                  <div
                    className={`absolute inset-0 rounded-xl bg-gradient-to-b from-mystic-600/30 to-mystic-900/20 ${
                      isCenter ? 'ring-2 ring-gold-400/40' : ''
                    }`}
                  />
                )}

                {/* Icon */}
                <div
                  className={`relative flex h-10 w-10 items-center justify-center rounded-2xl border transition-all duration-300 ${isActive ? 'border-gold-300/40 bg-gradient-to-b from-gold-300/20 via-purple-500/20 to-purple-950/30' : 'border-white/5 bg-gradient-to-b from-white/8 to-purple-950/20'} ${
                    isActive
                      ? 'scale-110 text-gold-300'
                      : 'text-mystic-400 group-hover:text-mystic-200'
                  }`}
                  style={{
                    boxShadow: isActive
                      ? '0 4px 12px rgba(251, 191, 36, 0.25), inset 0 1px 1px rgba(255,255,255,0.1)'
                      : 'none',
                  }}
                >
                  <Icon className="relative z-10 h-5 w-5 drop-shadow-[0_3px_6px_rgba(0,0,0,0.5)]" strokeWidth={1.8} />
                </div>

                {/* Label */}
                <span
                  className={`relative text-[10px] font-medium leading-tight transition-colors ${
                    isActive ? 'text-gold-200' : 'text-mystic-400 group-hover:text-mystic-200'
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}

          {/* Live Support button */}
          <button
            onClick={onSupportClick}
            className={`group relative flex flex-1 flex-col items-center justify-center gap-1 rounded-2xl py-2.5 transition-all duration-300 ${isCenter ? 'nav-center-item' : ''}`}
          >
            <div className="relative flex h-10 w-10 items-center justify-center rounded-2xl border border-emerald-300/10 bg-gradient-to-b from-white/5 to-emerald-950/20 text-mystic-400 transition-all duration-300 group-hover:scale-110 group-hover:text-emerald-300">
              <div className="absolute inset-0 rounded-xl bg-emerald-500/0 transition-all duration-300 group-hover:bg-emerald-500/10" />
              <Headphones className="relative z-10 h-5 w-5 drop-shadow-[0_3px_6px_rgba(0,0,0,0.5)]" strokeWidth={1.8} />
              {/* Pulse ring */}
              <span className="absolute inset-0 rounded-xl ring-1 ring-emerald-400/0 transition-all duration-300 group-hover:ring-emerald-400/40" />
            </div>
            <span className="relative text-[10px] font-medium leading-tight text-mystic-400 transition-colors group-hover:text-emerald-300">
              Destek
            </span>
          </button>
        </div>
      </div>
    </nav>
  );
}

export default BottomNavBar;
