import { useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { ArrowLeft, Droplets, RotateCw, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import { submitFortune } from '@/lib/fortuneApi';
import { getCredits, FORTUNE_COST } from '@/lib/credits';
import type { NavTabId } from '@/lib/navTabs';

interface Props { onNavigate: (tab: NavTabId) => void; }

function WaterFortunePage({ onNavigate }: Props) {
  const [mix, setMix] = useState(0);
  const [strokes, setStrokes] = useState(0);
  const [showAd, setShowAd] = useState(false);
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const lastPoint = useRef<{ x: number; y: number } | null>(null);
  const ready = strokes >= 8;
  const swirl = useMemo(() => mix % 360, [mix]);

  const stirStart = (e: ReactPointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    lastPoint.current = { x: e.clientX, y: e.clientY };
  };
  const stirMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!lastPoint.current) return;
    const dx = e.clientX - lastPoint.current.x;
    const dy = e.clientY - lastPoint.current.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    if (distance < 4) return;
    lastPoint.current = { x: e.clientX, y: e.clientY };
    setMix(v => v + distance * 2.8);
    setStrokes(v => Math.min(20, v + 1));
  };
  const stirEnd = () => { lastPoint.current = null; };

  const handleSubmit = () => {
    if (!ready || busy) return;
    if (getCredits() < FORTUNE_COST) { setError(`Su Falı için ${FORTUNE_COST} kredi gerekiyor.`); return; }
    setError('');
    setShowAd(true);
  };

  const handleAdComplete = async () => {
    setShowAd(false);
    setBusy(true);
    setError('');
    const result = await submitFortune({
      fortuneType: 'water',
      userInput: `Kullanıcı suyu parmağıyla ${strokes} hareketle karıştırdı. Su girdabı açısı ${Math.round(swirl)} derece. Su Falı yorumunu bu görsel ritüelin sembolik izlerine göre yap.`,
    });
    setBusy(false);
    if (!result.success) { setError(result.error || 'Su falın gönderilemedi.'); return; }
    setSuccess(true);
    setTimeout(() => onNavigate('history'), 2600);
  };

  return <div className="relative min-h-screen overflow-hidden bg-[#08021a] pb-28">
    <StarField count={80}/>
    <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,rgba(59,130,246,.24),transparent_32%),radial-gradient(circle_at_10%_70%,rgba(124,58,237,.18),transparent_35%)]"/>
    <div className="relative z-10 mx-auto max-w-2xl px-4 py-5">
      <button onClick={()=>onNavigate('home')} className="mb-5 flex items-center gap-2 rounded-full border border-gold-400/30 bg-night-800/70 px-4 py-2 text-sm text-gold-100"><ArrowLeft className="h-4 w-4"/> Geri</button>
      <section className="relative overflow-hidden rounded-[30px] border border-cyan-300/25 bg-gradient-to-b from-[#18104b] via-[#0d0a2d] to-[#08021a] p-5 shadow-[0_0_45px_rgba(59,130,246,.18)]">
        <div className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-cyan-400/10 blur-3xl"/>
        <div className="text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl border border-cyan-300/30 bg-cyan-400/10 shadow-[0_10px_28px_rgba(34,211,238,.2)]"><Droplets className="h-7 w-7 text-cyan-200"/></div>
          <p className="text-[10px] uppercase tracking-[.3em] text-cyan-200/70">Döndü Teyze'nin yeni ritüeli</p>
          <h1 className="mt-1 font-display text-3xl font-bold text-shimmer">SU FALI</h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-mystic-300">Suyun yüzeyindeki hareketleri sezgisel bir hikâyeye dönüştürelim.</p>
        </div>
        <div className="relative mx-auto mt-6 max-w-sm">
          <div className="pointer-events-none absolute inset-x-8 -bottom-3 h-16 rounded-full bg-cyan-400/20 blur-2xl"/>
          <div
            className="relative aspect-square touch-none select-none overflow-hidden rounded-[50%] border-[10px] border-[#7a4a20] bg-gradient-to-br from-[#4c2c1d] via-[#9a5f2c] to-[#2a1631] p-5 shadow-[0_25px_55px_rgba(0,0,0,.55),inset_0_5px_8px_rgba(255,255,255,.18)]"
            onPointerDown={stirStart} onPointerMove={stirMove} onPointerUp={stirEnd} onPointerCancel={stirEnd}
          >
            <div className="relative h-full w-full overflow-hidden rounded-full border-4 border-[#d6a65b]/60 bg-[#06153c] shadow-[inset_0_0_45px_rgba(56,189,248,.35)]">
              <div className="absolute inset-0 transition-transform duration-200" style={{ transform:`rotate(${swirl}deg)`, background:'conic-gradient(from 10deg, rgba(186,230,253,.85), rgba(37,99,235,.9), rgba(124,58,237,.7), rgba(34,211,238,.9), rgba(30,64,175,.9), rgba(186,230,253,.85))', filter:'blur(1px)' }}/>
              <div className="absolute inset-[10%] rounded-full border border-white/25 opacity-70" style={{ transform:`rotate(${-swirl*1.6}deg) scale(${1 + Math.min(strokes,10)*.01})` }}/>
              <div className="absolute inset-[22%] rounded-full border border-cyan-100/30 opacity-60" style={{ transform:`rotate(${swirl*2.2}deg)` }}/>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_35%_25%,rgba(255,255,255,.4),transparent_15%),radial-gradient(circle_at_70%_70%,rgba(124,58,237,.25),transparent_35%)]"/>
              {!ready && <div className="absolute inset-0 flex items-center justify-center p-8 text-center"><div className="rounded-3xl border border-gold-300/30 bg-black/35 px-5 py-4 backdrop-blur"><RotateCw className="mx-auto mb-2 h-7 w-7 animate-pulse text-gold-200"/><p className="font-display text-base text-gold-100">Lütfen suyu parmağınla karıştır...</p><p className="mt-1 text-[10px] text-mystic-300">Dairesel hareketlerle suyu uyandır</p></div></div>}
            </div>
          </div>
        </div>
        <div className="mt-5 flex items-center justify-between rounded-2xl border border-cyan-300/15 bg-cyan-950/20 px-4 py-3"><span className="text-xs text-mystic-300">Su hareketi</span><span className="font-display text-sm text-cyan-100">{Math.min(strokes,8)}/8</span></div>
        <button onClick={handleSubmit} disabled={!ready || busy} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-gold-300/50 bg-gradient-to-r from-violet-700 via-purple-600 to-indigo-700 px-5 py-4 font-display text-lg font-semibold text-gold-100 shadow-[0_0_28px_rgba(124,58,237,.3)] disabled:cursor-not-allowed disabled:opacity-45"><Sparkles className="h-5 w-5"/>{busy?'Yapay zekâ yorumluyor...':`Su Falıma Bak · ${FORTUNE_COST} Kredi`}</button>
        {error && <div className="mt-3 flex items-center gap-2 rounded-xl border border-rose-400/30 bg-rose-950/30 px-3 py-2 text-xs text-rose-200"><AlertCircle className="h-4 w-4"/>{error}</div>}
      </section>
      <p className="mx-auto mt-4 max-w-md text-center text-[9px] text-mystic-600">Su Falı yalnızca eğlence amaçlıdır.</p>
    </div>
    <RewardedAdModal open={showAd} onComplete={handleAdComplete} onClose={()=>setShowAd(false)} rewardLabel="Su Falı Yorumu"/>
    {success && <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/75 px-6 backdrop-blur-sm"><div className="w-full max-w-sm rounded-[28px] border border-cyan-300/30 bg-[#12082a] p-7 text-center"><CheckCircle2 className="mx-auto h-14 w-14 text-cyan-200"/><h2 className="mt-4 font-display text-xl text-gold-100">Su Falın Hazır ✨</h2><p className="mt-2 text-sm text-mystic-300">Yapay zekâ yorumun Fallarım'a kaydedildi.</p></div></div>}
  </div>;
}
export default WaterFortunePage;
