import { X, FileText, Shield, UserCheck } from 'lucide-react';

export type LegalType = 'user-agreement' | 'privacy' | 'terms';

interface LegalModalProps { type: LegalType | null; onClose: () => void; }

const VERSION = '23.08.2026-v2';
const CONTROLLER = 'Ebrar Onay';
const EMAIL = 'ebrar' + 'onay0@outlook.com';

const CONTENT: Record<LegalType, { title: string; icon: typeof FileText; intro: string; body: string[] }> = {
  'user-agreement': { title: 'Kullanıcı Sözleşmesi', icon: UserCheck, intro: `Sürüm: ${VERSION}. Bu metin Döndü Teyze uygulamasının hesap oluşturma ve hizmet kullanım esaslarını düzenler.`, body: [
    `Sözleşmenin tarafları: ${CONTROLLER} ("İşletmeci") ve uygulamayı kullanan kişi ("Kullanıcı"). İşletmecinin iletişim bilgileri: ${EMAIL}.`,
    'Döndü Teyze; kahve, tarot, yıldız, rüya, el, yüz, katina, su, melek kartları ve benzeri fal/yorum içeriklerini eğlence amacıyla sunar. Hiçbir fal sonucu bilimsel, kesin veya geleceği garanti eden bir öngörü değildir.',
    'Kullanıcı; hesap bilgilerinin doğru olduğunu, hesabını başkasına kullandırmayacağını ve uygulamayı hukuka, genel ahlaka ve üçüncü kişilerin haklarına aykırı amaçlarla kullanmayacağını kabul eder.',
    'Uygulamadaki yapay zekâ tarafından oluşturulan yorumlar otomatik içeriktir; bunlar sağlık, hukuk, finans, yatırım, psikoloji, güvenlik veya başka bir profesyonel danışmanlığın yerine geçmez. Önemli kararlar yalnızca fal sonucuna dayanılarak verilmemelidir.',
    'Kullanıcı tarafından yüklenen fotoğraflar, metinler ve diğer içeriklerin gerekli kullanım haklarına sahip olunması Kullanıcının sorumluluğundadır. Başkasına ait özel veya hukuka aykırı içerikler yüklenmemelidir.',
    'Kullanıcı hesabının güvenliğinden ve hesabı üzerinden yapılan işlemlerden sorumludur. Şüpheli erişim durumunda İşletmeciye derhal bildirim yapılmalıdır.',
    'Kredi, reklam ödülü, abonelik ve ücretli fal hakları yalnızca uygulamada tanımlanan kullanım amaçları içindir; nakde çevrilemez ve devredilemez. Hile, otomasyon veya sistem açıklarını kötüye kullanarak kredi/ödül elde etmek yasaktır.',
    'İşletmeci; güvenlik, mevzuat, teknik zorunluluk veya hizmetin geliştirilmesi nedeniyle özellikleri güncelleme, geçici olarak durdurma veya kaldırma hakkını saklı tutar. Kullanıcı haklarını etkileyen önemli değişiklikler uygun şekilde duyurulur.',
    'Hizmetin Kullanıcı tarafından kötüye kullanılması, sahte hesap, dolandırıcılık, yetkisiz erişim, tersine mühendislik veya hizmetin çalışmasını bozma girişimi halinde erişim sınırlandırılabilir.',
    'Bu sözleşme tüketicinin emredici yasal haklarını ortadan kaldırmaz. Uyuşmazlıklarda yürürlükteki Türk hukuku ve görevli/yetkili merciler uygulanır.',
  ]},
  privacy: { title: 'Gizlilik ve KVKK Aydınlatma Metni', icon: Shield, intro: `Sürüm: ${VERSION}. Bu metin 6698 sayılı KVKK kapsamındaki aydınlatma yükümlülüğü için hazırlanmıştır.`, body: [
    `Veri Sorumlusu: ${CONTROLLER}. İletişim: ${EMAIL}.`,
    'İşlenebilecek veriler; ad-soyad, yaş, burç, medeni hal, e-posta, hesap/üyelik bilgileri, satın alma ve abonelik kayıtları, kredi hareketleri, fal geçmişi, kullanıcının yüklediği fal fotoğrafları, destek/mesaj içerikleri ve hizmetin çalışması için oluşan teknik/log verileri olabilir. Hangi verilerin gerçekten toplandığı uygulamanın teknik yapısıyla birebir uyumlu tutulmalıdır.',
    'İşleme amaçları; hesap oluşturma ve yönetimi, fal hizmetlerinin sunulması, yüklenen görsellerin yapay zekâ ile analiz edilmesi, fal sonuçlarının Fallarım alanında gösterilmesi, müşteri desteği, satın alma/abonelik işlemleri, güvenlik ve kötüye kullanımın önlenmesi, yasal yükümlülüklerin yerine getirilmesi ve hizmetin geliştirilmesidir.',
    'Kişisel veriler; ilgili işleme amacıyla sınırlı olmak üzere uygulamanın teknik altyapı sağlayıcılarına, yapay zekâ/görsel analiz hizmet sağlayıcılarına, ödeme ve uygulama mağazası sağlayıcılarına, reklam/ölçüm sağlayıcılarına ve yetkili kamu kurumlarına aktarılabilir. Gerçek sağlayıcı listesi ve yurt dışı aktarım durumları yayın öncesinde teknik sözleşmelere göre kesinleştirilmelidir.',
    'Veriler; KVKK m.5 ve uygulanabilir diğer hukuki sebeplere dayanılarak, işleme amacı ve ilgili faaliyet bakımından gerekli olduğu ölçüde işlenir. Açık rıza gereken faaliyetlerde açık rıza ayrıca alınır. Aydınlatma metninin okunması tek başına açık rıza anlamına gelmez.',
    'Yüklenen fal fotoğrafları ve fal sonuçları, hizmetin sunulması için gerekli süre boyunca ve yasal saklama yükümlülükleri dikkate alınarak saklanır. Kesin saklama süreleri veri envanteri ve teknik mimariye göre belirlenmelidir.',
    'İlgili kişi; KVKK m.11 kapsamındaki hakları için Veri Sorumlusuna başvurabilir. Başvuru yöntemi ve güncel iletişim bilgileri yukarıdaki iletişim kanalı üzerinden duyurulacaktır.',
    'Aydınlatma yükümlülüğü ile açık rıza süreçleri birbirinden ayrı tutulur. Reklam/pazarlama gibi ayrıca rıza gerektiren işlemler hizmetin zorunlu şartı haline getirilemez.',
  ]},
  terms: { title: 'Kullanım Şartları', icon: FileText, intro: `Sürüm: ${VERSION}. Uygulamanın kullanım, reklam, kredi, fal ve ücretli hizmet kurallarını belirler.`, body: [
    'Döndü Teyze tamamen eğlence amaçlı bir fal ve içerik uygulamasıdır. Fal sonuçları gerçek, kesin veya garanti edilmiş gelecek bilgisi değildir.',
    'Kahve, el, yüz ve benzeri fotoğraf analizlerinde kullanıcı yalnızca kendisine ait veya kullanımına izin verilen görselleri yüklemelidir. Fotoğraflarda gereksiz kişisel veri veya üçüncü kişilere ait özel bilgiler bulunmaması önerilir.',
    'Yapay zekâ yorumları otomatik olarak üretilebilir. Sonuçların doğruluğu, eksiksizliği veya belirli bir olayın gerçekleşeceği garanti edilmez.',
    'Reklam karşılığı verilen kredi ve günlük ödüller, teknik olarak reklamın başarıyla tamamlanmasına ve uygulamada belirtilen günlük sınırlara tabidir. Reklam sağlayıcısının reklam sunamadığı durumlarda ödül verilemeyebilir; kullanıcı tekrar deneme seçeneğini kullanabilir.',
    'Krediler uygulama içi kullanım birimidir; para değildir, nakde çevrilemez ve kullanıcılar arasında devredilemez. Kredi fiyatları ve paket kapsamları satın alma ekranında açıkça gösterilir.',
    'Aboneliklerde ücret, dönem, yenileme, iptal ve ödeme koşulları satın alma ekranında ve kullanılan ödeme/uygulama mağazası altyapısında ayrıca gösterilir. Otomatik yenileme özelliği ancak kullanılan ödeme altyapısı tarafından gerçekten destekleniyorsa uygulanır; kullanıcıya yenileme öncesi gerekli bilgilendirmeler sağlanır.',
    'Dijital hizmet ve içerik satın alımlarında tüketicinin emredici mevzuattan doğan hakları saklıdır. Cayma hakkı, istisnalar ve anında ifaya ilişkin koşullar uygulanabilir mevzuat ve kullanılan satış kanalına göre değerlendirilir.',
    'İşletmeci; teknik bakım, güvenlik, mevzuat değişikliği veya hizmet sağlayıcı değişikliği nedeniyle uygulamada değişiklik yapabilir. Tüketicinin satın aldığı hizmetin esaslı özelliklerini etkileyen değişikliklerde yürürlükteki tüketici hukuku hükümleri saklıdır.',
    'Kullanıcı; sahtecilik, bot/otomasyon, reklam manipülasyonu, kredi/ödül istismarı, yetkisiz erişim, tersine mühendislik ve diğer kötüye kullanım yöntemlerinden kaçınmalıdır.',
    'Bu şartlar tüketicinin kanundan doğan emredici haklarını sınırlamaz. Uygulanacak hukuk Türkiye Cumhuriyeti hukukudur.',
  ]}
};

export default function LegalModal({ type, onClose }: LegalModalProps) {
  if (!type) return null;
  const item = CONTENT[type];
  const Icon = item.icon;
  return <div className="fixed inset-0 z-[120] flex items-center justify-center bg-night-950/90 p-4 backdrop-blur-sm" onClick={onClose}>
    <div className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-gold-400/30 bg-night-800 p-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
      <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><Icon className="h-5 w-5 text-gold-300" /><h2 className="font-display text-xl font-semibold text-gold-100">{item.title}</h2></div><button onClick={onClose} className="rounded-lg p-2 text-mystic-400 hover:text-mystic-100"><X className="h-5 w-5" /></button></div>
      <div className="mb-4 rounded-xl border border-amber-400/20 bg-amber-950/20 p-3 text-xs leading-5 text-amber-100/80">Bu metin uygulamanın mevcut işleyişine göre hazırlanmıştır; yayın öncesinde hukuki uzman tarafından son kontrol edilmesi önerilir.</div>
      <p className="mb-4 text-sm leading-6 text-gold-100/90">{item.intro}</p>
      <div className="space-y-4 text-sm leading-7 text-mystic-200">{item.body.map((p, i) => <p key={i}>{p}</p>)}</div>
      <button onClick={onClose} className="mt-6 w-full rounded-xl border border-gold-400/40 bg-gold-900/20 px-4 py-3 text-sm font-semibold text-gold-200">Kapat</button>
    </div>
  </div>;
}
