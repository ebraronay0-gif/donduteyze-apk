import { registerPlugin } from '@capacitor/core';
import { supabase } from './supabase';

interface PushNotificationsPlugin {
  requestPermissions(): Promise<{ receive: 'prompt' | 'prompt-with-rationale' | 'granted' | 'denied' }>;
  register(): Promise<void>;
  addListener(eventName: 'registration', listenerFunc: (token: { value: string }) => void): Promise<{ remove: () => Promise<void> }>;
  addListener(eventName: 'registrationError', listenerFunc: (error: unknown) => void): Promise<{ remove: () => Promise<void> }>;
  addListener(eventName: 'pushNotificationReceived', listenerFunc: (notification: { title?: string; body?: string; data?: Record<string, unknown> }) => void): Promise<{ remove: () => Promise<void> }>;
}

const PushNotifications = registerPlugin<PushNotificationsPlugin>('PushNotifications');

export async function registerAdminPush(adminId: string): Promise<void> {
  try {
    const permission = await PushNotifications.requestPermissions();
    if (permission.receive !== 'granted') return;
    await PushNotifications.addListener('registration', async ({ value }) => {
      await supabase.from('push_tokens').upsert({ owner_id: adminId, role: 'admin', token: value, platform: 'native' }, { onConflict: 'token' });
    });
    await PushNotifications.addListener('registrationError', (error) => console.error('Push registration error', error));
    await PushNotifications.register();
  } catch (error) {
    console.warn('Native push notifications unavailable', error);
  }
}
