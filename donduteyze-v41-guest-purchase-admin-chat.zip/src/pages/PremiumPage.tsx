import { useState } from 'react';
import { Crown, Check, Sparkles, Coins, Star, Gift, X, Loader2, Ban } from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import { purchasePlan, type PlanId } from '@/lib/subscriptions';
import { supabase } from '@/lib/supabase';
import type { AuthUser } from '@/lib/auth';
import LegalAcceptance from '@/components/LegalAcceptance';

interface PremiumPageProps {
  onNavigate: (tab: NavTabId) => void;
  onRequireAuth?: () => void;
  isLoggedIn?: boolean;
  onOpenLiveChat?: () => void;
  authUser?: AuthUser | null;
}

interface Offer {
  id: PlanId;
  title: string;
  price: string;
  suffix: string;
  badge?: string;
  features: string[];
  note?: string;
  featured?: boolean;
  button: string;
}

const SUBSCRIPTIONS: Offer[] = [
  {
    id: 'weekly',
    title: 'HAFTALIK ÜYELİK',
    price: '59,99 TL',
    suffix: '/ hafta',
    features: ['Reklamsız uygulama', 'Her gün 20 kredi', 'Öncelikli fal hakkı'],
    note: '1 hafta boyunca tüm ayrıcalıklar. Abonelik otomatik yenilenir.',
    button: 'HEMEN ÜYE OL',
  },
  {
    id: 'monthly',
    title: 'AYLIK ÜYELİK',
    price: '99,99 TL',
    suffix: '/ ay',
    badge: 'EN POPÜLER',
    features: ['Reklamsız uygulama', 'Her gün 20 kredi', 'Öncelikli fal hakkı'],
    note: '1 ay boyunca tüm ayrıcalıklar. Abonelik otomatik yenilenir.',
    button: 'HEMEN ÜYE OL',
  },
  {
    id: 'yearly',
    title: 'YILLIK ÜYELİK',
    price: '499,99 TL',
    suffix: '/ yıl',
    badge: 'EN AVANTAJLI',
    features: ['Reklamsız uygulama', 'Her gün 20 kredi', 'Öncelikli fal hakkı', 'Falcılarımıza 1 defa ücretsiz fal'],
    note: '1 defalık ücretsiz fal hakkı 72 kredi düşmeden kullanılır. Abonelik yıllık yenilenir.',
    featured: true,
    button: 'HEMEN ÜYE OL',
  },
];

const CREDIT_PACKS: Offer[] = [
  {
    id: 'credits500',
    title: '500 KREDİ',
    price: '599,99 TL',
    suffix: 'tek seferlik',
    badge: 'EN AVANTAJLI',
    features: ['500 kredi anında yüklenir', '1 ay reklamsız deneyim'],
    featured: true,
    button: 'SATIN AL',
  },
  {
    id: 'credits200',
    title: '200 KREDİ',
    price: '299,99 TL',
    suffix: 'tek seferlik',
    features: ['200 kredi anında yüklenir', '15 gün reklamsız deneyim'],
    button: 'SATIN AL',
  },
  {
    id: 'credits72',
    title: '72 KREDİ',
    price: '99,99 TL',
    suffix: 'tek seferlik',
    features: ['72 kredi anında yüklenir', '1 hafta reklamsız deneyim'],
    button: 'SATIN AL',
  },
];

function PremiumPage({ onNavigate, onRequireAuth, isLoggedIn, authUser }: PremiumPageProps) {
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);
  const [purchasing, setPurchasing] = useState(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);
  const [legalAccepted, setLegalAccepted] = useState(false);

  const handleBuy = async (offer: Offer) => {
    if (!legalAccepted) {
      setPurchaseError('Satın alma işlemine devam etmek için yasal metinleri okuyup gerekli kutucukları işaretleyin.');
      return;
    }
    setPurchasing(true);
    setPurchaseError(null);
    let buyer = authUser;
    if (!buyer) {
      const { data: sessionData } = await supabase.auth.getSession();
      if (sessionData.session?.user) {
        buyer = { id: sessionData.session.user.id, email: sessionData.session.user.email || `guest-${sessionData.session.user.id}@guest.donduteyze.app` };
      } else {
        const { data: anon, error: anonError } = await supabase.auth.signInAnonymously();
        if (anonError || !anon.user) {
          setPurchasing(false);
          setPurchaseError('Satın alma için güvenli bir geçici hesap oluşturulamadı. Lütfen tekrar deneyin.');
          return;
        }
        buyer = { id: anon.user.id, email: `guest-${anon.user.id}@guest.donduteyze.app` };
      }
    }
    const result = await purchasePlan(offer.id, buyer);
    setPurchasing(false);
    if (result.success) setSelectedOffer(offer);
    else setPurchaseError(result.error || 'Satın alma başarısız oldu.');
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-[#07030f] pb-28 text-white">
      <StarField count={70} />
      <div className="pointer-events-none absolute -top-32 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-purple-700/20 blur-3xl" />
      <div className="pointer-events-none absolute top-[38%] -left-32 h-80 w-80 rounded-full bg-fuchsia-700/10 blur-3xl" />
      <div className="pointer-events-none absolute top-[68%] -right-32 h-80 w-80 rounded-full bg-amber-500/10 blur-3xl" />

      <div className="relative z-10 mx-auto max-w-3xl px-3 pb-8 pt-4 sm:px-5">
        <section className="relative overflow-hidden rounded-[30px] border border-amber-400/35 bg-gradient-to-b from-[#180526] via-[#10041d] to-[#08030f] shadow-[0_0_45px_rgba(168,85,247,.18)]">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(168,85,247,.2),transparent_42%)]" />
          <div className="relative px-4 pb-5 pt-4 text-center sm:px-7">
            <div className="mx-auto mb-2 flex w-fit items-center gap-2 rounded-full border border-amber-400/30 bg-black/20 px-4 py-1.5 text-xs tracking-[.28em] text-amber-200">
              <Crown className="h-4 w-4" /> ÖZEL AYRICALIKLAR
            </div>
            <h1 className="font-display text-4xl font-bold tracking-[.16em] text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-yellow-400 to-amber-600">PREMIUM</h1>
            <p className="mt-1 text-lg font-semibold text-fuchsia-300">Daha Fazlası Seninle!</p>
            <p className="mx-auto mt-2 max-w-xl text-sm leading-relaxed text-purple-100/80">Reklamsız, ayrıcalıklı ve kesintisiz bir fal deneyimi seni bekliyor.</p>

            <div className="relative mx-auto mt-4 max-w-xl overflow-hidden rounded-3xl border border-amber-400/30 bg-black/25">
              <img src="/dondu-teyze-hero.png" alt="Döndü Teyze Premium" className="h-48 w-full object-cover object-center sm:h-56" />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#10041d] to-transparent" />
            </div>
          </div>

          <div className="relative px-3 pb-5 sm:px-5">
            <div className="mb-4">
              <LegalAcceptance onValidityChange={setLegalAccepted} />
            </div>

            <SectionTitle title="PREMIUM ÜYELİKLER" />
            <div className="grid gap-4 md:grid-cols-3">
              {SUBSCRIPTIONS.map((offer) => (
                <OfferCard key={offer.id} offer={offer} onBuy={handleBuy} purchasing={purchasing} subscription />
              ))}
            </div>

            <SectionTitle title="KREDİ PAKETLERİ" />
            <div className="grid gap-4 md:grid-cols-3">
              {CREDIT_PACKS.map((offer) => (
                <OfferCard key={offer.id} offer={offer} onBuy={handleBuy} purchasing={purchasing} />
              ))}
            </div>

            <div className="mt-5 rounded-2xl border border-amber-400/30 bg-gradient-to-r from-purple-950/80 via-[#18062b] to-purple-950/80 p-4 shadow-[0_0_25px_rgba(168,85,247,.12)]">
              <div className="mb-3 flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-amber-400/40 bg-amber-500/10"><Crown className="h-6 w-6 text-amber-300" /></div>
                <div><p className="font-display text-base font-bold text-amber-100">Premium Ayrıcalıkları</p><p className="text-xs text-purple-200/65">Tüm premium deneyim tek yerde</p></div>
              </div>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Benefit icon={Ban} text="Reklamsız" />
                <Benefit icon={Coins} text="Her gün 20 kredi" />
                <Benefit icon={Star} text="Öncelikli fal" />
                <Benefit icon={Gift} text="Özel fırsatlar" />
              </div>
            </div>

            {purchaseError && <div className="mt-4 rounded-xl border border-red-500/30 bg-red-950/40 px-4 py-3 text-center text-sm text-red-200">{purchaseError}</div>}

          </div>
        </section>
      </div>

      {selectedOffer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-5 backdrop-blur-md" onClick={() => setSelectedOffer(null)}>
          <div className="relative w-full max-w-sm overflow-hidden rounded-3xl border border-amber-400/50 bg-gradient-to-b from-[#21082f] to-[#09030f] p-7 text-center shadow-[0_0_55px_rgba(245,158,11,.2)]" onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setSelectedOffer(null)} className="absolute right-4 top-4 rounded-full border border-purple-400/30 p-2 text-purple-200"><X className="h-4 w-4" /></button>
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full border border-amber-400/50 bg-amber-500/10 shadow-[0_0_35px_rgba(245,158,11,.35)]"><Check className="h-10 w-10 text-amber-300" /></div>
            <h2 className="mt-5 font-display text-2xl font-bold text-amber-100">Satın Alma Başarılı</h2>
            <p className="mt-2 text-sm leading-relaxed text-purple-100/80"><strong className="text-amber-200">{selectedOffer.title}</strong> paketiniz aktifleştirildi.</p>
            <button onClick={() => { setSelectedOffer(null); onNavigate('home'); }} className="mt-6 w-full rounded-xl border border-amber-400/50 bg-gradient-to-r from-purple-700 to-fuchsia-700 px-4 py-3 font-display font-semibold text-amber-50">Ana Sayfaya Dön</button>
          </div>
        </div>
      )}
    </div>
  );
}

function SectionTitle({ title }: { title: string }) {
  return <div className="my-5 flex items-center gap-3"><div className="h-px flex-1 bg-gradient-to-r from-transparent to-amber-400/45" /><h2 className="shrink-0 font-display text-base font-bold tracking-[.12em] text-amber-200">{title}</h2><div className="h-px flex-1 bg-gradient-to-l from-transparent to-amber-400/45" /></div>;
}

function Benefit({ icon: Icon, text }: { icon: typeof Ban; text: string }) {
  return <div className="flex min-h-16 flex-col items-center justify-center rounded-xl border border-amber-400/15 bg-black/20 p-2 text-center"><Icon className="mb-1 h-5 w-5 text-amber-300" /><span className="text-[11px] text-purple-100/80">{text}</span></div>;
}

function OfferCard({ offer, onBuy, purchasing, subscription = false }: { offer: Offer; onBuy: (offer: Offer) => void; purchasing: boolean; subscription?: boolean }) {
  return (
    <article className={`relative overflow-hidden rounded-2xl border p-4 ${offer.featured ? 'border-amber-300/80 bg-gradient-to-b from-amber-950/35 via-purple-950/70 to-[#09030f] shadow-[0_0_28px_rgba(245,158,11,.2)]' : 'border-amber-400/25 bg-gradient-to-b from-[#170622] to-[#09030f]'}`}>
      {offer.badge && <div className="absolute right-0 top-0 rounded-bl-xl border-b border-l border-amber-300/50 bg-gradient-to-r from-amber-500 to-yellow-300 px-3 py-1 text-[9px] font-black tracking-wider text-[#1a071e]">{offer.badge}</div>}
      <div className="mb-4 flex items-center gap-2 pt-1"><Crown className="h-5 w-5 text-amber-300" /><h3 className="font-display text-sm font-bold tracking-wide text-amber-100">{offer.title}</h3></div>
      <div className="mb-4 rounded-xl border border-amber-400/25 bg-black/25 p-3 text-center"><span className="font-display text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-amber-200 to-yellow-500">{offer.price}</span><span className="ml-1 text-[10px] text-purple-200/55">{offer.suffix}</span></div>
      <ul className="mb-4 space-y-2.5">
        {offer.features.map((feature) => <li key={feature} className="flex items-start gap-2 text-xs leading-relaxed text-purple-100/85"><span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border border-amber-400/40 bg-amber-500/10"><Check className="h-2.5 w-2.5 text-amber-300" /></span>{feature}</li>)}
      </ul>
      {offer.note && <p className="mb-4 text-[10px] leading-relaxed text-purple-200/55">{offer.note}</p>}
      <button onClick={() => onBuy(offer)} disabled={purchasing} className={`group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl border px-3 py-3 font-display text-xs font-bold tracking-wide transition hover:scale-[1.01] disabled:opacity-60 ${offer.featured ? 'border-amber-300 bg-gradient-to-r from-amber-400 to-yellow-500 text-[#1a071e]' : 'border-amber-400/45 bg-gradient-to-r from-purple-700 to-fuchsia-700 text-amber-50'}`}>
        {purchasing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}{offer.button}
      </button>
      {subscription && <div className="mt-2 text-center text-[9px] text-purple-300/45">Otomatik yenileme • İstediğin zaman iptal edebilirsin</div>}
    </article>
  );
}

export default PremiumPage;
