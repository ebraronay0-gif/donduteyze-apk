import { useState } from 'react';
import { ArrowLeft, Sparkles, Star, MessageCircle, ShieldCheck, Heart, Check, ChevronRight } from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import { getCredits, spendCredits } from '@/lib/credits';
import { FORTUNE_TELLER_PRICE, purchaseChatSession } from '@/lib/liveChat';
import { hasSupabaseConfig, supabase } from '@/lib/supabase';
import type { AuthUser } from '@/lib/auth';

interface Props { onNavigate: (tab: NavTabId) => void; onOpenChat: (user: AuthUser, counselor: string) => void; }

const TELLERS = [
  { name: 'Aliye Teyze', quote: 'Gönlünden geçenleri bilirim.', rating: '4.9', reviews: '12.458', specialty: ['Tarot', 'Kahve Falı', 'Aşk Falı', 'Ruhsal Rehberlik'], avatar: '/teller-aliye.svg', tone: 'from-fuchsia-500/20 via-purple-950/80 to-[#090116]' },
  { name: 'Sultan Teyze', quote: 'Kaderini birlikte aydınlatalım.', rating: '4.8', reviews: '9.876', specialty: ['Yıldız Falı', 'Melek Kartları', 'Enerji Falı', 'Numeroloji'], avatar: '/teller-sultan.svg', tone: 'from-emerald-500/15 via-purple-950/80 to-[#090116]' },
  { name: 'Yasemen Bacı', quote: 'İçindeki sesi duymana yardım ederim.', rating: '4.9', reviews: '11.203', specialty: ['Tarot', 'Kahve Falı', 'Ruhsal Rehberlik', 'Aşk Falı'], avatar: '/teller-yasemin.svg', tone: 'from-rose-500/15 via-purple-950/80 to-[#090116]' },
  { name: 'Döndü Teyze', quote: 'Hayatın sırlarını birlikte çözelim.', rating: '4.9', reviews: '15.692', specialty: ['Kahve Falı', 'Tarot', 'Melek Kartları', 'Yıldız Falı'], avatar: '/icon.png', tone: 'from-amber-500/20 via-purple-950/80 to-[#090116]', expert: true },
];

async function getOrCreateGuest(): Promise<AuthUser | null> {
  const { data } = await supabase.auth.getSession();
  if (data.session?.user) return { id: data.session.user.id, email: data.session.user.email || '' };
  const { data: anon, error } = await supabase.auth.signInAnonymously();
  if (error || !anon.user) return null;
  return { id: anon.user.id, email: anon.user.email || '' };
}

function FortuneTellerPage({ onNavigate, onOpenChat }: Props) {
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [done, setDone] = useState('');

  const choose = async (name: string) => {
    if (busy) return;
    setError('');
    if (getCredits() < FORTUNE_TELLER_PRICE) {
      setError(`Bu falcıyla görüşmek için ${FORTUNE_TELLER_PRICE} kredi gerekiyor.`);
      return;
    }
    if (!hasSupabaseConfig) {
      setError('Falcı mesajlaşma sunucusu şu anda yapılandırılmamış.');
      return;
    }
    setBusy(name);
    const buyer = await getOrCreateGuest();
    if (!buyer) {
      setBusy(null);
      setError('Mesajlaşma bağlantısı kurulamadı. Lütfen tekrar deneyin.');
      return;
    }
    const result = spendCredits(FORTUNE_TELLER_PRICE);
    if (!result.success) { setBusy(null); setError('Yeterli krediniz yok.'); return; }
    const session = await purchaseChatSession(buyer, name);
    if (!session) {
      const { addCredits } = await import('@/lib/credits');
      addCredits(FORTUNE_TELLER_PRICE);
      setBusy(null);
      setError('Falcı sohbeti oluşturulamadı; krediniz iade edildi.');
      return;
    }
    setDone(name);
    setBusy(null);
    window.dispatchEvent(new Event('credits-updated'));
    setTimeout(() => onOpenChat(buyer, name), 450);
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#070116] pb-28 text-mystic-100">
      <StarField count={75} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_12%,rgba(168,85,247,.24),transparent_28%),radial-gradient(circle_at_85%_25%,rgba(245,158,11,.12),transparent_24%),linear-gradient(180deg,rgba(9,1,24,.12),#070116_70%)]" />

      <div className="relative z-10 mx-auto max-w-2xl px-3 pb-8 pt-4">
        <div className="mb-4 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold-400/45 bg-[#120520]/90 text-gold-100 shadow-[0_0_20px_rgba(168,85,247,.18)]">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex-1 rounded-full border border-gold-400/25 bg-[#120520]/75 px-4 py-2 backdrop-blur-md">
            <p className="text-[9px] uppercase tracking-[.28em] text-gold-300/70">Döndü Teyze'nin mistik dünyası</p>
            <p className="font-display text-base text-gold-100">Gerçek Yorumcular</p>
          </div>
        </div>

        <section className="relative mb-5 overflow-hidden rounded-[30px] border border-gold-400/40 bg-[radial-gradient(circle_at_18%_60%,rgba(168,85,247,.35),transparent_30%),linear-gradient(135deg,#1d0635,#080116_78%)] p-5 shadow-[0_24px_70px_rgba(0,0,0,.5),0_0_35px_rgba(124,58,237,.18)]">
          <div className="absolute -right-8 top-4 h-24 w-24 rounded-full bg-purple-500/10 blur-2xl" />
          <div className="grid grid-cols-[110px_1fr] items-center gap-4">
            <div className="relative flex h-28 w-28 items-end justify-center overflow-hidden rounded-[28px] border border-gold-300/45 bg-gradient-to-br from-purple-800/60 to-black/30 shadow-[0_15px_35px_rgba(0,0,0,.45)]">
              <img src="/teller-yasemin.svg" alt="Mistik yorumcu" className="h-full w-full object-contain drop-shadow-[0_12px_20px_rgba(168,85,247,.28)]" />
              <div className="absolute bottom-2 right-2 h-3 w-3 rounded-full border-2 border-[#19052c] bg-emerald-400 shadow-[0_0_12px_rgba(74,222,128,.8)]" />
            </div>
            <div>
              <div className="mb-1 flex items-center gap-2 text-gold-300"><Sparkles className="h-4 w-4" /><span className="text-[10px] uppercase tracking-[.22em]">Yorumcularımıza</span></div>
              <h1 className="font-display text-[27px] leading-none text-gold-100 sm:text-3xl">FAL BAKTIR</h1>
              <p className="mt-2 text-xs leading-5 text-mystic-300">Gerçek yorumcularımıza falını baktır, merak ettiklerinin cevabını öğren.</p>
            </div>
          </div>
          <div className="mt-5 grid grid-cols-3 overflow-hidden rounded-2xl border border-gold-400/25 bg-black/20">
            <div className="flex items-center gap-2 border-r border-gold-400/15 p-3"><ShieldCheck className="h-5 w-5 text-gold-300" /><span className="text-[10px] text-gold-100"><b className="block">%100</b>Güvenli</span></div>
            <div className="flex items-center gap-2 border-r border-gold-400/15 p-3"><MessageCircle className="h-5 w-5 text-gold-300" /><span className="text-[10px] text-gold-100"><b className="block">Gerçek</b>Yorumcular</span></div>
            <div className="flex items-center gap-2 p-3"><Heart className="h-5 w-5 text-pink-300" /><span className="text-[10px] text-gold-100"><b className="block">Dilediğin Kadar</b>Mesajlaş</span></div>
          </div>
        </section>

        {error && <div className="mb-4 rounded-2xl border border-rose-500/30 bg-rose-950/35 p-3 text-center text-xs text-rose-200">{error}</div>}

        <div className="space-y-3">
          {TELLERS.map((t) => (
            <article key={t.name} className={`relative overflow-hidden rounded-[25px] border border-gold-400/35 bg-gradient-to-br ${t.tone} p-3 shadow-[0_16px_42px_rgba(0,0,0,.45),inset_0_1px_1px_rgba(255,255,255,.08)]`}>
              <div className="grid grid-cols-[84px_1fr_116px] items-center gap-3 sm:grid-cols-[100px_1fr_135px]">
                <div className="relative mx-auto h-[78px] w-[78px] overflow-hidden rounded-full border-2 border-gold-300/55 bg-gradient-to-br from-purple-800/70 to-black/50 p-1 shadow-[0_0_25px_rgba(168,85,247,.25)] sm:h-[92px] sm:w-[92px]">
                  <img src={t.avatar} alt={t.name} className="h-full w-full object-contain drop-shadow-[0_8px_12px_rgba(0,0,0,.35)]" />
                  <span className="absolute bottom-1 right-1 h-3 w-3 rounded-full border-2 border-[#170525] bg-emerald-400" />
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-display text-[18px] leading-tight text-gold-100 sm:text-xl">{t.name}</h2>
                    {t.expert && <span className="rounded-full border border-violet-300/35 bg-violet-500/20 px-2 py-0.5 text-[8px] font-semibold uppercase tracking-wider text-violet-100">Uzman</span>}
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-[10px] text-emerald-300"><span className="h-2 w-2 rounded-full bg-emerald-400" /> Çevrimiçi</div>
                  <p className="mt-1 line-clamp-1 text-[11px] text-mystic-300">“{t.quote}”</p>
                  <div className="mt-1.5 flex items-center gap-2 text-[9px] text-gold-200"><span className="flex items-center gap-1"><Star className="h-3 w-3 fill-gold-300 text-gold-300" />{t.rating}</span><span className="opacity-50">|</span><span>{t.reviews} yorum</span></div>
                  <div className="mt-1.5 hidden flex-wrap gap-1 sm:flex">{t.specialty.map(s => <span key={s} className="rounded-full border border-violet-300/20 bg-violet-500/10 px-1.5 py-0.5 text-[8px] text-violet-100">{s}</span>)}</div>
                </div>
                <div className="flex flex-col items-stretch gap-2">
                  <div className="flex items-center justify-center gap-1 rounded-xl border border-gold-300/40 bg-black/30 px-2 py-2 text-[11px] font-bold text-gold-100"><span className="text-gold-300">✦</span>{FORTUNE_TELLER_PRICE} KREDİ</div>
                  <button onClick={() => choose(t.name)} disabled={!!busy} className="rounded-xl border border-gold-200/70 bg-gradient-to-r from-violet-700 to-purple-600 px-2 py-3 font-display text-[12px] text-white shadow-[0_0_20px_rgba(168,85,247,.4)] transition active:scale-[.98] disabled:opacity-60">{busy === t.name ? 'Açılıyor...' : 'FAL BAKTIR'}</button>
                  <div className="flex items-start gap-1 text-[8px] leading-3 text-mystic-400"><Heart className="mt-0.5 h-3 w-3 shrink-0 text-pink-300" />Falcı görüşmeyi sonlandırana kadar mesajlaşabilirsiniz.</div>
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-1 sm:hidden">{t.specialty.map(s => <span key={s} className="rounded-full border border-violet-300/20 bg-violet-500/10 px-1.5 py-0.5 text-[8px] text-violet-100">{s}</span>)}</div>
            </article>
          ))}
        </div>

        {done && <div className="mt-4 flex items-center justify-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-950/30 p-3 text-xs text-emerald-200"><Check className="h-4 w-4" /> {done} seçildi · {FORTUNE_TELLER_PRICE} kredi harcandı · mesaj kutusu açılıyor</div>}

        <section className="mt-5 rounded-[24px] border border-gold-400/30 bg-gradient-to-br from-[#21083b] to-[#0b021b] p-4 shadow-[0_18px_45px_rgba(0,0,0,.4)]">
          <div className="mb-4 flex items-center justify-center gap-2"><Sparkles className="h-4 w-4 text-gold-300" /><h3 className="font-display text-lg text-gold-100">NASIL ÇALIŞIR?</h3><Sparkles className="h-4 w-4 text-gold-300" /></div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[['1','Yorumcunu seç','Sana uygun yorumcuyu seç ve sohbete başla.'],['2','Sorunu sor','Merak ettiklerini yorumcuna yaz.'],['3','Cevabını al','Yorumcundan detaylı fal yorumunu al.'],['4','Sohbet devam eder','Falcı görüşmeyi sonlandırana kadar özgürce mesajlaş.']].map(([n,title,text]) => (
              <div key={n} className="rounded-2xl border border-gold-400/15 bg-black/20 p-3 text-center">
                <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-full border border-gold-300/40 bg-purple-700/30 font-display text-gold-100">{n}</div>
                <p className="mt-2 text-[11px] font-semibold text-gold-100">{title}</p><p className="mt-1 text-[9px] leading-4 text-mystic-400">{text}</p>
              </div>
            ))}
          </div>
        </section>
        <p className="mt-4 flex items-center justify-center gap-1 text-[9px] text-mystic-600"><ChevronRight className="h-3 w-3" /> Yorumcuların görüşleri eğlence amaçlıdır.</p>
      </div>
    </div>
  );
}

export default FortuneTellerPage;
