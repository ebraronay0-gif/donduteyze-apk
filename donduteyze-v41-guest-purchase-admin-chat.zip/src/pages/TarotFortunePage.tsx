import { useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle2,
  CircleDot,
  Eye,
  Flame,
  Gem,
  Heart,
  Moon,
  Orbit,
  Sparkles,
  Sun,
  Sword,
  Waves,
  WandSparkles,
  Star,
} from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { NavTabId } from '@/lib/navTabs';
import { submitFortune } from '@/lib/fortuneApi';
import { FORTUNE_COST, getCredits } from '@/lib/credits';

interface TarotFortunePageProps {
  onNavigate: (tab: NavTabId) => void;
}

const REQUIRED_PICKS = 3;

const TAROT_CARDS = [
  { symbol: Sun, name: 'Güneş', tone: 'from-amber-500/30 via-purple-900/80 to-[#0b0319]' },
  { symbol: Moon, name: 'Ay', tone: 'from-indigo-500/30 via-purple-950/80 to-[#0b0319]' },
  { symbol: Star, name: 'Yıldız', tone: 'from-violet-500/30 via-purple-950/80 to-[#0b0319]' },
  { symbol: Eye, name: 'Sezgi', tone: 'from-fuchsia-500/30 via-purple-950/80 to-[#0b0319]' },
  { symbol: Orbit, name: 'Kader', tone: 'from-cyan-500/20 via-purple-950/80 to-[#0b0319]' },
  { symbol: Gem, name: 'Bereket', tone: 'from-emerald-500/20 via-purple-950/80 to-[#0b0319]' },
  { symbol: Flame, name: 'Ateş', tone: 'from-orange-500/30 via-purple-950/80 to-[#0b0319]' },
  { symbol: Waves, name: 'Akış', tone: 'from-blue-500/25 via-purple-950/80 to-[#0b0319]' },
  { symbol: Sword, name: 'Cesaret', tone: 'from-slate-400/20 via-purple-950/80 to-[#0b0319]' },
  { symbol: Heart, name: 'Aşk', tone: 'from-rose-500/25 via-purple-950/80 to-[#0b0319]' },
  { symbol: WandSparkles, name: 'Dönüşüm', tone: 'from-purple-500/35 via-purple-950/80 to-[#0b0319]' },
  { symbol: CircleDot, name: 'Döngü', tone: 'from-yellow-500/25 via-purple-950/80 to-[#0b0319]' },
];

function TarotFortunePage({ onNavigate }: TarotFortunePageProps) {
  const [picks, setPicks] = useState<number[]>([]);
  const [showAd, setShowAd] = useState(false);
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const togglePick = (index: number) => {
    if (busy || success) return;
    setPicks((current) => {
      if (current.includes(index)) return current.filter((item) => item !== index);
      if (current.length >= REQUIRED_PICKS) return current;
      return [...current, index];
    });
  };

  const submit = () => {
    if (picks.length !== REQUIRED_PICKS || busy) return;
    if (getCredits() < FORTUNE_COST) {
      setError(`Tarot falı için ${FORTUNE_COST} kredi gerekiyor.`);
      return;
    }
    setError(null);
    setShowAd(true);
  };

  const completeAd = async () => {
    setShowAd(false);
    setBusy(true);
    setError(null);

    const selected = picks.map((index, position) => `${position + 1}. ${TAROT_CARDS[index].name}`).join(' | ');
    const result = await submitFortune({
      fortuneType: 'tarot',
      userInput: `Tarot destesinden seçilen 3 kart: ${selected}. Kart sırası geçmiş, şimdi ve gelecek olarak yorumlansın. Üç kartın ortak mesajını da ayrıca ver.`,
    });

    setBusy(false);
    if (!result.success) {
      setError(result.error || 'Tarot falın gönderilemedi.');
      return;
    }

    setSuccess(true);
    window.setTimeout(() => onNavigate('history'), 2600);
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#070112] pb-28 text-white">
      <StarField count={95} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_15%,rgba(168,85,247,.22),transparent_28%),radial-gradient(circle_at_85%_18%,rgba(251,191,36,.12),transparent_24%),radial-gradient(circle_at_50%_70%,rgba(76,29,149,.18),transparent_38%)]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-80 bg-gradient-to-b from-[#21063d]/45 to-transparent" />

      <div className="relative z-10 mx-auto max-w-3xl px-3 pb-8 pt-4 sm:px-5">
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="mb-4 flex items-center gap-2 rounded-full border border-amber-300/35 bg-black/30 px-4 py-2 text-sm font-semibold text-amber-100 shadow-[0_0_18px_rgba(251,191,36,.12)] backdrop-blur"
        >
          <ArrowLeft className="h-4 w-4" /> Geri
        </button>

        <section className="overflow-hidden rounded-[30px] border border-amber-300/25 bg-gradient-to-b from-[#25083f] via-[#120522] to-[#080112] shadow-[0_0_55px_rgba(124,58,237,.2)]">
          <div className="relative px-4 pb-5 pt-6 sm:px-7">
            <div className="pointer-events-none absolute -left-20 top-2 h-48 w-48 rounded-full bg-purple-500/15 blur-3xl" />
            <div className="pointer-events-none absolute -right-16 top-0 h-44 w-44 rounded-full bg-amber-400/10 blur-3xl" />

            <div className="relative text-center">
              <div className="mx-auto mb-2 flex items-center justify-center gap-3 text-amber-300/80">
                <span className="h-px w-16 bg-gradient-to-r from-transparent to-amber-300/70" />
                <Sparkles className="h-5 w-5" />
                <span className="h-px w-16 bg-gradient-to-l from-transparent to-amber-300/70" />
              </div>
              <h1 className="font-display text-4xl font-black uppercase tracking-wide text-transparent bg-clip-text bg-gradient-to-b from-amber-100 via-amber-300 to-amber-600 drop-shadow-[0_0_18px_rgba(251,191,36,.25)] sm:text-5xl">
                Tarot Falı
              </h1>
              <p className="mt-2 text-xl font-medium text-amber-50/90">Kartlar seni çağırıyor...</p>
              <p className="mx-auto mt-2 max-w-xl text-sm leading-relaxed text-mystic-200/90 sm:text-base">
                Kalbinden bir dilek geçir ve aşağıdaki 12 karttan <strong className="text-amber-200">3 tanesini</strong> seç.
              </p>
            </div>

            <div className="mx-auto mt-5 flex max-w-2xl items-center justify-center gap-3 rounded-full border border-amber-300/30 bg-[#16072a]/85 px-4 py-2.5 text-center shadow-[0_0_25px_rgba(168,85,247,.16)]">
              <Sparkles className="h-4 w-4 shrink-0 text-amber-300" />
              <span className="font-display text-sm font-bold uppercase tracking-wider text-amber-100">3 kart seçtiğinde falın açılacak</span>
              <Sparkles className="h-4 w-4 shrink-0 text-amber-300" />
            </div>
          </div>

          <div className="border-y border-purple-300/15 bg-black/15 px-3 py-4 sm:px-5">
            <div className="mb-3 flex items-center justify-between px-1">
              <span className="font-display text-sm font-semibold text-amber-100">Seçilen Kartlar</span>
              <span className="rounded-full border border-amber-300/25 bg-amber-300/5 px-3 py-1 text-xs font-bold text-amber-200">
                {picks.length} / {REQUIRED_PICKS}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 sm:gap-3">
              {Array.from({ length: REQUIRED_PICKS }).map((_, slot) => {
                const index = picks[slot];
                const CardIcon = index === undefined ? Sparkles : TAROT_CARDS[index].symbol;
                return (
                  <div
                    key={slot}
                    className={`relative flex aspect-[2/2.7] items-center justify-center overflow-hidden rounded-2xl border ${
                      index === undefined ? 'border-dashed border-purple-300/20 bg-purple-950/20' : 'border-amber-300/50 bg-gradient-to-br from-purple-900 to-[#090114] shadow-[0_0_22px_rgba(251,191,36,.16)]'
                    }`}
                  >
                    <div className="absolute inset-1.5 rounded-xl border border-amber-300/10" />
                    <CardIcon className={`relative h-8 w-8 ${index === undefined ? 'text-purple-300/35' : 'text-amber-200'}`} strokeWidth={1.25} />
                    {index !== undefined && <span className="absolute bottom-2 left-0 right-0 text-center text-[10px] font-bold uppercase tracking-wider text-amber-100">{TAROT_CARDS[index].name}</span>}
                    {index === undefined && <span className="absolute bottom-2 left-0 right-0 text-center text-[9px] font-bold uppercase tracking-wider text-purple-300/40">Kart {slot + 1}</span>}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="px-3 py-5 sm:px-5 sm:py-6">
            <div className="mb-4 flex items-center justify-between px-1">
              <div>
                <h2 className="font-display text-base font-bold text-amber-100">12 Karttan Seç</h2>
                <p className="mt-0.5 text-xs text-mystic-400">Sezgilerine güven. En fazla 3 kart seçebilirsin.</p>
              </div>
              <div className="hidden items-center gap-1.5 text-xs text-amber-200/70 sm:flex">
                <span className="h-2 w-2 rounded-full bg-amber-300 shadow-[0_0_9px_rgba(251,191,36,.8)]" />
                {picks.length === 3 ? 'Seçim tamamlandı' : 'Kartlarını seç'}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4 sm:gap-3.5">
              {TAROT_CARDS.map(({ symbol: Icon, name, tone }, index) => {
                const picked = picks.includes(index);
                const order = picks.indexOf(index);
                return (
                  <button
                    key={name}
                    type="button"
                    onClick={() => togglePick(index)}
                    disabled={busy || success}
                    aria-label={`${index + 1}. ${name} kartı`}
                    className={`group relative aspect-[.67] overflow-hidden rounded-[18px] border text-left transition-all duration-300 ${
                      picked
                        ? 'scale-[1.025] border-amber-200 shadow-[0_0_30px_rgba(251,191,36,.42)]'
                        : 'border-purple-300/20 hover:-translate-y-1 hover:border-amber-300/55 hover:shadow-[0_10px_30px_rgba(124,58,237,.25)]'
                    } disabled:cursor-not-allowed`}
                  >
                    <div className={`absolute inset-0 bg-gradient-to-br ${tone}`} />
                    <div className="absolute inset-2 rounded-[13px] border border-amber-300/30" />
                    <div className="absolute inset-3 rounded-[10px] border border-purple-200/10" />
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(251,191,36,.16),transparent_25%),radial-gradient(circle_at_50%_75%,rgba(168,85,247,.2),transparent_40%)]" />
                    <div className="absolute inset-x-0 top-3 flex justify-center">
                      <span className="flex h-7 w-7 items-center justify-center rounded-full border border-amber-300/35 bg-black/25 text-[10px] font-bold text-amber-100">{index + 1}</span>
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="flex h-16 w-16 items-center justify-center rounded-full border border-amber-300/25 bg-purple-950/45 shadow-[0_0_24px_rgba(168,85,247,.18)] sm:h-20 sm:w-20">
                        <Icon className="h-8 w-8 text-amber-200 drop-shadow-[0_0_10px_rgba(251,191,36,.55)] sm:h-10 sm:w-10" strokeWidth={1.15} />
                      </div>
                    </div>
                    <div className="absolute bottom-2 left-2 right-2 rounded-lg border border-amber-300/15 bg-black/25 px-1.5 py-1 text-center backdrop-blur-sm">
                      <span className="font-display text-[9px] font-bold uppercase tracking-wider text-amber-100 sm:text-[10px]">{name}</span>
                    </div>
                    {picked && (
                      <div className="absolute inset-0 flex items-start justify-end p-2">
                        <span className="flex h-7 w-7 items-center justify-center rounded-full border border-amber-100/70 bg-amber-300 text-xs font-black text-purple-950 shadow-[0_0_15px_rgba(251,191,36,.8)]">
                          {order + 1}
                        </span>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={submit}
              disabled={picks.length !== REQUIRED_PICKS || busy || success}
              className="group relative mt-6 flex w-full items-center justify-center gap-2 overflow-hidden rounded-[22px] border border-amber-300/60 bg-gradient-to-r from-purple-700 via-violet-700 to-fuchsia-700 px-5 py-4 shadow-[0_0_28px_rgba(168,85,247,.28)] transition-all duration-300 enabled:hover:scale-[1.015] enabled:hover:shadow-[0_0_38px_rgba(251,191,36,.28)] disabled:cursor-not-allowed disabled:opacity-40"
            >
              <span className="pointer-events-none absolute inset-y-0 left-[-30%] w-1/3 skew-x-[-20deg] bg-white/15 blur-md transition-transform duration-700 group-hover:translate-x-[420%]" />
              {busy ? <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/20 border-t-amber-100" /> : success ? <CheckCircle2 className="h-5 w-5 text-amber-100" /> : <Sparkles className="h-5 w-5 text-amber-100" />}
              <span className="font-display text-lg font-black uppercase tracking-wider text-amber-50">
                {busy ? 'Falın hazırlanıyor...' : success ? 'Falın Fallarım’a gönderildi' : `Falımı Bak · ${FORTUNE_COST} Kredi`}
              </span>
            </button>

            {error && (
              <div className="mt-3 flex items-center gap-2 rounded-xl border border-rose-400/30 bg-rose-950/30 px-3 py-2 text-xs text-rose-200">
                <AlertCircle className="h-4 w-4 shrink-0" />
                {error}
              </div>
            )}
          </div>

          <div className="border-t border-purple-300/15 bg-[#0b0317]/80 px-4 py-4 text-center">
            <div className="flex items-center justify-center gap-2 text-amber-200/80">
              <Sparkles className="h-4 w-4" />
              <span className="font-display text-sm font-semibold">Tarotun gizli mesajını keşfet</span>
              <Sparkles className="h-4 w-4" />
            </div>
          </div>
        </section>

        <p className="mx-auto mt-4 max-w-md text-center text-[9px] leading-relaxed text-mystic-600">
          Tarot falı yalnızca eğlence amaçlıdır. Yorumlar profesyonel tavsiye niteliğinde değildir.
        </p>
      </div>

      <RewardedAdModal
        open={showAd}
        onComplete={completeAd}
        onClose={() => setShowAd(false)}
        rewardLabel="Tarot Falı"
      />

      {success && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/75 px-6 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-[28px] border border-amber-300/30 bg-[#11051f] p-7 text-center shadow-[0_0_50px_rgba(124,58,237,.3)]">
            <CheckCircle2 className="mx-auto h-14 w-14 text-amber-200" />
            <h2 className="mt-4 font-display text-xl font-bold text-amber-100">Tarot falın gönderildi</h2>
            <p className="mt-2 text-sm leading-relaxed text-mystic-300">Sonucun hazır olduğunda Fallarım bölümünde görünecek.</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default TarotFortunePage;
