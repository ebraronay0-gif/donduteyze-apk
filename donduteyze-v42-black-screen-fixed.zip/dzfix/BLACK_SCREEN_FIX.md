# V42.1 / 1.0.30 – Black screen fix

- AdMob initialization no longer runs before React mounts.
- AdMob failures are non-fatal and are handled after the first screen renders.
- Added a visible inline startup screen so the app never presents a blank/black body while the web bundle initializes.
- Supabase already has a safe fallback client when build secrets are absent.
- Version bumped to 1.0.30 so the rebuilt APK can be distinguished from the previous APK.
