# Döndü Teyze V18 — Full Engagement & Night Mode

V18, V17 üzerine kırmadan eklenen kapsamlı etkileşim katmanıdır.

- Önceki profesyonel ana sayfa korunur: 7 fal kartı, Yıldız Falı, 15 kredi etiketleri, ortalanmış banner reklam ve yorumcu CTA.
- Ana sayfaya Gece Modu eklendi; yıldız yoğunluğu ve atmosfer değişir ve seçim cihazda saklanır.
- Gece Modu altında Ay Işığı Oyunu eklendi; kısa soru/seri akışı ve küçük kredi ödülü vardır.
- Kişisel Döndü Dostum avatarı eklendi: seviye, XP, aşk/sevgi/mutluluk değerleri, günlük 3 öğün besleme, kıyafet seçimi ve günlük +1 kredi ödülü.
- 30 XP'de seviye artışı yapılır; sistem yerel cihazda saklanır.
- Günlük / Günlüklerim korunur; tarih-saat kaydı devam eder.
- Kredi Kazan kartları (Çarkıfelek, Zar, Çekiliş) korunur ve mevcut reklam/ödül akışına bağlanır.
- Canlı Destek, satın alma ekranından ayrıdır; now bar canlı destek doğrudan destek modalını açar.
- 6'lı now bar korunur; yalnız Döndü Teyze gerçek görsel kullanır, diğerleri yazı tabanlı kalır.
- Launcher icon kaynağı `public/icon.png` ile `resources/icon.png` birebir eşitlendi.
- APK build script'i eski Android launcher mipmap klasörlerini temizleyip güncel icon kaynağını yeniden üretir; böylece eski mavi varsayılan ikonun kalması engellenir.
