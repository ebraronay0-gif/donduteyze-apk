import { useState, useEffect, useRef } from 'react';
import { Capacitor } from '@capacitor/core';
import { AdMob } from '@capacitor-community/admob';
import { X, Play } from 'lucide-react';
import { getAdUnitId, USE_TEST_ADS } from '@/lib/ads';

interface InterstitialAdProps {
  open: boolean;
  onClose: () => void;
  duration?: number;
}

function InterstitialAd({ open, onClose, duration = 5 }: InterstitialAdProps) {
  const [secondsLeft, setSecondsLeft] = useState(duration);
  const [canClose, setCanClose] = useState(false);
  const timerRef = useRef<number | null>(null);
  const nativeStarted = useRef(false);

  useEffect(() => {
    let cancelled = false;
    if (!open) {
      setSecondsLeft(duration);
      setCanClose(false);
      nativeStarted.current = false;
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }
    if (Capacitor.isNativePlatform()) {
      nativeStarted.current = true;
      (async () => {
        try {
          await AdMob.prepareInterstitial({ adId: getAdUnitId('interstitial'), isTesting: USE_TEST_ADS });
          if (!cancelled) await AdMob.showInterstitial();
          if (!cancelled) onClose();
        } catch (error) {
          console.error('AdMob geçiş reklamı gösterilemedi:', error);
          if (!cancelled) { setCanClose(true); }
        }
      })();
      return () => { cancelled = true; };
    }
    timerRef.current = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          setCanClose(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => {
      cancelled = true;
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [open, duration]);

  if (!open) return null;
  if (nativeStarted.current && Capacitor.isNativePlatform() && !canClose) return null;

  const adUnitId = getAdUnitId('interstitial');
  const progress = ((duration - secondsLeft) / duration) * 100;

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-night-950/95 backdrop-blur-md animate-fade-in">
      <div className="absolute top-4 left-1/2 -translate-x-1/2">
        <span className="rounded-full border border-mystic-700/40 bg-night-800/80 px-3 py-1 text-[10px] font-medium text-mystic-400">
          Reklam
        </span>
      </div>

      <button
        onClick={onClose}
        disabled={!canClose}
        className={`absolute top-4 right-4 flex h-9 w-9 items-center justify-center rounded-full border transition ${
          canClose
            ? 'border-mystic-600/40 bg-night-700/80 text-mystic-200 hover:text-mystic-100'
            : 'border-mystic-800/40 bg-night-900/60 text-mystic-700'
        }`}
        aria-label="Reklamı kapat"
      >
        <X className="h-4 w-4" />
      </button>

      <div className="relative flex w-full max-w-md flex-col items-center justify-center px-6 py-12">
        <div className="pointer-events-none absolute -top-20 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full bg-gold-500/10 blur-3xl" />

        <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-2xl border border-gold-400/30 bg-gold-900/20">
          <Play className="h-10 w-10 text-gold-300" />
        </div>

        <p className="font-display text-xl font-semibold text-mystic-100">
          {USE_TEST_ADS ? 'Test Geçiş Reklamı' : 'Geçiş Reklamı'}
        </p>
        <p className="mt-2 text-xs text-mystic-500">
          AdMob Birim: {adUnitId}
        </p>

        <div className="mt-6 h-1.5 w-full max-w-xs overflow-hidden rounded-full bg-mystic-700/40">
          <div
            className="h-full rounded-full bg-gold-400 transition-all duration-1000 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>

        {canClose ? (
          <button
            onClick={onClose}
            className="mt-6 rounded-xl border border-gold-400/40 bg-gold-900/30 px-8 py-3 font-display text-sm font-semibold text-gold-100 transition hover:bg-gold-800/40"
          >
            Devam Et
          </button>
        ) : (
          <p className="mt-6 text-sm text-mystic-400">
            Reklam {secondsLeft} saniye sonra kapanabilir...
          </p>
        )}
      </div>
    </div>
  );
}

export default InterstitialAd;
