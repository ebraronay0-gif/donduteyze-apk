import { useEffect } from 'react';
import { Capacitor } from '@capacitor/core';
import { AdMob, BannerAdPosition, BannerAdSize } from '@capacitor-community/admob';
import { isAdFree } from '@/lib/subscriptions';
import { getAdUnitId, USE_TEST_ADS } from '@/lib/ads';

interface BannerAdProps {
  inline?: boolean;
  size?: 'banner' | 'large';
}

function BannerAd({ inline = false, size = 'banner' }: BannerAdProps) {
  const adUnitId = getAdUnitId('banner');

  useEffect(() => {
    if (isAdFree() || !Capacitor.isNativePlatform()) return;
    let cancelled = false;
    (async () => {
      try {
        await AdMob.showBanner({
          adId: adUnitId,
          adSize: size === 'large' ? BannerAdSize.LARGE_BANNER : BannerAdSize.ADAPTIVE_BANNER,
          position: BannerAdPosition.BOTTOM_CENTER,
          margin: inline ? 8 : 0,
          isTesting: USE_TEST_ADS,
        });
      } catch (error) {
        console.error('AdMob banner gösterilemedi:', error);
      }
    })();
    return () => {
      cancelled = true;
      if (!cancelled) return;
      void AdMob.hideBanner().catch(() => undefined);
    };
  }, [adUnitId, inline, size]);

  if (isAdFree()) return null;

  // Browser/PWA fallback keeps the layout honest; real AdMob is used on native builds.
  if (Capacitor.isNativePlatform()) return null;

  const heightClass = size === 'large' ? 'h-20' : 'h-14';
  const wrapperClass = inline
    ? 'relative mx-auto flex w-full max-w-md items-center justify-center rounded-2xl border border-purple-400/20 bg-[#120621]/90 px-3 py-2 backdrop-blur-sm shadow-[0_0_22px_rgba(124,58,237,.12)]'
    : 'fixed bottom-16 left-0 right-0 z-30 flex items-center justify-center border-t border-mystic-700/30 bg-night-800/95 px-3 py-1.5 backdrop-blur-sm';

  return (
    <div className={wrapperClass}>
      <div className="flex w-full max-w-md items-center gap-2">
        <span className="shrink-0 rounded bg-mystic-700/40 px-1.5 py-0.5 text-[9px] font-medium text-mystic-400">Reklam</span>
        <div className={`flex ${heightClass} flex-1 items-center justify-center rounded-lg border border-mystic-700/30 bg-gradient-to-r from-mystic-800/30 to-night-700/30`}>
          <span className="text-xs font-medium text-mystic-300">{USE_TEST_ADS ? 'AdMob Test Banner' : 'AdMob Banner'}</span>
        </div>
      </div>
    </div>
  );
}

export default BannerAd;
