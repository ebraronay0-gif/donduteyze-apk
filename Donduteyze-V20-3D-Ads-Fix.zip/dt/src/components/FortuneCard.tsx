import type { FortuneCategory } from '@/lib/fortuneCategories';

interface FortuneCardProps {
  category: FortuneCategory;
  onClick?: () => void;
}

function FortuneCard({ category, onClick }: FortuneCardProps) {
  const Icon = category.icon;

  return (
    <button
      onClick={onClick}
      className="group relative aspect-[0.92] overflow-hidden rounded-[1.35rem] border border-gold-400/15 bg-gradient-to-br from-night-700/90 via-night-800/90 to-night-950/95 p-2.5 text-left transition-all duration-300 hover:-translate-y-1 hover:border-gold-400/50"
      style={{ boxShadow: `0 4px 20px ${category.glow}` }}
    >
      {/* Glow blob */}
      <div
        className="pointer-events-none absolute -top-8 -right-8 h-24 w-24 rounded-full opacity-30 blur-2xl transition-opacity duration-300 group-hover:opacity-60"
        style={{ backgroundColor: category.glow }}
      />

      {/* 3D Icon */}
      <div className="relative flex h-full flex-col items-center justify-center gap-2">
        <div
          className="relative transition-transform duration-500 group-hover:scale-110"
          style={{ perspective: '600px' }}
        >
          <div
            className="transition-transform duration-500 group-hover:[transform:rotateY(15deg)_rotateX(-10deg)]"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div
              className="relative flex h-16 w-16 items-center justify-center rounded-[1.25rem] border border-gold-300/20 bg-gradient-to-br from-white/20 via-purple-700/30 to-purple-950/70 backdrop-blur-md sm:h-[4.5rem] sm:w-[4.5rem]"
              style={{
                boxShadow: `0 10px 28px ${category.glow}, 0 0 18px rgba(251,191,36,0.10), inset 0 1px 1px rgba(255,255,255,0.22)`,
              }}
            >
              <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-gold-200/80 blur-[2px]" /><Icon className={`relative z-10 h-8 w-8 drop-shadow-[0_5px_10px_rgba(0,0,0,0.5)] sm:h-9 sm:w-9 ${category.iconColor}`} strokeWidth={1.5} />
            </div>
          </div>
        </div>

        <div className="text-center">
          <h3 className="font-display text-[11px] font-semibold leading-tight text-mystic-100 sm:text-sm">
            {category.name}
          </h3>
          <p className="mt-1 text-[9px] leading-tight text-mystic-400 sm:text-[10px]">{category.description}</p>
        </div>
      </div>

      {/* Shimmer sweep */}
      <div className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/5 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
    </button>
  );
}

export default FortuneCard;
