import { StrictMode } from 'react';
import { AdMob } from '@capacitor-community/admob';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

void AdMob.initialize({ initializeForTesting: import.meta.env.DEV || import.meta.env.VITE_USE_TEST_ADS === 'true' });

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
