import type { LucideIcon } from 'lucide-react';
import { Home, Gift, History, Stars, Headphones, Crown } from 'lucide-react';

export type NavTabId = 'home' | 'earn' | 'history' | 'zodiac' | 'support' | 'premium';
export interface NavTab { id: NavTabId; label: string; icon: LucideIcon; }

export const NAV_TABS: NavTab[] = [
  { id: 'home', label: 'DÖNDÜ TEYZE', icon: Home },
  { id: 'history', label: 'FALLARIM', icon: History },
  { id: 'earn', label: 'KREDİ KAZAN', icon: Gift },
  { id: 'zodiac', label: 'BURÇLAR', icon: Stars },
  { id: 'support', label: 'CANLI DESTEK', icon: Headphones },
  { id: 'premium', label: 'PREMİUM', icon: Crown },
];
