import { supabase, hasSupabaseConfig } from '@/lib/supabase';
import { FORTUNE_COST, spendCredits, getCredits } from './credits';

const USER_EMAIL_KEY = 'fal_user_email';
const READINGS_KEY = 'donduteyze_readings';

const MAX_IMAGE_DIM = 768;
const JPEG_QUALITY = 0.75;

async function compressImage(dataUrl: string): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width > MAX_IMAGE_DIM || height > MAX_IMAGE_DIM) {
        const ratio = Math.min(MAX_IMAGE_DIM / width, MAX_IMAGE_DIM / height);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(dataUrl);
        return;
      }
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', JPEG_QUALITY));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

export function getUserEmail(): string {
  try {
    let email = localStorage.getItem(USER_EMAIL_KEY);
    if (!email) {
      email = `guest_${Date.now()}_${Math.random().toString(36).slice(2, 8)}@donduteyze.app`;
      localStorage.setItem(USER_EMAIL_KEY, email);
    }
    return email;
  } catch {
    return `guest_${Date.now()}@donduteyze.app`;
  }
}

export interface FortuneReading {
  id: string;
  user_email: string;
  fortune_type: string;
  status: 'pending' | 'completed' | 'rejected';
  result: string | null;
  image_data: string | null;
  user_input: string | null;
  created_at: string;
  ready_at: string;
}

const DISCLAIMER = '\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.';

function generateFallbackFortune(fortuneType: string, userInput?: string): string {
  const fallbacks: Record<string, string> = {
    coffee: `Merhaba canım, hoş geldin. Fincanını elime aldığımda teller bana adeta fısıldamaya başladı. Öncelikle, fincanın dibinde belirgin bir kalp şekli görüyorum — bu, kalbinde derin bir sevgi arayışı olduğunu, ama aynı zamanda yakında bu arayışın sona ereceğini müjdeliyor. Telve içinde bir kuş figürü de var; bu, özgürlüğüne ve bağımsızlığına düşkün biri olduğunuzu, yeni bir kapı açılacağını gösteriyor.

Aşk hayatına bakalım canım. Telve içinde iki yan yana çizgi görüyorum — bu, şu an hayatında bir ikili ilişkinin olduğunu ya da çok yakında gireceğin bir bağlantıyı temsil ediyor. Karşındaki kişi seni şaşırtacak, beklediğin gibi biri olmayabilir ama kalbini ısıtacak. Sabırlı ol, aceleci olma; yıldızlar sizin için uygun zamanı ayarlıyor. Eğer halen birinin hayalini kuruyorsan, o kişi seni düşünüyor — teller bunu açıkça gösteriyor.

Kariyer方面a gelince, fincanın kenarında bir merdiven sembolü var. Bu, adım adım yükseleceğini, emeklerinin karşılığını alacağını ama bir anda değil, zamanla geleceğini gösteriyor. Önümüzdeki haftalarda önemli bir fırsat gelebilir; gözlerini dört aç. Çevrendeki bir kadın figürü, sana destek olacak bir mentor ya da arkadaşın olduğunu müjdeliyor — ona kulak ver.

Sağlık方面a baktığımda, teller arasında bir su damlası sembolü görüyorum. Bu, vücudunun sana dinlenme çağrısı yaptığını gösteriyor. Son zamanlarda çok yoruldun, ruhun ve bedenin tazeleme ihtiyacı duyuyor. Bol bol su iç, doğada yürüyüşler yap ve geceleri uykunu ihmal etme. Enerjin yakında yenilenecek.

Gelecekten bir kesit daha göreyim canım. Fincanın tabağında bir yıldız figürü belirdi — bu, önümüzdeki ay içinde seni bekleyen sürpriz bir mutluluk haberi. Beklemediğin bir anda, beklemediğin bir yerden güzel bir gelişme kapını çalacak. Korkma, sevgiyle karşıla.

Son olarak, tellerin oluşturduğu bir anahtar sembolü var. Bu, elinde çözemediğin bir sorunun anahtarının çok yakında ortaya çıkacağını gösteriyor. Sabırlı ol, yıldızlar senin yanında.${DISCLAIMER}`,

    tarot: `Merhaba canım, hoş geldin. Seçtiğin üç kartı dizdim önüme ve yıldızlar bana onların sırrını açtı. İlk kartın geçmişini, ikinci kartın bugününü, üçüncü kartın ise geleceğini temsil ediyor. Gel bakalım, ne fısıldıyorlar.

Geçmiş kartına bakıyorum canım. Bu kart, geçmişinde bir ayrılık ya da bitiş olduğunu gösteriyor — belki bir ilişki, belki bir alışkanlık, belki bir dönem. Ama bu bitiş, seni üzse de aslında seni özgürleştirdi. Kartın ters dönük figürü, o geçmişin seni hâlâ biraz etkilediğini, ama artık onunla vedalaşma vaktinin geldiğini söylüyor. O geçmiş, senin bugünkü gücünün temelidir; utanma, onu kabul et.

Bugün kartına geçelim. Bu kart, tam ortasında bir yol ayrımı sembolü taşıyor. Şu an hayatında bir karar vermek üzeresin — belki bir ilişki, belki bir iş, belki bir içsel seçim. Kart, kalbinin sesini dinlemeni söylüyor. Aklın değil, kalbin yol göstersin. Sezgilerin şu an çok güçlü; yıldızlar onları besliyor. Eğer bir tereddütin varsa, bir adım geri çekil ve nefes al — cevap içinden gelecek.

Gelecek kartına bakıyorum canım. Bu kart, üzerinde bir güneş sembolü taşıyor — bu, gelecekte seni parlak, aydınlık bir dönemin beklediğini müjdeliyor. Önümüzdeki haftalarda, beklediğin bir haber gelecek, beklediğin bir karşılaşma gerçekleşecek. Kartın alt kısmındaki iki el figürü, bu dönemi paylaşacağın birinin olduğunu gösteriyor — yalnız olmayacaksın.

Üç kartı bir araya getirdiğimde, şöyle bir hikâye çıkıyor: Geçmişin seni hazırladı, bugünün seni yol'a koydu, geleceğin seni ödüllendirecek. Aceleci olma, her kartın sırasını bekle. Yıldızlar senin için döndü.${DISCLAIMER}`,

    palm: `Merhaba canım, hoş geldin. Avuç içlerini uzattın ve yıldızlar bana çizgilerinin dilini tercüme etti. Gel bakalım, ne söylüyor bu çizgiler.

Önce hayat çizgine bakıyorum canım. Çizgin uzun, net ve kesintisiz — bu, önünde uzun ve bereketli bir ömür olduğunu gösteriyor. Çizginin ortasında hafif bir kıvrım var; bu, hayatında bir dönüm noktası yaşayacağını, o dönüm noktasından sonra ise daha bilge, daha olgun bir kişi olacağını müjdeliyor. Gençliğin enerjisiyle, olgunluğun bilgeliğini birleştireceksin.

Kalp çizgine geçelim. Çizgin derin ve kıvrımlı — bu, sevme ve sevilme kapasitenin çok yüksek olduğunu gösteriyor. Derin bir kalbin var, hisleri yoğun yaşıyorsun. Çizginin sonunda bir çatallaşma görüyorum; bu, hayatında iki farklı kalp yolundan birini seçeceğin bir anın yaklaştığını gösteriyor. Biri güvenli ve tanıdık, diğeri sürprizli ve yeni — kalbin hangisine çekildiğini dinle. Seçimini yaparken korkma; yıldızlar her iki yolda da senin için bir ders saklıyor.

Kafa çizgine bakıyorum şimdi. Çizgin net, düz ve uzun — zekân keskin, düşünce yapın sağlam. Analitik bir zihnin var ama aynı zamanda sezgilerin de güçlü; bu nadir bir kombinasyon. Çizginin ortasında küçük bir ada var; bu, hayatında bir öğrenme dönemi geçireceğini, yeni bir beceri ya da bilgi edineceğini ve bunun senin hayatını değiştireceğini gösteriyor.

Kader çizgine gelince canım, çizgin biraz kıvrımlı ve ince — bu, hayat seni bazen sürpriz yollara götürecek, ama her sapma seni daha güçlü bir yere ulaştıracak demek. Kaderin düz bir çizgi değil, ama her kıvrımı seni bir hazineye götürüyor. Sabırlı ol, her kıvrımın bir anlamı var.

Avucunun alt kısmında bir yıldız işareti görüyorum — bu nadir bir işaret. Bu, senin özel bir enerjiye sahip olduğunu, insanları etkileyen bir karizman olduğunu gösteriyor. Belki farkında değilsin ama çevrendekiler senin ışığını hissediyor.${DISCLAIMER}`,

    face: `Merhaba canım, hoş geldin. Yüzünü inceledim ve yıldızlar bana hatlarının gizli anlamlarını fısıldadı. Gel bakalım, ne söylüyor bu çizgiler.

Önce alnına bakıyorum canım. Alnın geniş ve açık — bu, zekânın ve vizyonunun geniş olduğunu gösteriyor. Düşüncelerin derin, ufukların açık. Alnının ortasında hafif bir çizkı var; bu, düşünme tarzının analitik olduğunu, bir konunun üzerine gidip derinleştiğini gösteriyor. Ama aynı zamanda bu çizkı, bazen çok fazla düşündüğünü, bazen kendini yormamayı öğrenmen gerektiğini de söylüyor. Zihnine mola ver.

Kaşlarına geçelim. Kaşların belirgin ve yay şeklinde — bu, kararlılık ve azmin simgesi. Bir işe kalkıştığında pes etmezsin, sonuna kadar götürürsün. Kaşlarının arasındaki mesafe, açık görüşlü bir insan olduğunu, ön yargılardan uzak durduğunu gösteriyor.

Gözlerine bakıyorum şimdi canım. Gözlerin derin ve anlamlı — iç dünyan çok zengin, hislerin derin. Gözlerinin renginde bir sıcaklık var; bu, insanların sana güvenmesini sağlayan bir enerji. Bakışların, bazen insanları etkileyen bir derinliğe sahip. Gözlerinin altında hafif bir çizkı görüyorum; bu, son zamanlarda duygusal bir yorgunluk yaşadığını, ama bunun yakında geçeceğini gösteriyor.

Burun yapına bakalım. Burunun belirgin ve düz — bu, özgüveni ve kararlılığı temsil eder. Hayatta pes etmeyen bir yapın var. Burunun ucu hafif yuvarlak; bu, sezgilerinin güçlü olduğunu, bir konuyu "hissederek" anladığını gösteriyor. Aklın ve kalbin birlikte çalışıyor.

Çene yapına gelince canım. Çenen belirgin ve güçlü — bu, azmini ve direncini gösteriyor. Hedeflerine ulaşmak için sabırla bekleyen birisin. Çene hattındaki keskinlik, bir liderlik enerjisi taşıdığını da müjdeliyor. Çevrendekiler senin kararlılığına saygı duyuyor.

Yanaklarına baktığımda hafif bir gamze izi görüyorum — bu, insanların seni sevmesini sağlayan bir şans işareti. Gülümseten bu detay, sana kapı açar.${DISCLAIMER}`,

    dream: `Merhaba canım, hoş geldin. Rüyanı dikkatle dinledim ve yıldızlar bana sembollerinin sırrını açtı. Gel bakalım, ne mesajlar var bu rüyada.

Rüyanda gördüğün semboller, iç dünyanın aynası. Bilinçaltın sana bir mesaj gönderiyor — duymaya hazır ol. Rüyanın atmosferi bana sıcak ve biraz gizemli geliyor; bu, bir dönüşüm içinde olduğunu, eski bir kalıbı bırakıp yeni bir başlangıca hazırlandığını gösteriyor.

Rüyanın merkezindeki sembol, bana bir kapı ya da geçit çağrıştırıyor. Bu, hayatında bir kapının açılmak üzere olduğunu gösteriyor — belki yeni bir fırsat, belki yeni bir insan, belki yeni bir içsel farkındalık. Bu kapıyı açmak için bir anahtarın var: cesaret. Korkma canım, kapı senin için açılıyor.

Rüyanın ikinci bölümünde bir su sembolü görüyorum — belki bir nehir, belki bir deniz, belki bir yağmur. Su, duyguları temsil eder. Bu sembol, duygusal bir arınma dönemi yaşayacağını, içinden geçen hislerle yüzleşip onları serbest bırakacağını gösteriyor. Bu arınmadan sonra hafifleyeceksin, yeni bir enerjiyle dolacaksın.

Rüyanın sonunda bir ışık görüyorsan, bu çok güzel bir işaret. Işık, yolun aydınlanacağını, karanlıkta kaldığını hissettiğin bir konunun yakında netleşeceğini müjdeliyor. Yıldızlar senin için parlıyor.

Rüyanın mesajı şu canım: İçindeki sesi dinle, korkuyla değil sevgiyle hareket et. Önündeki günlerde seni şaşırtacak güzel gelişmeler olabilir — beklemediğin bir anda, beklemediğin bir yerden. Hazır ol, kalbini açık tut.${DISCLAIMER}`,

    katina: `Merhaba canım, hoş geldin. Seçtiğin üç katina kartını dizdim önüme ve renklerin dili bana bir hikâye fısıldadı. Gel bakalım, ne söylüyor bu kartlar.

İlk kartın rengi bana geçmişini anlatıyor. Bu kart, geçmişinde bir dönemi kapattığını, yeni bir sayfa açmaya hazırlandığını gösteriyor. Renklerin tonu, o geçmişin seni biraz üzsse de aslında seni güçlendirdiğini, seni bugünkü haline getirdiğini söylüyor. O dönemi saygıyla an, ama geride bırak.

İkinci kartına bakalım. Bu kart, bugünün enerjisini yansıtıyor. Renklerin canlılığı, şu an içsel bir yenilenme içinde olduğunu gösteriyor. Eski alışkanlıklardan birini bırakıyorsun, yeni bir ritim arıyorsun. Kartın üzerindeki figür, bu yenilenmenin sana iyi geleceğini, kendini daha özgür hissedeceğini müjdeliyor. Kendine zaman tanı, çiçek açmak için toprağın hazırlanması gerekiyor.

Üçüncü kartına geçelim canım. Bu kart, geleceğin müjdesini taşıyor. Renklerin altın tonları, seni altın bir çağın beklediğini gösteriyor — bereket, bolluk, mutluluk. Bu dönemde elini attığın işler yolunda gidecek, ilişkilerin derinleşecek, içsel huzurun artacak. Ama bu altın çağ, senin aktif katılımınla gelecek; bekleme, adım at.

Üç kartı bir araya getirdiğimde, renklerin gökkuşağı oluşturduğunu görüyorum. Bu, hayatının tüm renklerini deneyimleyeceğini, her tonun seni zenginleştireceğini gösteriyor. Siyahı da beyazı da, kırmızısı da mavisini de yaşayacaksın — ama her renk seni daha tam bir insan yapacak. Renklerin enerjisi seni çevreliyor; kendine güven.${DISCLAIMER}`,

    dice: `Merhaba canım, hoş geldin. Attığın zarlar masada yuvarlandı ve yıldızlar bana sayıların sırrını açtı. Gel bakalım, ne müjdeler bu zarlar.

Zarların toplamı bana önündeki dönemin enerjisini gösteriyor. Sayılar yüksek — bu, şansın senin yanında olduğunu, ama yine de senin de çabalaması gerektiğini söylüyor. Yıldızlar fırsatı gönderiyor, ama sen o fırsatı yakalamak için elini uzatmalısın.

İlk zarın rakamı bana aşk hayatını anlatıyor. Bu sayı, kalbinde bir beklenti olduğunu, ama aynı zamanda yakında o beklentinin karşılık bulacağını gösteriyor. Eğer halen birinin hayalini kuruyorsan, o kişi seni düşünüyor — zarlar bunu açıkça gösteriyor. Aceleci olma, yıldızlar uygun zamanı ayarlıyor.

İkinci zarın rakamı kariyerini temsil ediyor. Bu sayı, önündeki dönemde bir fırsat kapısının açılacağını, ama o kapıyı çalması gerektiğini gösteriyor. Bekle, fırsat gelince cesurca adım at. Çevrenden gelecek bir teklif ya da davet, seni yeni bir yola koyacak.

Üçüncü zarın ise sağlık ve enerjiyi temsil ediyor. Bu sayı, vücudunun şimdilik güçlü olduğunu, ama sonbaharda bir dinlenme dönemi geçirmen gerektiğini söylüyor. Şimdi enerjini topla, kışın sana lazım olacak.

Zarların oluşturduğu desen, bir ok şekli çıkarıyor — bu, ileriye doğru bir yönü, ilerlemeyi, büyümeyi temsil ediyor. Durma canım, yıldızlar senden yana; cesur ol, adımlarını at.${DISCLAIMER}`,

    wheel: `Merhaba canım, hoş geldin. Şans çarkın senin için döndü ve yıldızlar bana çarkın durduğu noktanın sırrını açtı. Gel bakalım, ne müjdeler bu dönüş.

Çarkın durduğu nokta, bereket ve bolluk sembolü taşıyor — bu, önündeki dönemin bereketli olacağını müjdeliyor. Yıldızlar senin için parlıyor; fırsatları kaçırma, kendine güven ve ilerle. Bu dönem, elini attığın işlerin yolunda gideceği, ilişkilerinin derinleşeceği bir zaman olacak.

Çarkın dönüş yönü bana bir şey daha söylüyor: Bu bereket, bir anda değil, adım adım gelecek. Sabırlı ol. Çark döndükçe her adımda bir yeni fırsat, bir yeni kapı açılacak. Aceleci olma, her fırsatı sindire sindire değerlendir.

Çarkın üzerindeki renkler de mesaj taşıyor. Altın tonları, maddi bir bereketin yaklaştığını; yeşil tonları, sağlığın ve enerjinin yenileneceğini; mavi tonları ise içsel huzurun artacağını gösteriyor. Her renk, bir müjde.

Çarkın merkezi, bir yıldız sembolü taşıyor — bu, senin şanslı yıldızının parladığını, bu dönemde dikkat çekici bir olayın seni beklediğini gösteriyor. Beklemediğin bir yerden, beklemediğin bir şekilde güzel bir haber gelebilir. Gözlerini dört aç.${DISCLAIMER}`,

    star: `Merhaba canım, hoş geldin. Doğum bilgilerini ve yıldızlarının bugün oluşturduğu gizemli haritayı önüme serdim.\n\nYıldızların aşk, kariyer, para ve hayatındaki önemli dönüşümler konusunda sana bir hikâye fısıldıyor. Gökyüzündeki ışıkların hangi kapıyı işaret ettiğini, hangi konuda sabırlı olman gerektiğini ve önündeki dönemin hangi enerjiyi taşıdığını anlatacağım.\n\nBu yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.`,

    lottery: `Merhaba canım, hoş geldin. Biletini aldın, sayılar belli oldu ve yıldızlar bana rakamların gizli mesajını açtı. Gel bakalım, ne söylüyor bu sayılar.

Biletindeki sayıların toplamı, önündeki dönemin şanslı enerjisini yansıtıyor. Rakamların birleşimi, senin için özel bir anlam taşıyor — bu sayılar, hayatında bir dönemin kapanıp yeni bir dönemin açıldığını simgeliyor. Eski bir beklentiyi bırakıp, yenisine hazırlanıyorsun.

İlk rakama bakıyorum canım. Bu sayı, aşk hayatına işaret ediyor — kalbinde bir umut var, ve bu umut yakında karşılık bulacak. Eğer birini bekliyorsan, o kişi bir adım atacaktır. Aceleci olma, yıldızlar zamanı ayarlıyor.

İkinci rakam, kariyer ve maddi hayatı temsil ediyor. Bu sayı, önündeki dönemde küçük ama anlamlı bir kazanç ya da fırsat geleceğini gösteriyor. Büyük bir ikramiye olmasa da, seni şaşırtacak güzel bir sürpriz olabilir. Beklemediğin bir yerden gelir gelebilir.

Üçüncü rakam ise sağlığı ve enerjiyi simgeliyor. Bu sayı, vücudunun sana bir mesaj gönderdiğini, dinlenmeye ihtiyacın olduğunu söylüyor. Son zamanlarda çok koşturuyorsun; biraz yavaşla, nefes al.

Biletin üzerindeki sayıların dizilişi, bir yıldız deseni oluşturuyor — bu, senin şanslı dönemin yaklaştığını, yıldızların senin için hizalandığını gösteriyor. Büyük bir kazanç olmasa da, küçük sürprizler seni bekliyor. Şansın açık olsun canım.${DISCLAIMER}`,
  };

  let text = fallbacks[fortuneType] || fallbacks.coffee;

  if (userInput && fortuneType === 'dream') {
    text = `Merhaba canım, hoş geldin. Rüyanı dikkatle dinledim: ${userInput} — yıldızlar bana bu rüyanın sembollerinin sırrını açtı.

Rüyanda gördüğün bu semboller, iç dünyanın aynası. Bilinçaltın sana bir mesaj gönderiyor — duymaya hazır ol. Rüyanın atmosferi bana sıcak ve biraz gizemli geliyor; bu, bir dönüşüm içinde olduğunu, eski bir kalıbı bırakıp yeni bir başlangıca hazırlandığını gösteriyor.

Rüyanın merkezindeki sembol, bana bir kapı ya da geçit çağrıştırıyor. Bu, hayatında bir kapının açılmak üzere olduğunu gösteriyor — belki yeni bir fırsat, belki yeni bir insan, belki yeni bir içsel farkındalık. Bu kapıyı açmak için bir anahtarın var: cesaret. Korkma canım, kapı senin için açılıyor.

Rüyanın ikinci bölümünde bir su sembolü görüyorum — belki bir nehir, belki bir deniz, belki bir yağmur. Su, duyguları temsil eder. Bu sembol, duygusal bir arınma dönemi yaşayacağını, içinden geçen hislerle yüzleşip onları serbest bırakacağını gösteriyor. Bu arınmadan sonra hafifleyeceksin, yeni bir enerjiyle dolacaksın.

Rüyanın sonunda bir ışık görüyorsan, bu çok güzel bir işaret. Işık, yolun aydınlanacağını, karanlıkta kaldığını hissettiğin bir konunun yakında netleşeceğini müjdeliyor. Yıldızlar senin için parlıyor.

Rüyanın mesajı şu canım: İçindeki sesi dinle, korkuyla değil sevgiyle hareket et. Önündeki günlerde seni şaşırtacak güzel gelişmeler olabilir — beklenmedik bir anda, beklenmedik bir yerden. Hazır ol, kalbini açık tut.${DISCLAIMER}`;
  }

  if (userInput && fortuneType === 'water') {
    text = `Merhaba canım, suyu karıştırdığın anda oluşan enerjiye baktım: ${userInput}. Suyun merkezindeki hareket, zihninde bekleyen bir konunun artık çözülmeye başladığını gösteriyor. Yakın zamanda bir konuşma, bir haber ve küçük ama sevindiren bir fırsat öne çıkıyor. Kalbinin acele etmemesi gereken bir dönemdesin; suyun ritmi sabırla ilerlemeyi söylüyor.${DISCLAIMER}`;
  }

  if (userInput && fortuneType === 'angel') {
    text = `Merhaba canım, seçtiğin melek kartları: ${userInput}. Kartların ortak mesajı korunma, sevgi ve cesaret. Geçmişte kapanan bir kapının ardından yeni bir yol açılıyor. Aşk tarafında kalbini yumuşatan bir gelişme, kariyerde ise küçük bir başlangıcın büyüme ihtimali görünüyor. En güçlü mesaj: sezgine güven ama kararlarını sakinlikle ver.${DISCLAIMER}`;
  }

  if (userInput && fortuneType === 'tarot') {
    text = `Merhaba canım, hoş geldin. Seçtiğin üç kartı dizdim önüme: ${userInput} — yıldızlar bana onların sırrını açtı. İlk kartın geçmişini, ikinci kartın bugününü, üçüncü kartın ise geleceğini temsil ediyor.

Geçmiş kartına bakıyorum canım. Bu kart, geçmişinde bir ayrılık ya da bitiş olduğunu gösteriyor — belki bir ilişki, belki bir alışkanlık, belki bir dönem. Ama bu bitiş, seni üzse de aslında seni özgürleştirdi. Kartın ters dönük figürü, o geçmişin seni hâlâ biraz etkilediğini, ama artık onunla vedalaşma vaktinin geldiğini söylüyor. O geçmiş, senin bugünkü gücünün temelidir; utanma, onu kabul et.

Bugün kartına geçelim. Bu kart, tam ortasında bir yol ayrımı sembolü taşıyor. Şu an hayatında bir karar vermek üzeresin — belki bir ilişki, belki bir iş, belki bir içsel seçim. Kart, kalbinin sesini dinlemeni söylüyor. Aklın değil, kalbin yol göstersin. Sezgilerin şu an çok güçlü; yıldızlar onları besliyor.

Gelecek kartına bakıyorum canım. Bu kart, üzerinde bir güneş sembolü taşıyor — bu, gelecekte seni parlak, aydınlık bir dönemin beklediğini müjdeliyor. Önümüzdeki haftalarda, beklediğin bir haber gelecek, beklediğin bir karşılaşma gerçekleşecek. Kartın alt kısmındaki iki el figürü, bu dönemi paylaşacağın birinin olduğunu gösteriyor.

Üç kartı bir araya getirdiğimde, şöyle bir hikâye çıkıyor: Geçmişin seni hazırladı, bugünün seni yol'a koydu, geleceğin seni ödüllendirecek. Aceleci olma, her kartın sırasını bekle. Yıldızlar senin için döndü.${DISCLAIMER}`;
  }

  return text;
}

export function getCachedReadings(): FortuneReading[] {
  return completePendingReadings(getStoredReadings());
}

function getStoredReadings(): FortuneReading[] {
  try {
    const raw = localStorage.getItem(READINGS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as FortuneReading[];
  } catch {
    return [];
  }
}

function saveStoredReadings(readings: FortuneReading[]): void {
  try {
    localStorage.setItem(READINGS_KEY, JSON.stringify(readings.slice(0, 50)));
  } catch {
    const withoutImages = readings.slice(0, 50).map((r) => ({ ...r, image_data: null }));
    try {
      localStorage.setItem(READINGS_KEY, JSON.stringify(withoutImages));
    } catch {
      // give up
    }
  }
}

export async function submitFortune(opts: {
  fortuneType: string;
  imageData?: string[];
  userInput?: string;
}): Promise<{ success: boolean; readingId?: string; error?: string }> {
  const userEmail = getUserEmail();

  if (getCredits() < FORTUNE_COST) {
    return { success: false, error: `Yeterli krediniz yok. Bu fal ${FORTUNE_COST} kredi.` };
  }

  try {
    const compressedImages = opts.imageData
      ? await Promise.all(opts.imageData.map((img) => compressImage(img)))
      : undefined;

    // Image and dream readings are processed by the Gemini Edge Function.
    // Credits are charged only after the server accepts the submission.
    if (hasSupabaseConfig && (opts.fortuneType === 'dream' || opts.fortuneType === 'star' || opts.fortuneType === 'water' || opts.fortuneType === 'angel' || (opts.imageData && opts.imageData.length > 0))) {
      const { data, error } = await supabase.functions.invoke('gemini-fortune', {
        body: {
          fortuneType: opts.fortuneType,
          userInput: opts.userInput || '',
          imageData: compressedImages || undefined,
          userEmail,
        },
      });

      if (error || !data?.success || !data?.readingId) {
        return { success: false, error: error?.message || data?.error || 'Falınız oluşturulamadı.' };
      }

      const spent = spendCredits(FORTUNE_COST);
      if (!spent.success) {
        return { success: false, error: `Yeterli krediniz yok. Bu fal ${FORTUNE_COST} kredi.` };
      }
      window.dispatchEvent(new Event('credits-updated'));
      return { success: true, readingId: data.readingId };
    }

    const readingId = crypto.randomUUID();
    const now = new Date();
    const readyAt = new Date(now.getTime() + 5 * 60 * 1000);

    const result = generateFallbackFortune(opts.fortuneType, opts.userInput);
    const spent = spendCredits(FORTUNE_COST);
    if (!spent.success) {
      return { success: false, error: `Yeterli krediniz yok. Bu fal ${FORTUNE_COST} kredi.` };
    }
    window.dispatchEvent(new Event('credits-updated'));

    const reading: FortuneReading = {
      id: readingId,
      user_email: userEmail,
      fortune_type: opts.fortuneType,
      status: 'pending',
      result: null,
      image_data: compressedImages ? JSON.stringify(compressedImages.slice(0, 2)) : null,
      user_input: opts.userInput || null,
      created_at: now.toISOString(),
      ready_at: readyAt.toISOString(),
    };

    const readings = getStoredReadings();
    readings.unshift(reading);
    saveStoredReadings(readings);

    setTimeout(() => {
      const current = getStoredReadings();
      const updated = current.map((r) =>
        r.id === readingId ? { ...r, status: 'completed' as const, result } : r
      );
      saveStoredReadings(updated);
    }, 5 * 60 * 1000);

    return { success: true, readingId };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { success: false, error: `Fal gönderilemedi: ${msg}` };
  }
}

function completePendingReadings(readings: FortuneReading[]): FortuneReading[] {
  const now = Date.now();
  let changed = false;
  const updated = readings.map((r) => {
    if (r.status === 'pending' && new Date(r.ready_at).getTime() <= now) {
      changed = true;
      return { ...r, status: 'completed' as const };
    }
    return r;
  });
  if (changed) saveStoredReadings(updated);
  return updated;
}

export async function fetchReadings(): Promise<FortuneReading[]> {
  const localReadings = completePendingReadings(getStoredReadings());

  try {
    const { data, error } = await supabase
      .from('fortune_readings')
      .select('id,user_email,fortune_type,status,result,image_data,user_input,created_at,ready_at')
      .eq('user_email', getUserEmail())
      .order('created_at', { ascending: false });

    if (error || !data) return localReadings;

    const now = Date.now();
    const remoteReadings: FortuneReading[] = data.map((r) => ({
      ...r,
      status: r.status === 'pending' && new Date(r.ready_at).getTime() <= now
        ? 'completed'
        : r.status,
    })) as FortuneReading[];

    // Persist the status transition after the 5-minute timer has elapsed.
    const expired = data.filter((r) => r.status === 'pending' && new Date(r.ready_at).getTime() <= now);
    if (expired.length) {
      await supabase
        .from('fortune_readings')
        .update({ status: 'completed' })
        .in('id', expired.map((r) => r.id));
    }

    // Keep older/local non-Gemini readings visible while using Supabase as the
    // source of truth for Gemini-generated readings.
    const remoteIds = new Set(remoteReadings.map((r) => r.id));
    return [...remoteReadings, ...localReadings.filter((r) => !remoteIds.has(r.id))]
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  } catch {
    return localReadings;
  }
}

export const FORTUNE_TYPE_LABELS: Record<string, string> = {
  coffee: 'Kahve Falı',
  tarot: 'Tarot Falı',
  palm: 'El Falı',
  face: 'Yüz Falı',
  dream: 'Rüya Yorumu',
  katina: 'Katina Falı',
  dice: 'Zar Falı',
  wheel: 'Şans Çarkı',
  lottery: 'Piyango',
  star: 'Yıldız Falı',
};

export const FORTUNE_TYPE_ICONS: Record<string, string> = {
  coffee: '☕',
  tarot: '🃏',
  palm: '✋',
  face: '😊',
  dream: '🌙',
  katina: '🎴',
  dice: '🎲',
  wheel: '🎡',
  lottery: '🎟️',
  star: '🔮',
};
