# V19 — 3D tasarım ve reklam düzeltmeleri

- Ana sayfa: ortak 3D/mistik mor-altın görsel dili.
- Su Falı ana kartı statik 3D kase; Su Falı ekranındaki kase interaktif.
- Melek Kartları, El/Yüz ve fotoğraf falı ekranları ortak panel tasarımına geçirildi.
- AdMob banner artık native platformda gerçek banner gösteriyor.
- Interstitial ve rewarded reklamlar native AdMob üzerinden çağrılıyor.
- Native reklam yükleme hatasında ekran artık sessizce kapanmak yerine tekrar deneme sunuyor.
- Development build: Google test reklamları. Production: gerçek AdMob birimleri.
- Launcher icon source: `resources/icon.png`; native kaynaklara işlemek için `npm run assets:generate`.

## Kontrol

Bu ortamda npm bağımlılıkları kurulum zaman aşımına uğradığı için tam Vite/TypeScript/Android derlemesi çalıştırılamadı. Kaynak değişiklikleri paket içine işlendi; Android native klasörü ZIP'te mevcut olmadığı için APK burada üretilemedi.
