# Döndü Teyze Android APK

Bu proje Capacitor 6 + Android + Vite kullanır.

## Telefonda test APK'sı

GitHub'a push ettikten sonra **Actions → Build Döndü Teyze Android APK → Run workflow** ile derlemeyi başlatabilirsiniz.

Build tamamlandığında **donduteyze-debug-apk** artifact'inden `app-debug.apk` indirilebilir.

Bu APK fiziksel Android telefonda test içindir. Google Play yayını için daha sonra imzalı **AAB** üretmeliyiz.

## İlk kurulum

Android telefonda bilinmeyen kaynaklardan uygulama yükleme izni gerekebilir. Google Play'den olmayan APK olduğu için Android bunu sorabilir.

## Önemli

- APK debug sürümüdür; mağaza yayını için kullanılmamalıdır.
- Gerçek AdMob reklamlarını test etmek yerine yayın öncesinde test reklamları kullanılmalıdır.
- Google/Apple OAuth için Supabase ve sağlayıcı tarafındaki redirect ayarları ayrıca yapılmalıdır.


## Analytics

Apply the new Supabase migration `20260822000100_analytics_events.sql` before using Admin analytics. Country is a browser locale/timezone hint, not IP-geolocation. Revenue is estimated from subscription records and prices configured in Admin → İçerik & Fiyat.


## V19 3D / reklam düzeltmeleri

- Ana sayfadaki tüm fal kartları aynı mor-altın 3D/mistik görsel diliyle güçlendirildi. Ana sayfadaki Su Falı kartı statiktir; hareket sadece Su Falı ekranındaki kasede yapılır.
- Su Falı ekranı parmakla karıştırma ritüelini ve reklam sonrası AI gönderimini korur.
- El/Yüz fotoğraf ekranları, Melek Kartları ve diğer fal ekranları ortak 3D panel görsel diline alındı.
- Native Capacitor tarafında banner reklamları artık gerçek AdMob banner çağrısıyla gösterilir; interstitial ve rewarded reklamlar da native AdMob üzerinden hazırlanıp gösterilir.
- Geliştirme derlemelerinde resmi Google test reklamları otomatik kullanılır. Üretimde `VITE_USE_TEST_ADS=false` ile gerçek birimler kullanılır.
- Launcher ikonunun gerçekten Android/iOS kaynaklarına işlenmesi için `npm run assets:generate` çalıştırılmalıdır; `resources/icon.png` yeni Döndü Teyze ikonudur.

### Reklam notu

AdMob'un gerçek reklam sunabilmesi için Google AdMob tarafında uygulama kimliği ve reklam birimlerinin native projeye doğru şekilde tanımlanmış olması gerekir. Bu kaynak ZIP'inde Android native klasörü bulunmadığından burada native proje üretimi yapılmamıştır. `npx cap add android` sonrası `npm run assets:generate` ve `npm run cap:sync` çalıştırılmalıdır.
