# Döndü Teyze V19 – Reference 3D Visual Overhaul

- Ana sayfa 3x3 fal vitrinine Su Falı ve Melek Kartları eklendi.
- Fal kartları, referans görseldeki mor-altın, ışıklı ve görsel-merkezli tasarım diline yaklaştırıldı.
- Bugünün Köşesi, Günlük/Günlüklerim, Döndü Dostum ve Kredi Kazan bölümleri aynı premium görsel sistemle yenilendi.
- Su Falı için parmakla karıştırma/enerji ilerlemesi olan ayrı ritüel sayfası eklendi.
- Melek Kartları için üç kart seçmeli ayrı fal sayfası eklendi.
- Su Falı ve Melek Kartları reklam geçişinden sonra yapay zekâ fal gönderimine bağlandı; Fallarım kaydı mevcut submitFortune akışı üzerinden devam ediyor.
- Gemini Edge Function'a water ve angel fal tipleri için prompt/fallback desteği eklendi.
- Referans tasarım için yeni 3D görsel varlıklar: card-su.png, card-melek.png, water-ritual.png.
- APK derlemesi bu ortamda npm bağımlılıkları indirilemediği için doğrulanamadı; kaynak paket hazırlanmıştır.
