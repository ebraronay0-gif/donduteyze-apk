#!/bin/bash
set -e

echo "Building web app..."
npm run build

echo "Creating Android project..."
if [ ! -d android ]; then
  npx cap add android
fi

echo "Generating Android launcher icons..."
test -s resources/icon.png
# Always use the same transparent Döndü Teyze artwork as the launcher source.
cp -f public/icon.png resources/icon.png
if [ -d android/app/src/main/res ]; then
  find android/app/src/main/res -maxdepth 1 -type d -name 'mipmap-*' -exec rm -rf {} + || true
fi
npx capacitor-assets generate --android

# Fail loudly if Capacitor did not create the launcher icons.
for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  test -s "android/app/src/main/res/mipmap-${density}/ic_launcher.png"
done

echo "Syncing to Android..."
npx cap sync android
./scripts/configure-oauth-android.sh

echo "Done. APK can be built with:"
echo "  cd android && ./gradlew assembleDebug"
